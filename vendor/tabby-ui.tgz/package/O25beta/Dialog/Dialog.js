import React__default, { forwardRef, useRef, useImperativeHandle, useState, useCallback, useEffect } from 'react';
import { createPortal } from 'react-dom';
import SwipeListener from 'swipe-listener';
import cn from 'classnames';
import Close24 from '../../icons/core/Close24.js';
import { FadeTransition } from './components/FadeTransition/FadeTransition.js';
import { SlideTransitionUp } from './components/SlideTransitionUp/SlideTransitionUp.js';
import { MOBILE_BREAKPOINT } from './constants/index.js';
import { useIsDesktop } from './hooks/use-is-desktop.js';
import { isTopSwipe, isSwipeOnElement } from './utils.js';
import "./Dialog.css";

const getTransitionComponent = (transitionVariant, isMobile) => {
  if (isMobile || transitionVariant === "slide") {
    return SlideTransitionUp;
  }
  return FadeTransition;
};
const Dialog = forwardRef((props, ref) => {
  const {
    opened,
    children,
    onClose,
    className,
    fullScreen,
    fullWidth,
    showCloseButton,
    disallowClosing,
    showMobileDialog = false,
    disabledBackdropTransition = false,
    mobileBreakpoint = MOBILE_BREAKPOINT,
    transitionVariant = "fade",
    container: portalContainer,
    ...rest
  } = props;
  const isDesktop = useIsDesktop(mobileBreakpoint);
  const isMobile = !isDesktop && showMobileDialog;
  const TransitionComponent = getTransitionComponent(
    transitionVariant,
    isMobile
  );
  const dialogRef = useRef(null);
  useImperativeHandle(ref, () => dialogRef.current, []);
  const swipeTarget = document;
  const deltaRef = useRef(0);
  const [translate, setTranslate] = useState(null);
  const handleClose = useCallback(() => {
    onClose?.();
  }, [onClose]);
  useEffect(() => {
    if (!isMobile || disallowClosing) {
      return void 0;
    }
    const listener = SwipeListener(swipeTarget, {
      lockAxis: true,
      mouse: false,
      minHorizontal: 10
    });
    return () => listener.off();
  }, [swipeTarget, disallowClosing, isMobile]);
  const handleSwiping = useCallback((event) => {
    if (dialogRef.current && isTopSwipe(event) && isSwipeOnElement(event, dialogRef.current.getBoundingClientRect().top)) {
      const [startY, endY] = event.detail.y;
      deltaRef.current = endY - startY;
      setTranslate(`translateY(${deltaRef.current}px)`);
    }
  }, []);
  const handleSwipeRelease = useCallback(() => {
    if (deltaRef.current && dialogRef.current) {
      const dialogHeight = dialogRef.current.getBoundingClientRect().height;
      if (deltaRef.current > dialogHeight / 2) {
        handleClose();
        setTranslate(null);
      } else {
        setTranslate(`translateY(0px)`);
      }
    }
  }, [handleClose]);
  useEffect(() => {
    if (!isMobile || disallowClosing) {
      return void 0;
    }
    swipeTarget.addEventListener("swiping", handleSwiping);
    swipeTarget.addEventListener("swiperelease", handleSwipeRelease);
    return () => {
      swipeTarget.removeEventListener("swiping", handleSwiping);
      swipeTarget.removeEventListener("swiperelease", handleSwipeRelease);
    };
  }, [
    swipeTarget,
    handleSwiping,
    handleSwipeRelease,
    isMobile,
    disallowClosing
  ]);
  return createPortal(
    /* @__PURE__ */ React__default.createElement(
      FadeTransition,
      {
        opened: !!opened,
        className: cn("tui-o25-beta-component", "tui-dialog__backdrop"),
        onClick: disallowClosing ? void 0 : handleClose,
        disabledAnimation: disabledBackdropTransition
      },
      /* @__PURE__ */ React__default.createElement(
        TransitionComponent,
        {
          opened: !!opened,
          ref: dialogRef,
          style: translate ? { transform: translate } : {},
          className: cn(
            "tui-o25-beta-component",
            "tui-dialog__modal",
            {
              "tui-dialog__modal_full-width": fullWidth,
              "tui-dialog__modal_full-screen": fullScreen,
              "tui-dialog__modal_mobile": isMobile
            },
            className
          ),
          onClick: (e) => e.stopPropagation(),
          role: "dialog",
          ...rest
        },
        /* @__PURE__ */ React__default.createElement(React__default.Fragment, null, showCloseButton && onClose && !showMobileDialog && /* @__PURE__ */ React__default.createElement(Close24, { className: "tui-dialog__close", onClick: onClose }), isMobile && !disallowClosing && /* @__PURE__ */ React__default.createElement("div", { className: "tui-dialog__header" }, /* @__PURE__ */ React__default.createElement("div", { className: "tui-dialog__handle-bar" })), children)
      )
    ),
    portalContainer ?? document.body
  );
});
Dialog.displayName = "Dialog";

export { Dialog };
//# sourceMappingURL=Dialog.js.map
