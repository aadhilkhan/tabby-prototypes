import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { Transition } from 'react-transition-group';
import { TRANSITION_DURATION } from '../../constants/index.js';
import "./FadeTransition.css";

const FadeTransition = forwardRef(
  function Fade(props, ref) {
    const {
      opened,
      children,
      disabledAnimation = true,
      className,
      ...rest
    } = props;
    const duration = !disabledAnimation ? TRANSITION_DURATION : 0;
    return /* @__PURE__ */ React__default.createElement(
      Transition,
      {
        timeout: duration,
        in: opened,
        appear: true,
        unmountOnExit: true,
        exit: !disabledAnimation,
        enter: !disabledAnimation
      },
      (state, childProps) => {
        return /* @__PURE__ */ React__default.createElement(
          "div",
          {
            style: {
              "--tui-fade-duration": `${duration}ms`
            },
            className: cn(
              "tui-fade-transition",
              `tui-fade-transition_${state}`,
              {
                "tui-fade-transition_hidden": state === "exited" && !opened
              },
              className
            ),
            ref,
            ...rest,
            ...childProps
          },
          children
        );
      }
    );
  }
);

export { FadeTransition };
//# sourceMappingURL=FadeTransition.js.map
