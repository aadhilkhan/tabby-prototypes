const SidebarClasses = {
  root: "tui-o25beta-sidebar",
  navigation: "tui-o25beta-sidebar__navigation",
  logo: "tui-o25beta-sidebar__logo",
  logoSvg: "tui-o25beta-sidebar__logo-svg",
  logoCollapsed: "tui-o25beta-sidebar__logo-collapsed",
  logoExtended: "tui-o25beta-sidebar__logo-extended",
  header: "tui-o25beta-sidebar__header",
  footer: "tui-o25beta-sidebar__footer",
  group: "tui-o25beta-sidebar__group",
  groupContent: "tui-o25beta-sidebar__group-content",
  groupButton: "tui-o25beta-sidebar__group-button",
  groupButtonInteractive: "tui-o25beta-sidebar__group-button--interactive",
  groupButtonSelected: "tui-o25beta-sidebar__group-button--selected",
  groupButtonDisabled: "tui-o25beta-sidebar__group-button--disabled",
  groupButtonStartSlot: "tui-o25beta-sidebar__group-button-start-slot",
  groupButtonContent: "tui-o25beta-sidebar__group-button-content",
  groupButtonEndSlot: "tui-o25beta-sidebar__group-button-end-slot",
  itemButton: "tui-o25beta-sidebar__item-button",
  itemButtonSelected: "tui-o25beta-sidebar__item-button--selected",
  itemButtonDisabled: "tui-o25beta-sidebar__item-button--disabled",
  itemButtonContentWrapper: "tui-o25beta-sidebar__item-button-content-wrapper",
  itemButtonContent: "tui-o25beta-sidebar__item-button-content",
  itemButtonEndSlot: "tui-o25beta-sidebar__item-button-end-slot",
  itemButtonBadge: "tui-o25beta-sidebar__item-button-badge"
};

export { SidebarClasses };
//# sourceMappingURL=classes.js.map
