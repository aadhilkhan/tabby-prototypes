import cn from 'classnames';
import React__default, { useRef, useState } from 'react';
import { useResizeObserver } from '../../hooks/useResizeObserver.js';
import "./Collapse.css";

const Collapse = React__default.forwardRef(
  (props, ref) => {
    const { opened, collapsedSize = 0, children, className, ...rest } = props;
    const initialOpened = useRef(opened);
    const contentRef = useRef(null);
    const [contentHeight, setContentHeight] = useState(collapsedSize);
    const getHeight = () => {
      if (initialOpened.current) {
        initialOpened.current = false;
        return "auto";
      }
      return opened ? contentHeight : "0";
    };
    useResizeObserver(
      contentRef.current,
      (entry) => setContentHeight(entry.contentRect.height)
    );
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        className: cn("tui-o25-beta-component", "tui-collapse", className),
        style: {
          height: getHeight(),
          minHeight: collapsedSize
        },
        ...rest,
        ref
      },
      /* @__PURE__ */ React__default.createElement("div", { ref: contentRef, className: "tui-collapse__wrapper" }, children)
    );
  }
);
Collapse.displayName = "Collapse";

export { Collapse };
//# sourceMappingURL=Collapse.js.map
