import cn from 'classnames';
import React__default from 'react';
import { Button } from '../Button/Button.js';
import '@mui/material';
import '../../common/Loader/Loader.js';
import '@mui/utils';
import '../../theme/palette/paletteB23.js';
import { Styles } from './styles/styles.js';

function IconButton(props) {
  const { children, className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(
    Button,
    {
      ...rest,
      className: cn("Tui-Component", "Tui-IconButton", className),
      sx: Styles(props)
    },
    children
  );
}

export { IconButton };
//# sourceMappingURL=IconButton.js.map
