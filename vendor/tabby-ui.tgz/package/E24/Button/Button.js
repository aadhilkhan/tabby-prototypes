import React__default from 'react';
import { ButtonCommon } from '../../common/Button/Button.js';
import { Styles } from './styles/styles.js';

function Button(props) {
  const {
    color = "primary",
    size = "medium",
    variant = "contained",
    ...rest
  } = props;
  return /* @__PURE__ */ React__default.createElement(
    ButtonCommon,
    {
      color,
      size,
      variant,
      ...rest,
      sx: Styles(props)
    }
  );
}

export { Button };
//# sourceMappingURL=Button.js.map
