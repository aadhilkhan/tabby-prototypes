import React__default from 'react';
import { CheckboxCommon } from '../../common/Checkbox/Checkbox.js';
import CheckboxCheckedIcon from './icons/CheckboxCheckedIcon.js';
import CheckboxIcon from './icons/CheckboxIcon.js';
import CheckboxIndeterminateIcon from './icons/CheckboxIndeterminateIcon.js';
import { Styles } from './styles/styles.js';

function BaseCheckbox(props, ref) {
  return /* @__PURE__ */ React__default.createElement(
    CheckboxCommon,
    {
      icon: /* @__PURE__ */ React__default.createElement(CheckboxIcon, null),
      checkedIcon: /* @__PURE__ */ React__default.createElement(CheckboxCheckedIcon, null),
      indeterminateIcon: /* @__PURE__ */ React__default.createElement(CheckboxIndeterminateIcon, null),
      ref,
      ...props,
      sx: Styles(props)
    }
  );
}
const Checkbox = React__default.forwardRef(BaseCheckbox);

export { Checkbox };
//# sourceMappingURL=Checkbox.js.map
