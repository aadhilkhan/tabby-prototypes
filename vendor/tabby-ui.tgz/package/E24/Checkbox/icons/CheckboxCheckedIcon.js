import React__default from 'react';

function CheckboxCheckedIcon(props) {
  return /* @__PURE__ */ React__default.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "16",
      height: "16",
      fill: "none",
      ...props
    },
    /* @__PURE__ */ React__default.createElement(
      "rect",
      {
        width: "16",
        height: "16",
        fill: "#131C26",
        className: "TuiCheckbox-base",
        rx: "4"
      }
    ),
    /* @__PURE__ */ React__default.createElement(
      "path",
      {
        fill: "#fff",
        fillRule: "evenodd",
        d: "m7.27 11.716-.006.007L3.75 8.209l1.236-1.235L7.263 9.25 11.513 5l1.238 1.238-5.48 5.48z",
        className: "TuiCheckbox-icon",
        clipRule: "evenodd"
      }
    )
  );
}

export { CheckboxCheckedIcon as default };
//# sourceMappingURL=CheckboxCheckedIcon.js.map
