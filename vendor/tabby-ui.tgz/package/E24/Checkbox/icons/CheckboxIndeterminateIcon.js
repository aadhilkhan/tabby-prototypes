import React__default from 'react';

function CheckboxIndeterminateIcon(props) {
  return /* @__PURE__ */ React__default.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "16",
      height: "16",
      fill: "none",
      ...props
    },
    /* @__PURE__ */ React__default.createElement(
      "rect",
      {
        width: "16",
        height: "16",
        fill: "#131C26",
        className: "TuiCheckbox-base",
        rx: "4"
      }
    ),
    /* @__PURE__ */ React__default.createElement("path", { fill: "#fff", d: "M4 7h8v2H4z", className: "TuiCheckbox-icon" })
  );
}

export { CheckboxIndeterminateIcon as default };
//# sourceMappingURL=CheckboxIndeterminateIcon.js.map
