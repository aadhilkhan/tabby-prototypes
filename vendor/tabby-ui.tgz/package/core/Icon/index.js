export { TuiIconClasses } from './styles/classes.js';
//# sourceMappingURL=index.js.map
