const RTLFlipIconNames = [
  "ArrowBackDEV-LTR",
  "ArrowForwardDEV-LTR",
  "ArrowOutsideDEV-LTR",
  "ChevronBackDEV-LTR",
  "ChevronForwardDEV-LTR",
  "DoubleChevronBackDEV-LTR",
  "DoubleChevronForwardDEV-LTR",
  "SendDEV-LTR",
  "BreadcrumbsDEV-LTR"
];

export { RTLFlipIconNames };
//# sourceMappingURL=constant.js.map
