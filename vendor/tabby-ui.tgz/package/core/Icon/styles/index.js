const flipOnRtlIcons = [
  "ArrowBack24",
  "ArrowForward24",
  "ArrowOutside16",
  "ArrowOutside24",
  "ChevronBack24",
  "ChevronForward16",
  "ChevronForward24",
  "DoubleChevronBack24",
  "DoubleChevronForward24"
];

export { flipOnRtlIcons };
//# sourceMappingURL=index.js.map
