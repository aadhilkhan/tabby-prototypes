const TuiIconClasses = {
  root: "TuiIcon-root"
};

export { TuiIconClasses };
//# sourceMappingURL=classes.js.map
