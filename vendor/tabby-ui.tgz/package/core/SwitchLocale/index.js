export { SwitchLocale } from './SwitchLocale.js';
//# sourceMappingURL=index.js.map
