export { BaseThemeProvider } from './BaseThemeProvider/BaseThemeProvider.js';
export { BaseThemeProviderNoO25 } from './BaseThemeProvider/BaseThemeProviderNoO25.js';
export { BaseI18nextProvider } from './I18next/BaseI18nextProvider.js';
export { i18n, initI18next } from './I18next/instance.js';
export { commonI18nOptions } from './I18next/config.js';
export { I18nextProvider, Trans, Translation, useTranslation, withTranslation } from 'react-i18next';
export { Logo } from './Logo/Logo.js';
export { TuiLogoClasses } from './Logo/styles/classes.js';
export { SwitchLocale } from './SwitchLocale/SwitchLocale.js';
//# sourceMappingURL=index.js.map
