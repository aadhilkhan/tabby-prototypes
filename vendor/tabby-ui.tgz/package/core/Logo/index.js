export { Logo } from './Logo.js';
export { TuiLogoClasses } from './styles/classes.js';
//# sourceMappingURL=index.js.map
