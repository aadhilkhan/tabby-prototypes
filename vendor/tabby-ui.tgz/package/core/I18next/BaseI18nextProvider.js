import React__default, { useEffect, Suspense } from 'react';
import { I18nextProvider } from 'react-i18next';
import { initI18next, i18n } from './instance.js';

function BaseI18nextProvider(props) {
  const { children, config = {} } = props;
  useEffect(() => {
    initI18next(config);
  }, [config]);
  return /* @__PURE__ */ React__default.createElement(I18nextProvider, { i18n }, /* @__PURE__ */ React__default.createElement(Suspense, { fallback: /* @__PURE__ */ React__default.createElement(React__default.Fragment, null) }, children));
}

export { BaseI18nextProvider };
//# sourceMappingURL=BaseI18nextProvider.js.map
