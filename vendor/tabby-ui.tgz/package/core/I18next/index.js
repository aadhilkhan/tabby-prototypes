export { BaseI18nextProvider } from './BaseI18nextProvider.js';
export { i18n, initI18next } from './instance.js';
export { commonI18nOptions } from './config.js';
export { I18nextProvider, Trans, Translation, useTranslation, withTranslation } from 'react-i18next';
//# sourceMappingURL=index.js.map
