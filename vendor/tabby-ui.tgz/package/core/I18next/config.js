const commonI18nOptions = {
  supportedLngs: ["en", "ar"],
  preload: ["en", "ar"],
  fallbackLng: "en",
  debug: false,
  detection: {
    order: ["localStorage", "cookie"],
    caches: ["localStorage", "cookie"],
    lookupLocalStorage: "BaseI18nextProvider_lang",
    lookupCookie: "BaseI18nextProvider_lang"
  },
  backend: {
    loadPath: (lng) => {
      return `${window.location.origin}/assets/locales/${lng}.json`;
    }
  }
};

export { commonI18nOptions };
//# sourceMappingURL=config.js.map
