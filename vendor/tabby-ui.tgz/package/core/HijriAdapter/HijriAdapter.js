import { gregorianToHijri, hijriToGregorian } from '@tabby_ai/hijri-converter';
import { setYear, setMonth, setDate, addYears, addMonths, addDays, startOfYear, endOfYear, startOfMonth, endOfMonth, getDaysInMonth, isBefore, isAfter, isEqual, getYear, getMonth, getDate, startOfWeek, endOfWeek, isValid, format } from 'date-fns';
import { ar, enUS } from 'date-fns/locale';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
const _HijriAdapter = class _HijriAdapter extends AdapterDateFns {
  constructor(options) {
    const selectedLocale = options?.locale || "ar";
    const dateFnsLocale = selectedLocale === "ar" ? ar : enUS;
    const hijriFormats = {
      // Date formats
      keyboardDate: "yyyy/MM/dd",
      shortDate: "yyyy/MM/dd",
      normalDate: "yyyy/MM/dd",
      fullDate: "yyyy/MM/dd",
      // Time formats for DateTimePicker
      fullTime: "HH:mm:ss",
      fullTime12h: "hh:mm:ss a",
      fullTime24h: "HH:mm:ss",
      shortTime: "HH:mm",
      shortTime12h: "hh:mm a",
      shortTime24h: "HH:mm",
      // DateTime formats
      fullDateTime: "yyyy/MM/dd HH:mm",
      fullDateTime12h: "yyyy/MM/dd hh:mm a",
      fullDateTime24h: "yyyy/MM/dd HH:mm",
      keyboardDateTime: "yyyy/MM/dd HH:mm",
      keyboardDateTime12h: "yyyy/MM/dd hh:mm a",
      keyboardDateTime24h: "yyyy/MM/dd HH:mm"
    };
    super({
      locale: dateFnsLocale,
      formats: hijriFormats
    });
    __publicField(this, "localeType", "ar");
    __publicField(this, "locale");
    /**
     * Sets the Hijri year of the date
     * @param date - Date object to modify
     * @param year - Hijri year (1343-1500 AH)
     * @returns New Date object with updated Hijri year
     */
    __publicField(this, "setYear", (date, year) => {
      const hijri = this.toHijri(date);
      if (!hijri) return setYear(date, year);
      const clampedYear = this.clampHijriYear(year);
      const daysInTargetMonth = this.getDaysInHijriMonth(
        clampedYear,
        hijri.month
      );
      const day = Math.min(hijri.day, daysInTargetMonth);
      return this.fromHijri(clampedYear, hijri.month, day);
    });
    /**
     * Sets the Hijri month of the date
     * @param date - Date object to modify
     * @param month - Month index (0-based, 0 = Muharram, 11 = Dhu al-Hijjah)
     * @returns New Date object with updated Hijri month
     */
    __publicField(this, "setMonth", (date, month) => {
      const hijri = this.toHijri(date);
      if (!hijri) return setMonth(date, month);
      const hijriMonth = month + 1;
      const daysInTargetMonth = this.getDaysInHijriMonth(hijri.year, hijriMonth);
      const day = Math.min(hijri.day, daysInTargetMonth);
      return this.fromHijri(hijri.year, hijriMonth, day);
    });
    /**
     * Sets the Hijri day of the month
     * @param date - Date object to modify
     * @param day - Day of the month (1-30)
     * @returns New Date object with updated Hijri day
     */
    __publicField(this, "setDate", (date, day) => {
      const hijri = this.toHijri(date);
      if (!hijri) return setDate(date, day);
      return this.fromHijri(hijri.year, hijri.month, day);
    });
    /**
     * Adds years to a Hijri date
     * @param date - Date object to modify
     * @param amount - Number of Hijri years to add (can be negative)
     * @returns New Date object with added years
     */
    __publicField(this, "addYears", (date, amount) => {
      const hijri = this.toHijri(date);
      if (!hijri) return addYears(date, amount);
      const newYear = hijri.year + amount;
      const clampedYear = this.clampHijriYear(newYear);
      const daysInTargetMonth = this.getDaysInHijriMonth(
        clampedYear,
        hijri.month
      );
      const day = Math.min(hijri.day, daysInTargetMonth);
      return this.fromHijri(clampedYear, hijri.month, day);
    });
    /**
     * Adds months to a Hijri date
     * @param date - Date object to modify
     * @param amount - Number of Hijri months to add (can be negative)
     * @returns New Date object with added months
     */
    __publicField(this, "addMonths", (date, amount) => {
      const hijri = this.toHijri(date);
      if (!hijri) return addMonths(date, amount);
      let newMonth = hijri.month + amount;
      let newYear = hijri.year;
      while (newMonth > 12) {
        newMonth -= 12;
        newYear += 1;
      }
      while (newMonth < 1) {
        newMonth += 12;
        newYear -= 1;
      }
      const clampedYear = this.clampHijriYear(newYear);
      if (clampedYear !== newYear) {
        if (newYear < _HijriAdapter.MIN_HIJRI_YEAR) {
          newMonth = 1;
        } else if (newYear > _HijriAdapter.MAX_HIJRI_YEAR) {
          newMonth = 12;
        }
      }
      const daysInTargetMonth = this.getDaysInHijriMonth(clampedYear, newMonth);
      const day = Math.min(hijri.day, daysInTargetMonth);
      return this.fromHijri(clampedYear, newMonth, day);
    });
    /**
     * Adds days to a date
     * @param date - Date object to modify
     * @param amount - Number of days to add (can be negative)
     * @returns New Date object with added days
     */
    __publicField(this, "addDays", (date, amount) => {
      return addDays(date, amount);
    });
    /**
     * Gets the first day of the Hijri year
     * @param date - Date object
     * @returns First day of the Hijri year (1st of Muharram)
     */
    __publicField(this, "startOfYear", (date) => {
      const hijri = this.toHijri(date);
      if (!hijri) return startOfYear(date);
      return this.fromHijri(hijri.year, 1, 1);
    });
    /**
     * Gets the last day of the Hijri year
     * @param date - Date object
     * @returns Last day of the Hijri year (29th or 30th of Dhu al-Hijjah)
     */
    __publicField(this, "endOfYear", (date) => {
      const hijri = this.toHijri(date);
      if (!hijri) return endOfYear(date);
      const lastMonth = 12;
      const lastDay = this.getDaysInHijriMonth(hijri.year, lastMonth);
      return this.fromHijri(hijri.year, lastMonth, lastDay);
    });
    /**
     * Gets the first day of the Hijri month
     * @param date - Date object
     * @returns First day of the Hijri month
     */
    __publicField(this, "startOfMonth", (date) => {
      const hijri = this.toHijri(date);
      if (!hijri) return startOfMonth(date);
      return this.fromHijri(hijri.year, hijri.month, 1);
    });
    /**
     * Gets the last day of the Hijri month
     * @param date - Date object
     * @returns Last day of the Hijri month (29th or 30th)
     */
    __publicField(this, "endOfMonth", (date) => {
      const hijri = this.toHijri(date);
      if (!hijri) return endOfMonth(date);
      const lastDay = this.getDaysInHijriMonth(hijri.year, hijri.month);
      return this.fromHijri(hijri.year, hijri.month, lastDay);
    });
    /**
     * Gets the number of days in the Hijri month
     * @param date - Date object
     * @returns Number of days in the month (29 or 30)
     */
    __publicField(this, "getDaysInMonth", (date) => {
      const hijri = this.toHijri(date);
      if (!hijri) return getDaysInMonth(date);
      return this.getDaysInHijriMonth(hijri.year, hijri.month);
    });
    __publicField(this, "getYearRange", (range) => {
      const [start, end] = range;
      let startDate = this.startOfYear(start);
      let endDate = this.endOfYear(end);
      const minDate = this.fromHijri(_HijriAdapter.MIN_HIJRI_YEAR, 1, 1);
      const maxDate = this.fromHijri(_HijriAdapter.MAX_HIJRI_YEAR, 12, 29);
      if (isBefore(startDate, minDate)) {
        startDate = minDate;
      }
      if (isAfter(endDate, maxDate)) {
        endDate = maxDate;
      }
      const years = [];
      let currentDate = startDate;
      let prevYear = -1;
      while (isBefore(currentDate, endDate) || isEqual(currentDate, endDate)) {
        const currentHijriYear = this.getYear(currentDate);
        if (currentHijriYear === prevYear) {
          break;
        }
        years.push(currentDate);
        prevYear = currentHijriYear;
        currentDate = this.addYears(currentDate, 1);
      }
      return years;
    });
    __publicField(this, "formatTokenMap", {
      // Year
      y: {
        sectionType: "year",
        contentType: "digit",
        maxLength: 4
      },
      yy: { sectionType: "year", contentType: "digit", maxLength: 2 },
      yyy: {
        sectionType: "year",
        contentType: "digit",
        maxLength: 4
      },
      yyyy: { sectionType: "year", contentType: "digit", maxLength: 4 },
      // Month
      M: { sectionType: "month", contentType: "digit", maxLength: 2 },
      MM: { sectionType: "month", contentType: "digit", maxLength: 2 },
      MMM: { sectionType: "month", contentType: "letter" },
      MMMM: { sectionType: "month", contentType: "letter" },
      L: {
        sectionType: "month",
        contentType: "digit",
        maxLength: 2
      },
      LL: "month",
      LLL: {
        sectionType: "month",
        contentType: "letter"
      },
      LLLL: {
        sectionType: "month",
        contentType: "letter"
      },
      // Day of the month
      d: {
        sectionType: "day",
        contentType: "digit",
        maxLength: 2
      },
      dd: "day",
      do: {
        sectionType: "day",
        contentType: "digit-with-letter"
      },
      // Day of the week
      E: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      EE: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      EEE: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      EEEE: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      EEEEE: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      i: {
        sectionType: "weekDay",
        contentType: "digit",
        maxLength: 1
      },
      ii: "weekDay",
      iii: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      iiii: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      // eslint-disable-next-line id-denylist
      e: {
        sectionType: "weekDay",
        contentType: "digit",
        maxLength: 1
      },
      ee: "weekDay",
      eee: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      eeee: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      eeeee: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      eeeeee: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      c: {
        sectionType: "weekDay",
        contentType: "digit",
        maxLength: 1
      },
      cc: "weekDay",
      ccc: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      cccc: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      ccccc: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      cccccc: {
        sectionType: "weekDay",
        contentType: "letter"
      },
      // Meridiem
      a: "meridiem",
      aa: "meridiem",
      aaa: "meridiem",
      // Hours
      H: {
        sectionType: "hours",
        contentType: "digit",
        maxLength: 2
      },
      HH: "hours",
      h: {
        sectionType: "hours",
        contentType: "digit",
        maxLength: 2
      },
      hh: "hours",
      // Minutes
      m: {
        sectionType: "minutes",
        contentType: "digit",
        maxLength: 2
      },
      mm: "minutes",
      // Seconds
      s: {
        sectionType: "seconds",
        contentType: "digit",
        maxLength: 2
      },
      ss: "seconds"
    });
    this.localeType = selectedLocale;
    this.locale = dateFnsLocale;
    this.getYear = (date) => {
      const hijri = this.toHijri(date);
      return hijri ? hijri.year : getYear(date);
    };
    this.getMonth = (date) => {
      const hijri = this.toHijri(date);
      return hijri ? hijri.month - 1 : getMonth(date);
    };
    this.getDate = (date) => {
      const hijri = this.toHijri(date);
      return hijri ? hijri.day : getDate(date);
    };
    this.startOfWeek = (date) => {
      return startOfWeek(date, { weekStartsOn: 0 });
    };
    this.endOfWeek = (date) => {
      return endOfWeek(date, { weekStartsOn: 0 });
    };
    this.getWeekNumber = (date) => {
      const startOfYear2 = new Date(date.getFullYear(), 0, 1);
      const pastDaysOfYear = (date.getTime() - startOfYear2.getTime()) / 864e5;
      return Math.ceil((pastDaysOfYear + startOfYear2.getDay() + 1) / 7);
    };
    this.getWeekdays = () => {
      const baseDate = new Date(2025, 8, 7);
      const weekdays = [];
      for (let i = 0; i < 7; i += 1) {
        const date = addDays(baseDate, i);
        weekdays.push(this.getWeekdayName(date, "narrow"));
      }
      return weekdays;
    };
    this.formatByString = (date, formatStr) => {
      if (!isValid(date)) {
        return "Invalid Date";
      }
      const hijri = this.toHijri(date);
      if (!hijri) {
        try {
          return format(date, formatStr, { locale: this.locale });
        } catch {
          return "Invalid Date";
        }
      }
      return this.formatHijriDate(hijri, date, formatStr);
    };
    this.format = (date, formatKey) => {
      if (typeof formatKey === "string") {
        switch (formatKey) {
          case "hours24h":
            return this.formatNumber(
              date.getHours().toString().padStart(2, "0")
            );
          case "hours12h": {
            const hours12 = date.getHours() % 12 || 12;
            return this.formatNumber(hours12.toString().padStart(2, "0"));
          }
          case "minutes":
            return this.formatNumber(
              date.getMinutes().toString().padStart(2, "0")
            );
          case "seconds":
            return this.formatNumber(
              date.getSeconds().toString().padStart(2, "0")
            );
        }
      }
      const formatString = this.getFormatString(formatKey);
      return this.formatByString(date, formatString);
    };
    this.formatNumber = (numberToFormat) => {
      const stringValue = String(numberToFormat);
      if (/^[0-9]+$/.test(stringValue)) {
        return this.localeType === "ar" ? this.toArabicNumerals(stringValue) : stringValue;
      }
      return stringValue;
    };
    this.formatBySection = (value) => {
      if (typeof value === "number") {
        const formattedValue = String(value).padStart(2, "0");
        return this.localeType === "ar" ? this.toArabicNumerals(formattedValue) : formattedValue;
      }
      return String(value);
    };
  }
  toHijri(date) {
    if (!date || !isValid(date)) return null;
    const year = getYear(date);
    const month = getMonth(date) + 1;
    const day = getDate(date);
    if (year < 1924 || year > 2077) {
      return null;
    }
    try {
      return gregorianToHijri({
        year,
        month,
        day
      });
    } catch (error) {
      return null;
    }
  }
  fromHijri(hijriYear, hijriMonth, hijriDay) {
    const clampedYear = this.clampHijriYear(hijriYear);
    const clampedMonth = Math.max(1, Math.min(12, hijriMonth));
    const maxDay = this.getDaysInHijriMonth(clampedYear, clampedMonth);
    const clampedDay = Math.max(1, Math.min(maxDay, hijriDay));
    const g = hijriToGregorian({
      year: clampedYear,
      month: clampedMonth,
      day: clampedDay
    });
    return new Date(g.year, g.month - 1, g.day);
  }
  /**
   * Clamps a Hijri year to the supported range of hijri-converter
   */
  clampHijriYear(year) {
    return Math.max(
      _HijriAdapter.MIN_HIJRI_YEAR,
      Math.min(_HijriAdapter.MAX_HIJRI_YEAR, year)
    );
  }
  /**
   * Gets the number of days in a Hijri month using Umm al-Qura data.
   * Implementation: probe from the longest valid month length downwards.
   * Some edge months in the converter's supported range are shorter than 29 days,
   * so the old "30 else 29" shortcut can overestimate the length and crash later.
   */
  getDaysInHijriMonth(year, month) {
    const clampedYear = this.clampHijriYear(year);
    for (let day = 30; day >= 1; day -= 1) {
      try {
        hijriToGregorian({ year: clampedYear, month, day });
        return day;
      } catch {
      }
    }
    return 1;
  }
  getFormatString(formatKey) {
    const formatMap = {
      // Date formats
      normalDate: "yyyy/MM/dd",
      normalDateWithWeekday: "yyyy/MM/dd",
      shortDate: "yyyy/MM/dd",
      fullDate: "yyyy/MM/dd",
      keyboardDate: "yyyy/MM/dd",
      // Time formats
      fullTime: "HH:mm:ss",
      fullTime12h: "hh:mm:ss a",
      fullTime24h: "HH:mm:ss",
      shortTime: "HH:mm",
      shortTime12h: "hh:mm a",
      shortTime24h: "HH:mm",
      // DateTime formats
      fullDateTime: "yyyy/MM/dd HH:mm",
      fullDateTime12h: "yyyy/MM/dd hh:mm a",
      fullDateTime24h: "yyyy/MM/dd HH:mm",
      keyboardDateTime: "yyyy/MM/dd HH:mm",
      keyboardDateTime12h: "yyyy/MM/dd hh:mm a",
      keyboardDateTime24h: "yyyy/MM/dd HH:mm",
      // Component formats
      year: "yyyy",
      month: "MMMM",
      monthShort: "MMM",
      monthAndYear: "MMMM yyyy",
      monthAndDate: "MMMM d",
      weekday: "EEEE",
      weekdayShort: "EEE",
      dayOfMonth: "d",
      // Time section formats for DateTimePicker
      hours24h: "HH",
      hours12h: "hh",
      minutes: "mm",
      seconds: "ss"
    };
    return formatMap[formatKey] || formatKey || "yyyy/MM/dd";
  }
  /**
   * Converts Western Arabic numerals to Eastern Arabic numerals
   */
  toArabicNumerals(num) {
    const arabicNumerals = ["\u0660", "\u0661", "\u0662", "\u0663", "\u0664", "\u0665", "\u0666", "\u0667", "\u0668", "\u0669"];
    return String(num).replace(
      /[0-9]/g,
      (digit) => arabicNumerals[parseInt(digit, 10)]
    );
  }
  getHijriMonthName(month, locale) {
    const currentLocale = locale || this.localeType;
    const monthNames = {
      en: [
        "Muharram",
        "Safar",
        "Rabi' al-awwal",
        "Rabi' al-thani",
        "Jumada al-awwal",
        "Jumada al-thani",
        "Rajab",
        "Sha'ban",
        "Ramadan",
        "Shawwal",
        "Dhu al-Qi'dah",
        "Dhu al-Hijjah"
      ],
      ar: [
        "\u0645\u062D\u0631\u0645",
        "\u0635\u0641\u0631",
        "\u0631\u0628\u064A\u0639 \u0627\u0644\u0623\u0648\u0644",
        "\u0631\u0628\u064A\u0639 \u0627\u0644\u062B\u0627\u0646\u064A",
        "\u062C\u0645\u0627\u062F\u0649 \u0627\u0644\u0623\u0648\u0644\u0649",
        "\u062C\u0645\u0627\u062F\u0649 \u0627\u0644\u062B\u0627\u0646\u064A\u0629",
        "\u0631\u062C\u0628",
        "\u0634\u0639\u0628\u0627\u0646",
        "\u0631\u0645\u0636\u0627\u0646",
        "\u0634\u0648\u0627\u0644",
        "\u0630\u0648 \u0627\u0644\u0642\u0639\u062F\u0629",
        "\u0630\u0648 \u0627\u0644\u062D\u062C\u0629"
      ]
    };
    return monthNames[currentLocale][month - 1] || "";
  }
  getWeekdayName(date, style) {
    const weekdayNames = {
      ar: {
        long: [
          "\u0627\u0644\u0623\u062D\u062F",
          "\u0627\u0644\u0625\u062B\u0646\u064A\u0646",
          "\u0627\u0644\u062B\u0644\u0627\u062B\u0627\u0621",
          "\u0627\u0644\u0623\u0631\u0628\u0639\u0627\u0621",
          "\u0627\u0644\u062E\u0645\u064A\u0633",
          "\u0627\u0644\u062C\u0645\u0639\u0629",
          "\u0627\u0644\u0633\u0628\u062A"
        ],
        short: ["\u0623\u062D\u062F", "\u0625\u062B\u0646\u064A\u0646", "\u062B\u0644\u0627\u062B\u0627\u0621", "\u0623\u0631\u0628\u0639\u0627\u0621", "\u062E\u0645\u064A\u0633", "\u062C\u0645\u0639\u0629", "\u0633\u0628\u062A"],
        narrow: ["\u062D", "\u0646", "\u062B", "\u0631", "\u062E", "\u062C", "\u0633"]
      },
      en: {
        long: [
          "Sunday",
          "Monday",
          "Tuesday",
          "Wednesday",
          "Thursday",
          "Friday",
          "Saturday"
        ],
        short: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
        narrow: ["S", "M", "T", "W", "T", "F", "S"]
      }
    };
    const dayOfWeek = date.getDay();
    const currentLocale = this.localeType;
    return weekdayNames[currentLocale][style][dayOfWeek] || weekdayNames.en[style][dayOfWeek];
  }
  /**
   * Formats a Hijri date according to the given format string
   */
  formatHijriDate(hijri, gregorianDate, formatStr) {
    let result = formatStr;
    result = this.formatDateComponents(result, hijri);
    result = this.formatTimeComponents(result, gregorianDate);
    result = this.formatWeekday(result, gregorianDate);
    return result;
  }
  /**
   * Formats date components (year, month, day) in the format string
   */
  formatDateComponents(formatStr, hijri) {
    let result = formatStr;
    result = result.replace(/yyyy/g, this.formatNumberValue(hijri.year, 4));
    result = result.replace(
      /yy/g,
      this.formatNumberValue(Number(String(hijri.year).slice(-2)), 2)
    );
    result = result.replace(/LLLL/g, this.getHijriMonthName(hijri.month));
    result = result.replace(/MMMM/g, this.getHijriMonthName(hijri.month));
    result = result.replace(
      /LLL/g,
      this.getHijriMonthName(hijri.month).slice(0, 3)
    );
    result = result.replace(
      /MMM/g,
      this.getHijriMonthName(hijri.month).slice(0, 3)
    );
    result = result.replace(/LL/g, this.formatNumberValue(hijri.month, 2));
    result = result.replace(/MM/g, this.formatNumberValue(hijri.month, 2));
    result = result.replace(/\bL\b/g, this.formatNumberValue(hijri.month));
    result = result.replace(/\bM\b/g, this.formatNumberValue(hijri.month));
    result = result.replace(/dd/g, this.formatNumberValue(hijri.day, 2));
    result = result.replace(/\bd\b/g, this.formatNumberValue(hijri.day));
    return result;
  }
  /**
   * Formats time components (hours, minutes, seconds, meridiem) in the format string
   */
  formatTimeComponents(formatStr, date) {
    let result = formatStr;
    const hours24 = date.getHours();
    const hours12 = this.get12HourFormat(hours24);
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();
    result = result.replace(/HH/g, this.formatNumberValue(hours24, 2));
    result = result.replace(/\bH\b/g, this.formatNumberValue(hours24));
    result = result.replace(/hh/g, this.formatNumberValue(hours12, 2));
    result = result.replace(/\bh\b/g, this.formatNumberValue(hours12));
    result = result.replace(/mm/g, this.formatNumberValue(minutes, 2));
    result = result.replace(/\bm\b/g, this.formatNumberValue(minutes));
    result = result.replace(/ss/g, this.formatNumberValue(seconds, 2));
    result = result.replace(/\bs\b/g, this.formatNumberValue(seconds));
    const meridiem = this.getMeridiem(hours24);
    result = result.replace(/\ba+\b/g, meridiem);
    return result;
  }
  /**
   * Formats weekday in the format string
   */
  formatWeekday(formatStr, date) {
    let result = formatStr;
    result = result.replace(/EEEE/g, this.getWeekdayName(date, "long"));
    result = result.replace(/EEE/g, this.getWeekdayName(date, "short"));
    result = result.replace(/\bE\b/g, this.getWeekdayName(date, "narrow"));
    return result;
  }
  /**
   * Formats a number value based on locale
   */
  formatNumberValue(num, padLength) {
    const formatted = padLength ? String(num).padStart(padLength, "0") : String(num);
    return this.localeType === "ar" ? this.toArabicNumerals(formatted) : formatted;
  }
  /**
   * Converts 24-hour format to 12-hour format
   */
  get12HourFormat(hours24) {
    if (hours24 === 0) {
      return 12;
    }
    if (hours24 > 12) {
      return hours24 - 12;
    }
    return hours24;
  }
  /**
   * Gets the meridiem (AM/PM) indicator
   */
  getMeridiem(hours24) {
    const isPM = hours24 >= 12;
    if (isPM) {
      return this.localeType === "ar" ? "\u0645" : "PM";
    }
    return this.localeType === "ar" ? "\u0635" : "AM";
  }
};
// hijri-converter supported date range (1343-1500 AH)
__publicField(_HijriAdapter, "MIN_HIJRI_YEAR", 1343);
__publicField(_HijriAdapter, "MAX_HIJRI_YEAR", 1500);
let HijriAdapter = _HijriAdapter;

export { HijriAdapter };
//# sourceMappingURL=HijriAdapter.js.map
