export { HijriAdapter } from './HijriAdapter.js';
//# sourceMappingURL=index.js.map
