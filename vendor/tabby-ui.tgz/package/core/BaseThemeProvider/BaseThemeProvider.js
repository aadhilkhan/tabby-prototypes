import createCache from '@emotion/cache';
import { CacheProvider } from '@emotion/react';
import React__default, { useEffect, useMemo } from 'react';
import { prefixer } from 'stylis';
import rtlPlugin from 'stylis-plugin-rtl';
import CssBaseline from '@mui/material/CssBaseline';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { deepmerge } from '@mui/utils';
import { useDir } from '../../hooks/useDir.js';
import { StyleWrapper } from '../../O25/StyleWrapper/StyleWrapper.js';
import { getKitThemeOptions } from '../../theme/theme.js';
import '../../theme/palette/paletteB23.js';

const SHOW_TUI_PARAM = "showTui";
function checkShowTUIParam() {
  const url = new URL(window.location.href);
  const showTui = url.searchParams.get(SHOW_TUI_PARAM);
  if (showTui && showTui === "1") {
    localStorage.setItem(SHOW_TUI_PARAM, "1");
  }
  if (showTui && showTui === "0") {
    localStorage.setItem(SHOW_TUI_PARAM, "0");
  }
  if (localStorage.getItem(SHOW_TUI_PARAM) === "1") {
    if (!document.body.classList.contains("showTui")) {
      document.body.classList.add("showTui");
    }
  } else {
    document.body.classList.remove("showTui");
  }
}
function BaseThemeProvider(props) {
  checkShowTUIParam();
  const {
    themeOptions: projectThemeOptions = {},
    kitThemeIsMain = false,
    setDirPropToBody = true,
    disableKitTheme = false,
    children,
    dir
  } = props;
  const direction = useDir(dir);
  useEffect(() => {
    if (setDirPropToBody) {
      document.dir = direction;
    }
  }, [setDirPropToBody, direction]);
  const cache = useMemo(
    () => createCache({
      key: `${direction}-direction`,
      prepend: true,
      stylisPlugins: direction === "rtl" ? [prefixer, rtlPlugin] : [prefixer]
    }),
    [direction]
  );
  const theme = useMemo(() => {
    let resultThemeOptions = {};
    if (disableKitTheme) {
      resultThemeOptions = projectThemeOptions;
    } else {
      resultThemeOptions = kitThemeIsMain ? deepmerge(projectThemeOptions, getKitThemeOptions(direction)) : deepmerge(getKitThemeOptions(direction), projectThemeOptions);
    }
    resultThemeOptions.direction = direction;
    return createTheme(resultThemeOptions);
  }, [direction, disableKitTheme, kitThemeIsMain, projectThemeOptions]);
  return /* @__PURE__ */ React__default.createElement(CacheProvider, { value: cache }, /* @__PURE__ */ React__default.createElement(ThemeProvider, { theme }, /* @__PURE__ */ React__default.createElement("style", null, `
            .showTui .Tui-Component {
              outline: 2px solid cyan !important;
            }
          `), /* @__PURE__ */ React__default.createElement(CssBaseline, null), /* @__PURE__ */ React__default.createElement(StyleWrapper, { dir: direction, setDocumentDir: false }, children)));
}

export { BaseThemeProvider };
//# sourceMappingURL=BaseThemeProvider.js.map
