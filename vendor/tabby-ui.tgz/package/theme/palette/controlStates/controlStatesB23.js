const controlStatesB23 = {
  light: {
    control: {
      primary: {
        front: {
          neutral: {
            default: "#ffffff"
          },
          positive: {
            default: "#ffffff"
          },
          negative: {
            default: "#ffffff"
          },
          warning: {
            default: "#ffffff"
          },
          highlight: {
            default: "#ffffff"
          },
          inverted: {
            default: "#1d2329"
          }
        },
        background: {
          neutral: {
            default: "#1d2329",
            hover: "#3e4a59"
          },
          positive: {
            default: "#179958",
            hover: "#31cc7e"
          },
          negative: {
            default: "#e81e40",
            hover: "#f26b7d"
          },
          warning: {
            default: "#f27f0c",
            hover: "#ffb17a"
          },
          highlight: {
            default: "#5d21de",
            hover: "#aa79f2"
          },
          inverted: {
            default: "#ffffff",
            hover: "#e9eff5"
          }
        }
      },
      secondary: {
        front: {
          neutral: {
            default: "#1d2329"
          },
          positive: {
            default: "#179958"
          },
          negative: {
            default: "#e81e40"
          },
          warning: {
            default: "#f27f0c"
          },
          highlight: {
            default: "#5d21de"
          },
          inverted: {
            default: "#d8e0eb"
          }
        },
        background: {
          neutral: {
            default: "#e9eff5",
            hover: "#d8e0eb"
          },
          positive: {
            default: "#edfaf1",
            hover: "#d1ffe0"
          },
          negative: {
            default: "#ffe6e3",
            hover: "#ffd0cc"
          },
          warning: {
            default: "#fffae0",
            hover: "#fff4bd"
          },
          highlight: {
            default: "#faf2ff",
            hover: "#f2e8ff"
          },
          inverted: {
            default: "#3e4a59",
            hover: "#2c3540"
          }
        }
      },
      tertiary: {
        front: {
          neutral: {
            default: "#1d2329"
          },
          positive: {
            default: "#179958"
          },
          negative: {
            default: "#e81e40"
          },
          warning: {
            default: "#f27f0c"
          },
          highlight: {
            default: "#5d21de"
          },
          inverted: {
            default: "#e9eff5"
          }
        },
        background: {
          neutral: {
            default: "transparent",
            hover: "#f2f5f7"
          },
          positive: {
            default: "transparent",
            hover: "#d1ffe0"
          },
          negative: {
            default: "transparent",
            hover: "#fff0ee"
          },
          warning: {
            default: "transparent",
            hover: "#fffae0"
          },
          highlight: {
            default: "transparent",
            hover: "#faf2ff"
          },
          inverted: {
            default: "transparent",
            hover: "#2c3540"
          }
        }
      }
    }
  },
  dark: {
    control: {
      primary: {
        front: {
          neutral: {
            default: "#1d2329"
          },
          positive: {
            default: "#004f25"
          },
          negative: {
            default: "#9e0020"
          },
          warning: {
            default: "#942f00"
          },
          highlight: {
            default: "#5d21de"
          },
          inverted: {
            default: "#ffffff"
          }
        },
        background: {
          neutral: {
            default: "#ffffff",
            hover: "#e9eff5"
          },
          positive: {
            default: "#77eda6",
            hover: "#31cc7e"
          },
          negative: {
            default: "#ffa9a8",
            hover: "#f26b7d"
          },
          warning: {
            default: "#ffd5b5",
            hover: "#ffb17a"
          },
          highlight: {
            default: "#e5d7fa",
            hover: "#ccb1fa"
          },
          inverted: {
            default: "#11151a",
            hover: "#3e4a59"
          }
        }
      },
      secondary: {
        front: {
          neutral: {
            default: "#d8e0eb"
          },
          positive: {
            default: "#d1ffe0"
          },
          negative: {
            default: "#ffe6e3"
          },
          warning: {
            default: "#ffe8d6"
          },
          highlight: {
            default: "#f2e8ff"
          },
          inverted: {
            default: "#1d2329"
          }
        },
        background: {
          neutral: {
            default: "#3e4a59",
            hover: "#2c3540"
          },
          positive: {
            default: "#004f25",
            hover: "#003615"
          },
          negative: {
            default: "#cc0836",
            hover: "#9e0020"
          },
          warning: {
            default: "#942f00",
            hover: "#6e1f00"
          },
          highlight: {
            default: "#5d21de",
            hover: "#3e1c9c"
          },
          inverted: {
            default: "#ffffff",
            hover: "#e9eff5"
          }
        }
      },
      tertiary: {
        front: {
          neutral: {
            default: "#e9eff5"
          },
          positive: {
            default: "#d1ffe0"
          },
          negative: {
            default: "#ffe6e3"
          },
          warning: {
            default: "#ffe8d6"
          },
          highlight: {
            default: "#f2e8ff"
          },
          inverted: {
            default: "#1d2329"
          }
        },
        background: {
          neutral: {
            default: "transparent",
            hover: "#2c3540"
          },
          positive: {
            default: "transparent",
            hover: "#004f25"
          },
          negative: {
            default: "transparent",
            hover: "#9e0020"
          },
          warning: {
            default: "transparent",
            hover: "#942f00"
          },
          highlight: {
            default: "transparent",
            hover: "#3e1c9c"
          },
          inverted: {
            default: "transparent",
            hover: "#f2f5f7"
          }
        }
      }
    }
  }
};

export { controlStatesB23 };
//# sourceMappingURL=controlStatesB23.js.map
