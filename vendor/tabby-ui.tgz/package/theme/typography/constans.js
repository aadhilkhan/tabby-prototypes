const FONT_FAMILY_RADIAL = "Radial";
const FONT_FAMILY_INTER = "Inter";
const FONT_FAMILY_IBM_PLEX = "IBM Plex Sans Arabic";
const FONT_FAMILY_GEIST = "Geist";

export { FONT_FAMILY_GEIST, FONT_FAMILY_IBM_PLEX, FONT_FAMILY_INTER, FONT_FAMILY_RADIAL };
//# sourceMappingURL=constans.js.map
