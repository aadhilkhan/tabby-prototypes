import Account48x48 from './Account48x48.js';
import Ads48x48 from './Ads48x48.js';
import BarChart248x48 from './BarChart248x48.js';
import Bell48x48 from './Bell48x48.js';
import Checkmark48x48 from './Checkmark48x48.js';
import CreditCard48x48 from './CreditCard48x48.js';
import Disputes48x48 from './Disputes48x48.js';
import Doc48x48 from './Doc48x48.js';
import Dollar48x48 from './Dollar48x48.js';
import Email48x48 from './Email48x48.js';
import FastForward48x48 from './FastForward48x48.js';
import FastForwardAR48x48 from './FastForwardAR48x48.js';
import Flag48x48 from './Flag48x48.js';
import Gift48x48 from './Gift48x48.js';
import Globe48x48 from './Globe48x48.js';
import Help48x48 from './Help48x48.js';
import Levels48x48 from './Levels48x48.js';
import Location48x48 from './Location48x48.js';
import Marketing48x48 from './Marketing48x48.js';
import MessageCircle48x48 from './MessageCircle48x48.js';
import Mobile48x48 from './Mobile48x48.js';
import Percent48x48 from './Percent48x48.js';
import Phone48x48 from './Phone48x48.js';
import PieChart48x48 from './PieChart48x48.js';
import Search48x48 from './Search48x48.js';
import Security48x48 from './Security48x48.js';
import ShoppingBag48x48 from './ShoppingBag48x48.js';
import Shuffle48x48 from './Shuffle48x48.js';
import SplitInFour48x48 from './SplitInFour48x48.js';
import Tag48x48 from './Tag48x48.js';
import Trend48x48 from './Trend48x48.js';
import UserCheck48x48 from './UserCheck48x48.js';
import UserPlus48x48 from './UserPlus48x48.js';
import Users48x48 from './Users48x48.js';
import _40days48x48 from './_40days48x48.js';

const allIcons = [
  { name: "Account48x48", Component: Account48x48 },
  { name: "Ads48x48", Component: Ads48x48 },
  { name: "BarChart248x48", Component: BarChart248x48 },
  { name: "Bell48x48", Component: Bell48x48 },
  { name: "Checkmark48x48", Component: Checkmark48x48 },
  { name: "CreditCard48x48", Component: CreditCard48x48 },
  { name: "Disputes48x48", Component: Disputes48x48 },
  { name: "Doc48x48", Component: Doc48x48 },
  { name: "Dollar48x48", Component: Dollar48x48 },
  { name: "Email48x48", Component: Email48x48 },
  { name: "FastForward48x48", Component: FastForward48x48 },
  { name: "FastForwardAR48x48", Component: FastForwardAR48x48 },
  { name: "Flag48x48", Component: Flag48x48 },
  { name: "Gift48x48", Component: Gift48x48 },
  { name: "Globe48x48", Component: Globe48x48 },
  { name: "Help48x48", Component: Help48x48 },
  { name: "Levels48x48", Component: Levels48x48 },
  { name: "Location48x48", Component: Location48x48 },
  { name: "Marketing48x48", Component: Marketing48x48 },
  { name: "MessageCircle48x48", Component: MessageCircle48x48 },
  { name: "Mobile48x48", Component: Mobile48x48 },
  { name: "Percent48x48", Component: Percent48x48 },
  { name: "Phone48x48", Component: Phone48x48 },
  { name: "PieChart48x48", Component: PieChart48x48 },
  { name: "Search48x48", Component: Search48x48 },
  { name: "Security48x48", Component: Security48x48 },
  { name: "ShoppingBag48x48", Component: ShoppingBag48x48 },
  { name: "Shuffle48x48", Component: Shuffle48x48 },
  { name: "SplitInFour48x48", Component: SplitInFour48x48 },
  { name: "Tag48x48", Component: Tag48x48 },
  { name: "Trend48x48", Component: Trend48x48 },
  { name: "UserCheck48x48", Component: UserCheck48x48 },
  { name: "UserPlus48x48", Component: UserPlus48x48 },
  { name: "Users48x48", Component: Users48x48 },
  { name: "_40days48x48", Component: _40days48x48 }
];

export { allIcons };
//# sourceMappingURL=allIcons.js.map
