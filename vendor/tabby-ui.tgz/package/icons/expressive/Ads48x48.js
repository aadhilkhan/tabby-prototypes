import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Ads48x48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Ads48x48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Ads48x48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Ads48x48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M22 10L12 18H4V30H12L22 38V10Z",
          stroke: "#1A1919",
          strokeWidth: "3",
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }
      ),
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M38.1401 9.85999C41.8895 13.6105 43.9958 18.6967 43.9958 24C43.9958 29.3033 41.8895 34.3894 38.1401 38.14M31.0801 16.92C32.9548 18.7953 34.0079 21.3383 34.0079 23.99C34.0079 26.6416 32.9548 29.1847 31.0801 31.06",
          stroke: "#1A1919",
          strokeWidth: "3",
          strokeLinecap: "round",
          strokeLinejoin: "round"
        }
      )
    )
  );
}

export { Ads48x48 as default };
//# sourceMappingURL=Ads48x48.js.map
