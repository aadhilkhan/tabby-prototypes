import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Image24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Image24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Image24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Image24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M18 2C20.2091 2 22 3.79086 22 6V18C22 18.0727 21.998 18.145 21.9941 18.2168L21.9971 18.2188C21.8985 20.0479 20.5706 21.5492 18.8252 21.9141C18.8174 21.9157 18.8096 21.9174 18.8018 21.9189C18.7449 21.9305 18.6876 21.9411 18.6299 21.9502C18.6221 21.9514 18.6143 21.9529 18.6064 21.9541C18.5602 21.9611 18.5136 21.9663 18.4668 21.9717C18.445 21.9742 18.4233 21.9773 18.4014 21.9795C18.3786 21.9817 18.3558 21.9835 18.333 21.9854C18.252 21.992 18.1702 21.9953 18.0879 21.9971C18.0596 21.9977 18.0313 22 18.0029 22H6C3.79086 22 2 20.2091 2 18V6C2 3.79086 3.79086 2 6 2H18ZM4.00293 16.4873V18C4.00293 19.1046 4.89836 20 6.00293 20H18C18.6718 20 19.2643 19.6673 19.627 19.1592L9.50293 13.3096L4.00293 16.4873ZM6 4C4.89543 4 4 4.89543 4 6V14.1787L9.50293 11L20 17.0645V6C20 4.89543 19.1046 4 18 4H6ZM16 6C17.1046 6 18 6.89543 18 8C18 9.10457 17.1046 10 16 10C14.8954 10 14 9.10457 14 8C14 6.89543 14.8954 6 16 6Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Image24 as default };
//# sourceMappingURL=Image24.js.map
