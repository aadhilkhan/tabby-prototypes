import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Copy24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Copy24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Copy24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Copy24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M12.5 8C14.433 8 16 9.567 16 11.5V17.5C16 19.433 14.433 21 12.5 21H6.5C4.567 21 3 19.433 3 17.5V11.5C3 9.567 4.567 8 6.5 8H12.5ZM6.5 10C5.67157 10 5 10.6716 5 11.5V17.5C5 18.3284 5.67157 19 6.5 19H12.5C13.3284 19 14 18.3284 14 17.5V11.5C14 10.6716 13.3284 10 12.5 10H6.5ZM17.5 3C19.433 3 21 4.56702 21 6.5V12.5C21 14.2632 19.6961 15.7222 18 15.9648V13.915C18.5826 13.7091 19 13.1531 19 12.5V6.5C19 5.67159 18.3284 5 17.5 5H11.5C10.8469 5 10.2909 5.4174 10.085 6H8.03516C8.27777 4.30385 9.73676 3 11.5 3H17.5Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Copy24 as default };
//# sourceMappingURL=Copy24.js.map
