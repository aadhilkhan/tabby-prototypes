import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function DutyFree24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("DutyFree24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-DutyFree24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-DutyFree24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M17.8286 2.60729C18.5829 1.81221 19.8444 1.79562 20.6194 2.57058C21.3943 3.34553 21.3777 4.60701 20.5826 5.36131L16.1404 9.57577L16.7206 11H11V14.4525L9.6755 15.7091L10.9393 20.1325C11.0221 20.4222 10.9413 20.734 10.7283 20.947C10.3581 21.3172 9.74186 21.2562 9.45148 20.8206L7.73905 18.2519C7.37015 17.6986 6.9475 17.183 6.47724 16.7128C6.00699 16.2425 5.49143 15.8199 4.93809 15.451L2.36944 13.7385C1.93387 13.4482 1.87285 12.8319 2.24301 12.4617C2.45604 12.2487 2.76781 12.1679 3.05749 12.2507L7.48077 13.5145L10.2433 10.6026L3.91458 5.47939C3.39456 5.05843 3.35369 4.27975 3.82678 3.80666C4.14739 3.48605 4.62891 3.38881 5.04881 3.55988L13.6142 7.0495L17.8286 2.60729ZM23 13V23H13V13H23ZM16.0554 14.7648V14.7648C16.0554 15.9019 16.926 16.8237 17.9999 16.8237C19.0738 16.8237 19.9443 15.9019 19.9443 14.7648V14.7648H16.0554Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { DutyFree24 as default };
//# sourceMappingURL=DutyFree24.js.map
