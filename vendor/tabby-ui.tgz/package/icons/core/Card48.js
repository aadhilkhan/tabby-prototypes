import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Card48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Card48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Card48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Card48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M39 12H9C7.34315 12 6 13.3431 6 15V16H42V15C42 13.3431 40.6569 12 39 12ZM42 22H6V33C6 34.6569 7.34315 36 9 36H39C40.6569 36 42 34.6569 42 33V22ZM9 9C5.68629 9 3 11.6863 3 15V33C3 36.3137 5.68629 39 9 39H39C42.3137 39 45 36.3137 45 33V15C45 11.6863 42.3137 9 39 9H9ZM21 30C22.1046 30 23 29.1046 23 28C23 26.8954 22.1046 26 21 26C19.8954 26 19 26.8954 19 28C19 29.1046 19.8954 30 21 30ZM38 26H26V30H38V26Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Card48 as default };
//# sourceMappingURL=Card48.js.map
