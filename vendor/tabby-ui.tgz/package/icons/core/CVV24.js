import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function CVV24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("CVV24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-CVV24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-CVV24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M3 4H16C16.5523 4 17 4.44771 17 5V6H2V5C2 4.44772 2.44772 4 3 4ZM2 9V14C2 14.5523 2.44772 15 3 15H6V17H3C1.34315 17 0 15.6569 0 14V5C0 3.34315 1.34315 2 3 2H16C17.6569 2 19 3.34315 19 5V9H17H6H2ZM22 14C22 13.4477 21.5523 13 21 13H11C10.4477 13 10 13.4477 10 14V19C10 19.5523 10.4477 20 11 20H21C21.5523 20 22 19.5523 22 19V14ZM11 11C9.34315 11 8 12.3431 8 14V19C8 20.6569 9.34315 22 11 22H21C22.6569 22 24 20.6569 24 19V14C24 12.3431 22.6569 11 21 11H11ZM20 16.5C20 17.0523 19.5523 17.5 19 17.5C18.4477 17.5 18 17.0523 18 16.5C18 15.9477 18.4477 15.5 19 15.5C19.5523 15.5 20 15.9477 20 16.5ZM16 17.5C16.5523 17.5 17 17.0523 17 16.5C17 15.9477 16.5523 15.5 16 15.5C15.4477 15.5 15 15.9477 15 16.5C15 17.0523 15.4477 17.5 16 17.5ZM14 16.5C14 17.0523 13.5523 17.5 13 17.5C12.4477 17.5 12 17.0523 12 16.5C12 15.9477 12.4477 15.5 13 15.5C13.5523 15.5 14 15.9477 14 16.5Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { CVV24 as default };
//# sourceMappingURL=CVV24.js.map
