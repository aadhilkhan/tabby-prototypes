import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function HomeRenovation24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("HomeRenovation24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-HomeRenovation24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-HomeRenovation24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M6 2C4.89543 2 4 2.89543 4 4V7C4 8.10457 4.89543 9 6 9H16C17.1046 9 18 8.10457 18 7V4C18 2.89543 17.1046 2 16 2H6ZM20 4C21.1046 4 22 4.89543 22 6V8C22 10.7614 19.7614 13 17 13H13C12.4477 13 12 13.4477 12 14V15H13V20C13 21.1046 12.1046 22 11 22C9.89543 22 9 21.1046 9 20V15H10V14C10 12.3431 11.3431 11 13 11H17C18.6569 11 20 9.65685 20 8V4Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { HomeRenovation24 as default };
//# sourceMappingURL=HomeRenovation24.js.map
