import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function GlobalTransfer48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("GlobalTransfer48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-GlobalTransfer48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-GlobalTransfer48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M9.53923 20C9.18777 21.2734 9 22.6148 9 24C9 25.3852 9.18777 26.7266 9.53923 28C9.72905 28.6877 9.96661 29.3557 10.2481 30C12.5628 35.2977 17.849 39 24 39C30.151 39 35.4372 35.2977 37.7519 30H32.2511C30.8623 35.2977 27.6906 39 24 39V37C26.7006 37 29.0441 34.1598 30.2115 30H24V28H30.6624C30.8816 26.7399 31 25.3956 31 24C31 22.6044 30.8816 21.2601 30.6624 20H24V18H30.2115C29.0441 13.8402 26.7006 11 24 11V9C27.6906 9 30.8623 12.7023 32.2511 18H37.7519C35.4372 12.7023 30.151 9 24 9C17.849 9 12.5628 12.7023 10.2481 18C9.96661 18.6443 9.72905 19.3123 9.53923 20ZM24 11V18H17.7885C18.9559 13.8402 21.2994 11 24 11ZM24 20V28H17.3376C17.1184 26.7399 17 25.3956 17 24C17 22.6044 17.1184 21.2601 17.3376 20H24ZM24 30H17.7885C18.9559 34.1598 21.2994 37 24 37V30ZM11 24C11 22.6044 11.2199 21.2601 11.627 20H15.3235C15.1127 21.2734 15 22.6148 15 24C15 25.3852 15.1127 26.7266 15.3235 28H11.627C11.2199 26.7399 11 25.3956 11 24ZM18.3906 35.7308C15.8487 34.5132 13.7641 32.4937 12.4644 30H15.7489C16.3394 32.2528 17.2524 34.2171 18.3906 35.7308ZM12.4644 18C13.7641 15.5063 15.8487 13.4868 18.3906 12.2691C17.2524 13.7829 16.3394 15.7472 15.7489 18H12.4644ZM38.4608 20H32.6765C32.8873 21.2734 33 22.6148 33 24C33 25.3852 32.8873 26.7266 32.6765 28H38.4608C38.8122 26.7266 39 25.3852 39 24C39 22.6148 38.8122 21.2734 38.4608 20Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { GlobalTransfer48 as default };
//# sourceMappingURL=GlobalTransfer48.js.map
