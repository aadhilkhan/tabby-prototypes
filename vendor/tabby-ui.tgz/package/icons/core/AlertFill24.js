import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function AlertFill24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("AlertFill24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-AlertFill24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-AlertFill24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M22 7.85742V16.1426L16.1426 22H7.85742L2 16.1426V7.85742L7.85742 2H16.1426L22 7.85742ZM12 15.333C11.2638 15.3332 10.667 15.9307 10.667 16.667C10.6672 17.4031 11.2639 17.9998 12 18C12.7361 17.9998 13.3338 17.4031 13.334 16.667C13.334 15.9307 12.7362 15.3332 12 15.333ZM10.667 13.333H13.334V6H10.667V13.333Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { AlertFill24 as default };
//# sourceMappingURL=AlertFill24.js.map
