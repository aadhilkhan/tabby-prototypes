import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Deal16(props) {
  const { dir, className, style = {}, color = "", size = 16, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Deal16");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Deal16 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Deal16",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M9.73 2.674 8 1 6.27 2.674l-2.385-.337-.416 2.371-2.127 1.129L2.4 8l-1.058 2.163 2.127 1.129.416 2.371 2.384-.337L8 15l1.731-1.674 2.384.337.416-2.371 2.127-1.129L13.6 8l1.057-2.163-2.127-1.129-.416-2.371zM11 5.901 5.901 11 5 10.099 10.099 5zM6.043 6.954a.911.911 0 1 0 0-1.822.911.911 0 0 0 0 1.822m3.824 3.824a.911.911 0 1 0 0-1.822.911.911 0 0 0 0 1.822",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { Deal16 as default };
//# sourceMappingURL=Deal16.js.map
