import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Gift16(props) {
  const { dir, className, style = {}, color = "", size = 16, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Gift16");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Gift16 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Gift16",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M6.5 1.5c.273 0 .536.044.782.125-.4.373-.705.846-.877 1.38A1 1 0 0 0 5.5 4H7a2.5 2.5 0 0 1 5 0h.5a2 2 0 0 1 2 2v1a2 2 0 0 1-1 1.732V12a2 2 0 0 1-2 2h-7a2 2 0 0 1-2-2V8.732A2 2 0 0 1 1.5 7V6a2 2 0 0 1 2-2H4a2.5 2.5 0 0 1 2.5-2.5m3 1.5a1 1 0 0 1 1 1h-2a1 1 0 0 1 1-1M3 6a.5.5 0 0 1 .5-.5h3.75v2H3.5A.5.5 0 0 1 3 7zm10 1a.5.5 0 0 1-.5.5H8.75v-2h3.75a.5.5 0 0 1 .5.5zm-8.5 5.5A.5.5 0 0 1 4 12V9h3.25v3.5zm7 0a.5.5 0 0 0 .5-.5V9H8.75v3.5z",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { Gift16 as default };
//# sourceMappingURL=Gift16.js.map
