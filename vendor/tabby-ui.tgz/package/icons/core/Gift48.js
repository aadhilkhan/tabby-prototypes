import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Gift48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Gift48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Gift48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Gift48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M7.83375 11.267L4.2015 14.8235C3.43307 15.576 3 16.6061 3 17.6816V18.9828C3 20.7687 4.18391 22.3383 5.90112 22.8289L7.09889 23.1711C8.81609 23.6617 10 25.2313 10 27.0172V44C10 46.2091 11.7909 48 14 48H35.3431C36.404 48 37.4214 47.5786 38.1716 46.8284L41.8284 43.1716C42.5786 42.4214 43 41.404 43 40.3431V14.125C43 11.9159 41.2091 10.125 39 10.125H10.6322C9.58596 10.125 8.58133 10.535 7.83375 11.267Z",
          fill: "black"
        }
      ),
      /* @__PURE__ */ React__default.createElement("g", { filter: "url(#filter0_d_20341_3336)" }, /* @__PURE__ */ React__default.createElement("rect", { x: "11", y: "14", width: "30", height: "4", fill: "white" }), /* @__PURE__ */ React__default.createElement(
        "rect",
        {
          x: "9",
          y: "12",
          width: "34",
          height: "8",
          stroke: "black",
          strokeWidth: "4",
          strokeLinejoin: "round"
        }
      )),
      /* @__PURE__ */ React__default.createElement("g", { filter: "url(#filter1_d_20341_3336)" }, /* @__PURE__ */ React__default.createElement("rect", { x: "13", y: "22", width: "26", height: "18", fill: "white" }), /* @__PURE__ */ React__default.createElement(
        "rect",
        {
          x: "11",
          y: "20",
          width: "30",
          height: "22",
          stroke: "black",
          strokeWidth: "4",
          strokeLinejoin: "round"
        }
      )),
      /* @__PURE__ */ React__default.createElement("path", { d: "M27 14V21", stroke: "black", strokeWidth: "4" }),
      /* @__PURE__ */ React__default.createElement("path", { d: "M25 20V44", stroke: "black", strokeWidth: "4" }),
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M28.8636 11.9958C33.7193 11.9958 38.8564 9.67216 36.3381 5.8078C34.3854 2.81135 29.3605 2.71169 25 12",
          stroke: "black",
          strokeWidth: "4"
        }
      ),
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M21.1364 11.9958C16.2807 11.9958 11.1436 9.67216 13.6619 5.8078C15.6146 2.81135 20.6395 2.71169 25 12",
          stroke: "black",
          strokeWidth: "4"
        }
      ),
      /* @__PURE__ */ React__default.createElement("defs", null, /* @__PURE__ */ React__default.createElement(
        "filter",
        {
          id: "filter0_d_20341_3336",
          x: "3",
          y: "10",
          width: "42",
          height: "16",
          filterUnits: "userSpaceOnUse",
          colorInterpolationFilters: "sRGB"
        },
        /* @__PURE__ */ React__default.createElement("feFlood", { floodOpacity: "0", result: "BackgroundImageFix" }),
        /* @__PURE__ */ React__default.createElement(
          "feColorMatrix",
          {
            in: "SourceAlpha",
            type: "matrix",
            values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
            result: "hardAlpha"
          }
        ),
        /* @__PURE__ */ React__default.createElement("feOffset", { dx: "-4", dy: "4" }),
        /* @__PURE__ */ React__default.createElement("feComposite", { in2: "hardAlpha", operator: "out" }),
        /* @__PURE__ */ React__default.createElement(
          "feColorMatrix",
          {
            type: "matrix",
            values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0"
          }
        ),
        /* @__PURE__ */ React__default.createElement(
          "feBlend",
          {
            mode: "normal",
            in2: "BackgroundImageFix",
            result: "effect1_dropShadow_20341_3336"
          }
        ),
        /* @__PURE__ */ React__default.createElement(
          "feBlend",
          {
            mode: "normal",
            in: "SourceGraphic",
            in2: "effect1_dropShadow_20341_3336",
            result: "shape"
          }
        )
      ), /* @__PURE__ */ React__default.createElement(
        "filter",
        {
          id: "filter1_d_20341_3336",
          x: "5",
          y: "18",
          width: "38",
          height: "30",
          filterUnits: "userSpaceOnUse",
          colorInterpolationFilters: "sRGB"
        },
        /* @__PURE__ */ React__default.createElement("feFlood", { floodOpacity: "0", result: "BackgroundImageFix" }),
        /* @__PURE__ */ React__default.createElement(
          "feColorMatrix",
          {
            in: "SourceAlpha",
            type: "matrix",
            values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0",
            result: "hardAlpha"
          }
        ),
        /* @__PURE__ */ React__default.createElement("feOffset", { dx: "-4", dy: "4" }),
        /* @__PURE__ */ React__default.createElement("feComposite", { in2: "hardAlpha", operator: "out" }),
        /* @__PURE__ */ React__default.createElement(
          "feColorMatrix",
          {
            type: "matrix",
            values: "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0"
          }
        ),
        /* @__PURE__ */ React__default.createElement(
          "feBlend",
          {
            mode: "normal",
            in2: "BackgroundImageFix",
            result: "effect1_dropShadow_20341_3336"
          }
        ),
        /* @__PURE__ */ React__default.createElement(
          "feBlend",
          {
            mode: "normal",
            in: "SourceGraphic",
            in2: "effect1_dropShadow_20341_3336",
            result: "shape"
          }
        )
      ))
    )
  );
}

export { Gift48 as default };
//# sourceMappingURL=Gift48.js.map
