import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Feedback48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Feedback48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Feedback48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Feedback48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M38.2816 33.2258L37.4825 34.4599L39.1101 39.1101L34.4599 37.4825L33.2258 38.2816C30.5702 40.0013 27.4063 41 24 41C14.6112 41 7 33.3888 7 24C7 14.6112 14.6112 7 24 7C33.3888 7 41 14.6112 41 24C41 27.4063 40.0013 30.5702 38.2816 33.2258ZM34.8565 40.7998L44 44L40.7998 34.8565C42.8244 31.7299 44 28.0022 44 24C44 12.9543 35.0457 4 24 4C12.9543 4 4 12.9543 4 24C4 35.0457 12.9543 44 24 44C28.0022 44 31.7299 42.8244 34.8565 40.7998ZM23.084 18.2436C21.2347 16.3854 18.2415 16.3854 16.3922 18.2436C14.5359 20.1087 14.5359 23.1381 16.3922 25.0033L23.1684 31.8118C23.3998 32.0443 23.7033 32.1553 24 32.1498C24.2967 32.1553 24.6002 32.0443 24.8316 31.8118L31.6078 25.0033C33.4641 23.1381 33.4641 20.1087 31.6078 18.2436C29.7585 16.3854 26.7653 16.3854 24.916 18.2436L24 19.1639L23.084 18.2436Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Feedback48 as default };
//# sourceMappingURL=Feedback48.js.map
