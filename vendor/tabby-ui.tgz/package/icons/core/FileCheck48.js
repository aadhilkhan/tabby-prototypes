import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function FileCheck48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("FileCheck48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-FileCheck48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-FileCheck48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M25 4.00781H26.3506C27.4115 4.00781 28.4295 4.42954 29.1797 5.17969L38.8281 14.8281C39.5783 15.5783 40 16.5964 40 17.6572V38C40 41.3137 37.3137 44 34 44H14C10.6863 44 8 41.3137 8 38V10C8 6.68629 10.6863 4 14 4H25V4.00781ZM14 7C12.3431 7 11 8.34315 11 10V38C11 39.6569 12.3431 41 14 41H34C35.6569 41 37 39.6569 37 38V19H29C26.7909 19 25 17.2091 25 15V7H14ZM32.3506 25.1211L22.4688 35.0039L22.4648 35L22.4629 35.002L16.3496 28.8887L18.4707 26.7676L22.4658 30.7627L30.2295 23L32.3506 25.1211ZM28 15C28 15.5523 28.4477 16 29 16H35.7578L28 8.24219V15Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { FileCheck48 as default };
//# sourceMappingURL=FileCheck48.js.map
