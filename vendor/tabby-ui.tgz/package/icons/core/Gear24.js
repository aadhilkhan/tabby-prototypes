import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Gear24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Gear24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Gear24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Gear24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M12.7197 2C13.1783 2.00027 13.5782 2.31284 13.6895 2.75781L14.166 4.66797C14.329 5.3191 15.0747 5.62735 15.6504 5.28223L17.3408 4.26953C17.7341 4.0338 18.2381 4.09591 18.5625 4.41992L19.5801 5.4375C19.9042 5.76192 19.9663 6.26585 19.7305 6.65918L18.7168 8.34766C18.3713 8.92335 18.6798 9.66891 19.3311 9.83203L21.2432 10.3105C21.6878 10.422 21.9998 10.8218 22 11.2803V12.7188C22 13.1774 21.688 13.5779 21.2432 13.6895L19.3311 14.167C18.6795 14.3297 18.3705 15.0755 18.7158 15.6514L19.7305 17.3408C19.9663 17.7341 19.9042 18.2381 19.5801 18.5625L18.5625 19.5801C18.2381 19.9041 17.7341 19.9662 17.3408 19.7305L15.6514 18.7168C15.0756 18.3711 14.329 18.6796 14.166 19.3311L13.6895 21.2422C13.5782 21.6872 13.1783 21.9997 12.7197 22H11.2812C10.8224 22 10.4219 21.6873 10.3105 21.2422L9.83203 19.3311C9.66901 18.6795 8.92244 18.371 8.34668 18.7168L6.65918 19.7305C6.26588 19.9662 5.76186 19.9042 5.4375 19.5801L4.4209 18.5625C4.09643 18.238 4.03442 17.7343 4.27051 17.3408L5.2832 15.6514C5.62844 15.0755 5.31933 14.3298 4.66797 14.167L2.75781 13.6895C2.31265 13.5782 1.99902 13.1776 1.99902 12.7188V11.2803C1.99924 10.8216 2.31281 10.4218 2.75781 10.3105L4.66797 9.83203C5.31928 9.66905 5.62857 8.92341 5.2832 8.34766L4.27051 6.65918C4.03442 6.2657 4.09643 5.76197 4.4209 5.4375L5.4375 4.41992C5.76188 4.09583 6.26588 4.03378 6.65918 4.26953L8.34766 5.28223C8.92335 5.62756 9.66896 5.31917 9.83203 4.66797L10.3105 2.75781C10.4219 2.31271 10.8224 2 11.2812 2H12.7197ZM12 8C9.79086 8 8 9.79086 8 12C8 14.2091 9.79086 16 12 16C14.2091 16 16 14.2091 16 12C16 9.79086 14.2091 8 12 8Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Gear24 as default };
//# sourceMappingURL=Gear24.js.map
