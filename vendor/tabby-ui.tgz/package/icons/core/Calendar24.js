import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Calendar24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Calendar24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Calendar24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Calendar24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M10 2H8V4H7C4.79086 4 3 5.79086 3 8V17C3 19.2091 4.79086 21 7 21H17C19.2091 21 21 19.2091 21 17V8C21 5.79086 19.2091 4 17 4H16V2H14V4H10V2ZM14 8V6H10V8H8V6H7C5.89543 6 5 6.89543 5 8V17C5 18.1046 5.89543 19 7 19H17C18.1046 19 19 18.1046 19 17V8C19 6.89543 18.1046 6 17 6H16V8H14ZM9 16V14H7V16H9ZM11 10H13V12H11V10ZM9 12V10H7V12H9ZM11 14H13V16H11V14ZM17 12V10H15V12H17Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Calendar24 as default };
//# sourceMappingURL=Calendar24.js.map
