import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function ClockCrossedOut24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("ClockCrossedOut24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-ClockCrossedOut24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-ClockCrossedOut24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M20.3408 6.48633C21.3879 8.06731 22 9.96171 22 12C22 17.5228 17.5228 22 12 22C9.96171 22 8.06731 21.3879 6.48633 20.3408L7.93652 18.8906C9.12774 19.5944 10.5162 20 12 20C16.4183 20 20 16.4183 20 12C20 10.5162 19.5944 9.12774 18.8906 7.93652L20.3408 6.48633ZM12 2C14.0378 2 15.932 2.61149 17.5127 3.6582L19.0713 2.10059L20.4854 3.51465L11.2852 12.7139L8.72754 15.2725L3.51465 20.4854L2.10059 19.0713L3.6582 17.5127C2.61149 15.932 2 14.0378 2 12C2 6.47715 6.47715 2 12 2ZM12 4C7.58172 4 4 7.58172 4 12C4 13.4833 4.40489 14.8716 5.1084 16.0625L11 10.1719V6H13V8.17188L16.0625 5.1084C14.8716 4.40489 13.4833 4 12 4ZM16.5996 14.2002L15.4004 15.7998L12.9014 13.9258L14.3301 12.4971L16.5996 14.2002Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { ClockCrossedOut24 as default };
//# sourceMappingURL=ClockCrossedOut24.js.map
