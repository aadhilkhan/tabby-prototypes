import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function FaceID48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("FaceID48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-FaceID48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-FaceID48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M8 38C8 39.1046 8.89543 40 10 40H16V43H10C7.23858 43 5 40.7614 5 38V32H8V38ZM43 38C43 40.7614 40.7614 43 38 43H32V40H38C39.1046 40 40 39.1046 40 38V32H43V38ZM34.5352 32.04C31.7206 34.5047 28.0351 36 24 36C19.9646 36 16.2785 34.5051 13.4639 32.04L15.4414 29.7812C17.7282 31.7838 20.7215 33 24 33C27.2782 33 30.2709 31.7835 32.5576 29.7812L34.5352 32.04ZM25 25H27V28H22V20H25V25ZM18 22H15V15H18V22ZM33 22H30V15H33V22ZM16 8H10C8.89543 8 8 8.89543 8 10V16H5V10C5 7.23858 7.23858 5 10 5H16V8ZM38 5C40.7614 5 43 7.23858 43 10V16H40V10C40 8.89543 39.1046 8 38 8H32V5H38Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { FaceID48 as default };
//# sourceMappingURL=FaceID48.js.map
