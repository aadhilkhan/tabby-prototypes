import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function BrokenHeartFill24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("BrokenHeartFill24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-BrokenHeartFill24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-BrokenHeartFill24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M10.9822 5.54844C8.92745 3.48385 5.60169 3.48385 3.54691 5.54844C1.48436 7.62083 1.48436 10.9868 3.54691 13.0592L11.076 20.6242C11.3331 20.8825 11.6704 21.0059 12 20.9998C12.3296 21.0059 12.6669 20.8826 12.924 20.6242L20.4531 13.0592C22.5156 10.9868 22.5156 7.62083 20.4531 5.54844C18.6929 3.7799 16.0002 3.52631 13.9726 4.78765L16.5 9L13 11L15 14L12 17L13 14L10 10.5L13.5 8.5L11.9987 6.56976L10.9822 5.54844Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { BrokenHeartFill24 as default };
//# sourceMappingURL=BrokenHeartFill24.js.map
