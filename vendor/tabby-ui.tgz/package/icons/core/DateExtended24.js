import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function DateExtended24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("DateExtended24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-DateExtended24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-DateExtended24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M9 2H7V4H6C3.79086 4 2 5.79086 2 8V17C2 19.2091 3.79086 21 6 21H10.0703C9.71218 20.381 9.43466 19.7095 9.25204 19H6C4.89543 19 4 18.1046 4 17V8C4 6.89543 4.89543 6 6 6H7V8H9V6H13V8H15V6H16C17.1046 6 18 6.89543 18 8V9.06189C18.6986 9.14901 19.3693 9.32622 20 9.58152V8C20 5.79086 18.2091 4 16 4H15V2H13V4H9V2ZM17 23C20.3137 23 23 20.3137 23 17C23 13.6863 20.3137 11 17 11C13.6863 11 11 13.6863 11 17C11 20.3137 13.6863 23 17 23ZM19.6513 14.3054L20.712 15.3661L17.1764 18.9016L16.1158 19.9623L15.0551 18.9016L13.2874 17.1339L14.348 16.0732L16.1158 17.841L19.6513 14.3054ZM8 14H6V16H8V14ZM10 10H12V12H10V10ZM8 12V10H6V12H8Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { DateExtended24 as default };
//# sourceMappingURL=DateExtended24.js.map
