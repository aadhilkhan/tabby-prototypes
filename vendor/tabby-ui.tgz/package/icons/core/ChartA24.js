import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function ChartA24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("ChartA24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-ChartA24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-ChartA24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M21 3H18V21H21V3ZM11 13H8V21H11V13ZM13 8H16V21H13V8ZM6 16H3V21H6V16Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { ChartA24 as default };
//# sourceMappingURL=ChartA24.js.map
