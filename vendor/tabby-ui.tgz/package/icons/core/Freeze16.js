import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Freeze16(props) {
  const { dir, className, style = {}, color = "", size = 16, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Freeze16");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Freeze16 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Freeze16",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M8.667 1.333H7.333l.059 1.668L6.35 1.96l-.707.707 1.8 1.8L7.54 7.2l-2.32-1.45-.055-.205-.604-2.254-.966.259.381 1.423-1.415-.885-.667 1.155 1.474.783-1.423.382.259.966 2.459-.66L7.078 8 4.662 9.284l-2.46-.659-.258.966 1.423.382-1.474.783.667 1.155 1.415-.885-.381 1.423.966.259.604-2.254.055-.205 2.32-1.45-.096 2.734-1.8 1.8.707.707L7.392 13l-.059 1.668h1.334l-.059-1.668L9.65 14.04l.707-.707-1.65-1.65-.15-.15L8.461 8.8l2.32 1.45.055.205.604 2.254.966-.259-.381-1.423 1.415.885.667-1.155-1.474-.783 1.423-.382-.259-.966-2.254.604-.204.055L8.923 8l2.416-1.284.205.055 2.253.604.26-.966-1.424-.382 1.474-.783-.667-1.155-1.415.885.381-1.423-.966-.259-.658 2.459-2.32 1.45.095-2.734.15-.15 1.65-1.65-.707-.707L8.608 3z",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { Freeze16 as default };
//# sourceMappingURL=Freeze16.js.map
