import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Copy16(props) {
  const { dir, className, style = {}, color = "", size = 16, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Copy16");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Copy16 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Copy16",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M8 1a3 3 0 0 0-2.958 2.5H6.89c.221-.445.68-.75 1.21-.75h3.8c.746 0 1.35.604 1.35 1.35v3.8c0 .53-.306.989-.75 1.21v1.849A3 3 0 0 0 15 8V4a3 3 0 0 0-3-3zM1 8a3 3 0 0 1 3-3h4a3 3 0 0 1 3 3v4a3 3 0 0 1-3 3H4a3 3 0 0 1-3-3zm1.75.1c0-.746.604-1.35 1.35-1.35h3.8c.746 0 1.35.604 1.35 1.35v3.8a1.35 1.35 0 0 1-1.35 1.35H4.1a1.35 1.35 0 0 1-1.35-1.35z",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { Copy16 as default };
//# sourceMappingURL=Copy16.js.map
