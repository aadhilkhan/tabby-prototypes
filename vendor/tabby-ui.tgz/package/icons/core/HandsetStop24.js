import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function HandsetStop24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("HandsetStop24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-HandsetStop24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-HandsetStop24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M22.1515 17.0465C21.9532 17.2999 21.6786 17.4829 21.3683 17.5683C21.058 17.6537 20.7285 17.6371 20.4284 17.5209L15.8346 15.8906L15.8074 15.8802C15.5777 15.7883 15.3743 15.641 15.2153 15.4514C15.0563 15.2619 14.9467 15.0359 14.8962 14.7937L14.314 12.0046C12.8036 11.49 11.1647 11.4936 9.65651 12.0149L9.10339 14.7824C9.0546 15.0273 8.94545 15.2562 8.78583 15.4482C8.62621 15.6402 8.42118 15.7894 8.18932 15.8821L8.16214 15.8924L3.56839 17.5209C3.39787 17.5881 3.21635 17.623 3.03307 17.624C2.80493 17.6244 2.5797 17.5728 2.37451 17.473C2.16933 17.3733 1.9896 17.228 1.84901 17.0484C0.233699 14.9652 0.414636 12.2006 2.2887 10.3256C7.55276 5.05961 16.4449 5.05961 21.7118 10.3256C23.5859 12.1987 23.7668 14.9634 22.1515 17.0465Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { HandsetStop24 as default };
//# sourceMappingURL=HandsetStop24.js.map
