import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Breadcrumbs24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Breadcrumbs24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Breadcrumbs24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Breadcrumbs24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M8.24269 10.5858L8.24267 10.5858L5.41421 7.75732L4 9.17154L6.82846 12L4.00005 14.8284L5.41427 16.2426L9.65691 12L8.24269 10.5858ZM14.2427 10.5858L14.2427 10.5858L15.6569 12L11.4143 16.2426L10.0001 14.8284L12.8285 12L10 9.17154L11.4142 7.75732L14.2427 10.5858ZM20.2428 10.5858L20.2428 10.5858L21.657 12L17.4143 16.2426L16.0001 14.8284L18.8285 12L16.0001 9.17154L17.4143 7.75732L20.2428 10.5858Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Breadcrumbs24 as default };
//# sourceMappingURL=Breadcrumbs24.js.map
