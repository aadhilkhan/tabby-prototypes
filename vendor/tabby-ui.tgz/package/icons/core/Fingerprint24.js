import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Fingerprint24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Fingerprint24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Fingerprint24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Fingerprint24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M3 12C3 7.02944 7.02944 3 12 3C13.1917 3 14.3316 3.23213 15.3752 3.65458C15.8871 3.8618 16.1342 4.4448 15.9269 4.95673C15.7197 5.46867 15.1367 5.71568 14.6248 5.50845C13.8155 5.18088 12.9301 5 12 5C8.13401 5 5 8.13401 5 12V17C5 17.5523 4.55228 18 4 18C3.44772 18 3 17.5523 3 17V12ZM17.6199 6.21975C18.0508 5.87431 18.6802 5.94361 19.0256 6.37453C20.2606 7.91514 21 9.87259 21 12V17C21 17.5523 20.5523 18 20 18C19.4477 18 19 17.5523 19 17V12C19 10.3436 18.4259 8.82406 17.4651 7.62547C17.1197 7.19455 17.189 6.56519 17.6199 6.21975ZM7 12C7 9.23858 9.23858 7 12 7C14.7614 7 17 9.23858 17 12V20C17 20.5523 16.5523 21 16 21C15.4477 21 15 20.5523 15 20V12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 12.5523 8.55228 13 8 13C7.44772 13 7 12.5523 7 12ZM8 15C8.55228 15 9 15.4477 9 16V20C9 20.5523 8.55228 21 8 21C7.44772 21 7 20.5523 7 20V16C7 15.4477 7.44772 15 8 15ZM12 11C11.4477 11 11 11.4477 11 12V21C11 21.5523 11.4477 22 12 22C12.5523 22 13 21.5523 13 21V12C13 11.4477 12.5523 11 12 11Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Fingerprint24 as default };
//# sourceMappingURL=Fingerprint24.js.map
