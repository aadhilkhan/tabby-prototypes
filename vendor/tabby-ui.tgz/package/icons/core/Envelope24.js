import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Envelope24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Envelope24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Envelope24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Envelope24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M19 6C19.0942 6 19.1853 6.01302 19.2717 6.03735L13.4428 12.1092C12.6557 12.9291 11.3443 12.9291 10.5572 12.1092L4.72829 6.03735C4.81469 6.01302 4.90582 6 5 6H19ZM14.8855 13.4942L20 8.16667V16L17.0473 13.0474L15.7873 14.3599C15.7454 14.4036 15.7029 14.4464 15.6598 14.4883L19.159 17.9874C19.1072 17.9957 19.0541 18 19 18H5C4.9459 18 4.89281 17.9957 4.84104 17.9874L8.34019 14.4883C8.29716 14.4464 8.25467 14.4036 8.21275 14.3599L6.95268 13.0474L4 16V8.16667L9.11445 13.4942C10.6887 15.1341 13.3113 15.134 14.8855 13.4942ZM2 7C2 6.72174 2.03788 6.45233 2.10878 6.19664C2.46 4.92988 3.62141 4 5 4H19C20.3786 4 21.54 4.92988 21.8912 6.19664C21.9621 6.45233 22 6.72174 22 7V17C22 17.3031 21.9551 17.5957 21.8715 17.8715C21.4981 19.1033 20.3538 20 19 20H5C3.64625 20 2.50192 19.1033 2.12855 17.8715C2.04495 17.5957 2 17.3031 2 17V7Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Envelope24 as default };
//# sourceMappingURL=Envelope24.js.map
