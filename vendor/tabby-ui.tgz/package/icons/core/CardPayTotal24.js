import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function CardPayTotal24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("CardPayTotal24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-CardPayTotal24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-CardPayTotal24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M18 11C21.3137 11 24 13.6863 24 17C24 20.3137 21.3137 23 18 23C14.6863 23 12 20.3137 12 17C12 13.6863 14.6863 11 18 11ZM17.1162 17.8408L15.3477 16.0732L14.2871 17.1338L17.1162 19.9619L21.7119 15.3662L20.6514 14.3057L17.1162 17.8408ZM16 2C17.6569 2 19 3.34315 19 5V9.06348C18.6723 9.02261 18.3387 9 18 9H2V14C2 14.5523 2.44772 15 3 15H10.2549C10.0901 15.6394 10 16.3091 10 17H3C1.34315 17 0 15.6569 0 14V5C0 3.34315 1.34315 2 3 2H16ZM3 4C2.44772 4 2 4.44772 2 5V6H17V5C17 4.44771 16.5523 4 16 4H3Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { CardPayTotal24 as default };
//# sourceMappingURL=CardPayTotal24.js.map
