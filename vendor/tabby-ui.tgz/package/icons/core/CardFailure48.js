import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function CardFailure48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("CardFailure48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-CardFailure48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-CardFailure48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M36 24C41.5228 24 46 28.4772 46 34C46 39.5228 41.5228 44 36 44C30.4772 44 26 39.5228 26 34C26 28.4772 30.4772 24 36 24ZM36 27C32.134 27 29 30.134 29 34C29 37.866 32.134 41 36 41C39.866 41 43 37.866 43 34C43 30.134 39.866 27 36 27ZM36 36.5C36.8284 36.5 37.5 37.1716 37.5 38C37.5 38.8284 36.8284 39.5 36 39.5C35.1716 39.5 34.5 38.8284 34.5 38C34.5 37.1716 35.1716 36.5 36 36.5ZM36 8C39.3137 8 42 10.6863 42 14V22.4648C40.2049 21.5292 38.1643 21 36 21H5V32C5 33.6569 6.34315 35 8 35H23.0381C23.1171 36.0389 23.318 37.0437 23.627 38H8C4.68629 38 2 35.3137 2 32V14C2 10.6863 4.68629 8 8 8H36ZM37.25 35H34.75V29H37.25V35ZM21 28H9V25H21V28ZM8 11C6.34315 11 5 12.3431 5 14V15H39V14C39 12.3431 37.6569 11 36 11H8Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { CardFailure48 as default };
//# sourceMappingURL=CardFailure48.js.map
