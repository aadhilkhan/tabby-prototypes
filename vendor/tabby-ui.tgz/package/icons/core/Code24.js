import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Code24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Code24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Code24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Code24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M13.3833 3L8.69995 20.4783L10.6318 20.996L15.3151 3.51764L13.3833 3ZM21.5814 10.5818L17.9996 6.99995L16.5842 8.41531L20.1661 11.9972L16.5819 15.5813L17.9966 16.996L22.9961 11.9965L21.5815 10.5818L21.5814 10.5818ZM2.41472 10.5818L5.99658 6.99998L7.41194 8.41534L3.83008 11.9972L7.41423 15.5814L5.99954 16.996L1 11.9965L2.41469 10.5818L2.41472 10.5818Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Code24 as default };
//# sourceMappingURL=Code24.js.map
