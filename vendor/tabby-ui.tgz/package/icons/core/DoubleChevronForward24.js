import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function DoubleChevronForward24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("DoubleChevronForward24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-DoubleChevronForward24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-DoubleChevronForward24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M5.92883 7.75748L10.1715 12.0002L5.92889 16.2428L7.3431 17.657L13 12.0001L11.5857 10.5859L11.5857 10.5859L7.34305 6.34326L5.92883 7.75748ZM11.9288 7.75748L16.1715 12.0002L11.9289 16.2428L13.3431 17.657L19 12.0001L17.5857 10.5859L17.5857 10.5859L13.343 6.34326L11.9288 7.75748Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { DoubleChevronForward24 as default };
//# sourceMappingURL=DoubleChevronForward24.js.map
