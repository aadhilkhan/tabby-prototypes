import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Beauty24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Beauty24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Beauty24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Beauty24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M10.2527 12.656L8.06627 15.4106C7.69062 15.2629 7.28226 15.1818 6.85526 15.1818C5.0022 15.1818 3.5 16.7081 3.5 18.5909C3.5 20.4737 5.0022 22 6.85526 22C8.70832 22 10.2105 20.4737 10.2105 18.5909C10.2105 18.0938 10.1058 17.6216 9.91759 17.1957L12 14.7273L14.0824 17.1958C13.8942 17.6216 13.7895 18.0939 13.7895 18.591C13.7895 20.4738 15.2917 22.0001 17.1447 22.0001C18.9978 22.0001 20.5 20.4738 20.5 18.591C20.5 16.7082 18.9978 15.1819 17.1447 15.1819C16.7178 15.1819 16.3094 15.2629 15.9338 15.4107L5.28946 2C4.46594 3.95237 4.80775 6.20172 6.17406 7.82132L10.2527 12.656ZM14.8106 11.3956L17.8259 7.82132C19.1922 6.20172 19.534 3.95237 18.7105 2L13.0319 9.1545L14.8106 11.3956ZM8.64474 18.5908C8.64474 19.595 7.84356 20.409 6.85526 20.409C5.86696 20.409 5.06579 19.595 5.06579 18.5908C5.06579 17.5867 5.86696 16.7726 6.85526 16.7726C7.84356 16.7726 8.64474 17.5867 8.64474 18.5908ZM18.9342 18.5909C18.9342 19.595 18.133 20.4091 17.1447 20.4091C16.1564 20.4091 15.3552 19.595 15.3552 18.5909C15.3552 17.5867 16.1564 16.7727 17.1447 16.7727C18.133 16.7727 18.9342 17.5867 18.9342 18.5909ZM12.671 12.4545C12.671 12.8311 12.3706 13.1363 12 13.1363C11.6294 13.1363 11.3289 12.8311 11.3289 12.4545C11.3289 12.078 11.6294 11.7727 12 11.7727C12.3706 11.7727 12.671 12.078 12.671 12.4545Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Beauty24 as default };
//# sourceMappingURL=Beauty24.js.map
