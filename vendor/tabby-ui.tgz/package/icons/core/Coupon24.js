import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Coupon24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Coupon24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Coupon24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Coupon24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M18 5H13.2427C12.9775 5 12.7231 5.10536 12.5356 5.29289L7.11925 10.7092L13.2908 16.8808L18.7071 11.4645C18.8947 11.2769 19 11.0226 19 10.7574V6C19 5.44772 18.5523 5 18 5ZM4.03557 13.7929L5.70504 12.1234L11.8766 18.295L10.2071 19.9645C9.81662 20.355 9.18345 20.355 8.79293 19.9645L4.03557 15.2071C3.64504 14.8166 3.64504 14.1834 4.03557 13.7929ZM11.1214 3.87868C11.684 3.31607 12.447 3 13.2427 3H18C19.6569 3 21 4.34315 21 6V10.7574C21 11.553 20.684 12.3161 20.1214 12.8787L11.6214 21.3787C10.4498 22.5503 8.55029 22.5503 7.37872 21.3787L2.62136 16.6213C1.44978 15.4497 1.44978 13.5503 2.62136 12.3787L11.1214 3.87868ZM15.4999 9.99997C16.3283 9.99997 16.9999 9.3284 16.9999 8.49997C16.9999 7.67154 16.3283 6.99997 15.4999 6.99997C14.6715 6.99997 13.9999 7.67154 13.9999 8.49997C13.9999 9.3284 14.6715 9.99997 15.4999 9.99997Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Coupon24 as default };
//# sourceMappingURL=Coupon24.js.map
