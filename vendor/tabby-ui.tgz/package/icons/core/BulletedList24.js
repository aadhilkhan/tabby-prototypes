import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function BulletedList24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("BulletedList24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-BulletedList24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-BulletedList24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M8 18H20V16H8V18ZM5 16C4.44771 16 4 16.4477 4 17C4 17.5523 4.44771 18 5 18C5.55228 18 6 17.5523 6 17C6 16.4477 5.55228 16 5 16ZM8 13H20V11H8V13ZM5 11C4.44771 11 4 11.4477 4 12C4 12.5523 4.44771 13 5 13C5.55228 13 6 12.5523 6 12C6 11.4477 5.55228 11 5 11ZM8 8H20V6H8V8ZM5 6C4.44771 6 4 6.44772 4 7C4 7.55228 4.44771 8 5 8C5.55228 8 6 7.55228 6 7C6 6.44772 5.55228 6 5 6Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { BulletedList24 as default };
//# sourceMappingURL=BulletedList24.js.map
