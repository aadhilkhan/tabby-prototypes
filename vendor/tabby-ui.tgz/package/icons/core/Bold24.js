import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Bold24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Bold24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Bold24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Bold24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M13.1572 4C14.3193 4.00002 15.2851 4.18238 16.0547 4.54688C16.8296 4.90625 17.4088 5.39844 17.791 6.02344C18.1784 6.64839 18.3721 7.35685 18.3721 8.14844C18.3721 8.79941 18.2464 9.3568 17.9951 9.82031C17.7438 10.2786 17.4055 10.651 16.9814 10.9375C16.5575 11.2238 16.0839 11.4297 15.5605 11.5547V11.7109C16.131 11.7422 16.6778 11.9168 17.2012 12.2344C17.7299 12.5469 18.162 12.9896 18.4971 13.5625C18.8321 14.1354 19 14.8281 19 15.6406C19 16.4687 18.7986 17.2136 18.3955 17.875C17.9924 18.5312 17.3848 19.0495 16.5732 19.4297C15.7618 19.8099 14.741 20 13.5107 20H7V4H13.1572ZM9.91406 17.5781H13.0469C14.1043 17.5781 14.866 17.3775 15.332 16.9766C15.8032 16.5703 16.0391 16.0495 16.0391 15.4141C16.0391 14.9401 15.9211 14.513 15.6855 14.1328C15.45 13.7475 15.1152 13.4453 14.6807 13.2266C14.2462 13.0026 13.7279 12.8907 13.126 12.8906H9.91406V17.5781ZM9.91406 10.8047H12.7959C13.2984 10.8047 13.7512 10.7135 14.1543 10.5312C14.5574 10.3438 14.8741 10.0807 15.1045 9.74219C15.3401 9.39844 15.458 8.99219 15.458 8.52344C15.458 7.90375 15.2385 7.3932 14.7988 6.99219C14.3643 6.59115 13.717 6.39062 12.8584 6.39062H9.91406V10.8047Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Bold24 as default };
//# sourceMappingURL=Bold24.js.map
