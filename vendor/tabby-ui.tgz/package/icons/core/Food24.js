import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Food24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Food24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Food24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Food24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M17.8761 10.0521C18.6324 10.142 19.36 10.3469 20.0303 10.6514C20.8396 11.0189 21.9262 10.486 21.7156 9.6225C20.8114 5.91476 17.84 3.01689 14.0917 2.21918C16.1045 4.31201 17.4725 7.02951 17.8761 10.0521ZM10.8462 2.06592C7.62643 2.43583 4.87187 4.33494 3.32712 7.01862C3.54985 7.00631 3.7742 7.00007 4 7.00007C7.64152 7.00007 10.9042 8.6221 13.1049 11.1831C13.919 10.6369 14.854 10.2571 15.8613 10.0923C15.3534 6.774 13.4864 3.90316 10.8462 2.06592ZM4 9.00007C7.05204 9.00007 9.78474 10.3673 11.619 12.5228C11.019 13.2431 10.5609 14.0857 10.2877 15.0077C9.01295 14.3157 7.55237 13.9227 6 13.9227C4.70648 13.9227 3.4767 14.1956 2.36508 14.6869C2.12717 13.8319 2 12.9309 2 12.0001C2 11.0004 2.14668 10.035 2.4197 9.12423C2.93444 9.04251 3.46226 9.00007 4 9.00007ZM10.0021 17.1789C10.0263 18.1845 10.2541 19.1562 10.6512 20.0304C11.0187 20.8398 10.4858 21.9264 9.62228 21.7158C6.77234 21.0207 4.40092 19.1043 3.09395 16.5525C3.97911 16.1481 4.96323 15.9227 6 15.9227C7.48819 15.9227 8.86791 16.3871 10.0021 17.1789Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Food24 as default };
//# sourceMappingURL=Food24.js.map
