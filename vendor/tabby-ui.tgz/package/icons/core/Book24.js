import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Book24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Book24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Book24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Book24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M11.8112 4.40764C10.0736 3.25688 7.06121 2.18802 5.01116 2.01096C3.35537 1.86375 2 3.21757 2 4.95662V16.5526C2 17.9822 3.056 19.2974 4.42163 19.4831L4.67769 19.5207L4.68182 19.5213C6.51789 19.7825 9.42283 20.7977 11.0486 21.7441C11.0592 21.7503 11.0699 21.7562 11.0807 21.762L11.1021 21.7733C11.3971 21.9412 11.7195 22 11.9944 22C12.2715 22 12.6046 21.9401 12.9066 21.7578C14.5308 20.805 17.4343 19.7842 19.276 19.5222L19.5677 19.4845L19.5714 19.4841C20.9404 19.3019 22 17.9847 22 16.5526V4.96622C22 3.22318 20.6506 1.89796 19.0237 2.017H19.0069C18.9788 2.017 18.9506 2.01829 18.9226 2.02085C16.8718 2.20795 13.8439 3.28905 12.1059 4.4531L11.9983 4.52718L11.8112 4.40764ZM3.96411 4.95662C3.96411 4.41156 4.3574 4.03781 4.84719 4.08162L4.8502 4.08189C6.58476 4.23135 9.3011 5.19452 10.7747 6.17266L10.7891 6.18204L11.0096 6.32289C11.0109 6.32372 11.0121 6.32455 11.0134 6.32538C11.011 6.35514 11.0098 6.38526 11.0098 6.41568V19.405C9.16997 18.5201 6.68646 17.7102 4.94561 17.4622L4.94357 17.4619L4.68619 17.4241L4.67373 17.4224C4.3113 17.3742 3.96411 16.9635 3.96411 16.5526V4.95662ZM12.9739 19.4017C14.8136 18.5153 17.2838 17.7078 19.021 17.4619L19.0323 17.4602L19.3263 17.4224L19.3277 17.4222C19.6896 17.3731 20.0359 16.963 20.0359 16.5526V4.96622C20.0359 4.42162 19.643 4.04656 19.1438 4.09122C19.1163 4.09368 19.0887 4.09491 19.0611 4.09491H19.0507C17.3142 4.26447 14.6238 5.22805 13.1617 6.2054L13.0138 6.30727L12.9982 6.31781C12.9891 6.32377 12.9801 6.32962 12.971 6.33537C12.9729 6.36187 12.9739 6.38865 12.9739 6.41568V19.4017Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Book24 as default };
//# sourceMappingURL=Book24.js.map
