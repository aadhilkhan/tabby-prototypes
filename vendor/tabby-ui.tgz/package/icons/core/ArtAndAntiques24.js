import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function ArtAndAntiques24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("ArtAndAntiques24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-ArtAndAntiques24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-ArtAndAntiques24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M7.99994 5.7V3.5C7.99994 3.22386 8.2238 3 8.49994 3H11.9999H15.4999C15.7761 3 15.9999 3.22386 15.9999 3.5V5.7C15.9999 5.7 16.6739 6.19706 17.5269 7H6.47301C7.32602 6.19706 7.99994 5.7 7.99994 5.7ZM3.01343 12.5804L5.33332 10.5L8.66666 13.4892L12 10.5L15.3333 13.4892L18.6667 10.5L20.9864 12.5803C20.8663 11.1421 19.9618 9.69408 18.9554 8.5H5.04451C4.03804 9.69411 3.13349 11.1421 3.01343 12.5804ZM20.8239 14.4453L18.6667 12.5108L15.3333 15.5L12 12.5108L8.66666 15.5L5.33332 12.5108L3.17604 14.4454C3.3957 15.4839 3.79632 16.5437 4.23614 17.5H19.7637C20.2036 16.5437 20.6042 15.4838 20.8239 14.4453ZM6.21422 21C6.21422 21 5.64983 20.1944 4.99404 19H19.0058C18.35 20.1944 17.7857 21 17.7857 21H11.9999H6.21422Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { ArtAndAntiques24 as default };
//# sourceMappingURL=ArtAndAntiques24.js.map
