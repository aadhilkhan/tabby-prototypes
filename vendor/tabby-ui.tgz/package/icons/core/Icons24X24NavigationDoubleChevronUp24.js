import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Icons24X24NavigationDoubleChevronUp24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes(
    "Icons24X24NavigationDoubleChevronUp24"
  );
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Icons24X24NavigationDoubleChevronUp24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Icons24X24NavigationDoubleChevronUp24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M15.7783 12.5356L11.5361 8.29248L7.29297 12.5356L5.87891 11.1216L11.5352 5.46436L12.9502 6.87842L17.1924 11.1216L15.7783 12.5356ZM15.7783 18.5356L11.5361 14.2925L7.29297 18.5356L5.87891 17.1216L11.5352 11.4644L12.9502 12.8784L17.1924 17.1216L15.7783 18.5356Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Icons24X24NavigationDoubleChevronUp24 as default };
//# sourceMappingURL=Icons24X24NavigationDoubleChevronUp24.js.map
