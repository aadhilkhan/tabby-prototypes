import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Folder48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Folder48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Folder48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Folder48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M10 7H14C15.6569 7 17 8.34315 17 10C17 16.0751 21.9249 21 28 21H38C39.6569 21 41 22.3431 41 24V36C41 37.6569 39.6569 39 38 39H10C8.34315 39 7 37.6569 7 36V10C7 8.34315 8.34315 7 10 7ZM20 10C20 6.68629 17.3137 4 14 4H10C6.68629 4 4 6.68629 4 10V36C4 39.3137 6.68629 42 10 42H38C41.3137 42 44 39.3137 44 36V24C44 23.9958 44 23.9917 44 23.9876L44 22V16C44 11.5817 40.4183 8 36 8H20H19.6587C19.8798 8.62556 20 9.29873 20 10C20 10.3387 20.0211 10.6724 20.062 11H36C38.7614 11 41 13.2386 41 16V18.8027C40.1175 18.2922 39.0929 18 38 18H28C23.5817 18 20 14.4183 20 10Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Folder48 as default };
//# sourceMappingURL=Folder48.js.map
