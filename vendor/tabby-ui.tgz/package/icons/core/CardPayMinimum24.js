import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function CardPayMinimum24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("CardPayMinimum24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-CardPayMinimum24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-CardPayMinimum24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M14.0713 18.0137C14.4381 19.439 15.561 20.5619 16.9863 20.9287V23C14.4386 22.5726 12.4274 20.5614 12 18.0137H14.0713ZM24 18.0137C23.5726 20.5614 21.5614 22.5726 19.0137 23V20.9287C20.439 20.5619 21.5619 19.439 21.9287 18.0137H24ZM16 2C17.6569 2 19 3.34315 19 5V9.06348C18.6723 9.02261 18.3387 9 18 9H2V14C2 14.5523 2.44772 15 3 15H10.2549C10.0901 15.6394 10 16.3091 10 17H3C1.34315 17 0 15.6569 0 14V5C0 3.34315 1.34315 2 3 2H16ZM16.9863 13.0713C15.561 13.4381 14.4381 14.561 14.0713 15.9863H12C12.4274 13.4386 14.4386 11.4274 16.9863 11V13.0713ZM19.0137 11C21.5614 11.4274 23.5726 13.4386 24 15.9863H19.0137V11ZM3 4C2.44772 4 2 4.44772 2 5V6H17V5C17 4.44771 16.5523 4 16 4H3Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { CardPayMinimum24 as default };
//# sourceMappingURL=CardPayMinimum24.js.map
