import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Hotels24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Hotels24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Hotels24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Hotels24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M3 6C3 4.89543 3.89543 4 5 4H19C20.1046 4 21 4.89543 21 6V9.10002C20.6769 9.03443 20.3425 9 20 9H19V8.5C19 7.67157 18.3284 7 17.5 7H14.5C13.6716 7 13 7.67157 13 8.5V9H11V8.5C11 7.67157 10.3284 7 9.5 7H6.5C5.67157 7 5 7.67157 5 8.5V9H4C3.65753 9 3.32311 9.03443 3 9.10002V6ZM1 14C1 12.3431 2.34315 11 4 11H20C21.6569 11 23 12.3431 23 14V15V18V19C23 19.5523 22.5523 20 22 20C21.4477 20 21 19.5523 21 19V18H3V19C3 19.5523 2.55228 20 2 20C1.44772 20 1 19.5523 1 19V18V15V14Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Hotels24 as default };
//# sourceMappingURL=Hotels24.js.map
