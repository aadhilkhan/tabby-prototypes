import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function DateExtension48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("DateExtension48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-DateExtension48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-DateExtension48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M14 4H17V8H22.5V4H25.5V8H31V4H34V8H36C39.866 8 43 11.134 43 15V35C43 38.866 39.866 42 36 42H12C8.13401 42 5 38.866 5 35V15C5 11.134 8.13401 8 12 8H14V4ZM14 11H12C9.79086 11 8 12.7909 8 15V35C8 37.2091 9.79086 39 12 39H36C38.2091 39 40 37.2091 40 35V15C40 12.7909 38.2091 11 36 11H34V15H31V11H25.5V15H22.5V11H17V15H14V11ZM29.1415 30C27.8627 31.3834 26.0325 32.2497 24 32.2497C21.4969 32.2497 19.3007 30.9359 18.0633 28.9602L15.5189 30.5504C17.2826 33.3663 20.4097 35.241 23.9753 35.2497H24.0248C26.7405 35.2431 29.2018 34.154 31 32.3911V35H34V30V27H31H26V30H29.1415ZM17 19H13V23H17V19ZM22 19H26V23H22V19ZM31 19H35V23H31V19Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { DateExtension48 as default };
//# sourceMappingURL=DateExtension48.js.map
