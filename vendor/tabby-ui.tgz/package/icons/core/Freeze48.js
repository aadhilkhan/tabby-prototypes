import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Freeze48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Freeze48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Freeze48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Freeze48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M25.5 10.3281L28.9502 6.87891L31.0713 9L25.5 14.5713V21.4014L31.416 17.9863L33.4551 10.376L36.3525 11.1523L35.0898 15.8652L41.4365 12.2012L42.9365 14.7988L36.5898 18.4629L41.3027 19.7256L40.5264 22.624L32.916 20.585L27 24L32.916 27.415L40.5264 25.376L41.3027 28.2744L36.5898 29.5371L42.9365 33.2012L41.4365 35.7988L35.0898 32.1348L36.3525 36.8477L33.4551 37.624L31.416 30.0137L25.5 26.5967V33.4287L31.0713 39L28.9502 41.1211L25.5 37.6719V45H22.5V37.6719L19.0498 41.1211L16.9287 39L22.5 33.4287V26.5967L16.584 30.0137L14.5449 37.624L11.6475 36.8477L12.9102 32.1348L6.56348 35.7988L5.06348 33.2012L11.4102 29.5371L6.69824 28.2744L7.47461 25.376L15.084 27.415L20.999 24L15.084 20.585L7.47461 22.624L6.69824 19.7256L11.4102 18.4629L5.06348 14.7988L6.56348 12.2012L12.9102 15.8652L11.6475 11.1523L14.5449 10.376L16.584 17.9863L22.5 21.4014V14.5713L16.9287 9L19.0498 6.87891L22.5 10.3281V3H25.5V10.3281Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Freeze48 as default };
//# sourceMappingURL=Freeze48.js.map
