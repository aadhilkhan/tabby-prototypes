import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Gift24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Gift24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Gift24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Gift24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M15.7305 7C15.9009 6.70564 16 6.36464 16 6C16 4.89543 15.1046 4.00001 14 4C12.8954 4 12 4.89543 12 6C12 6.36464 12.0991 6.70563 12.2695 7H15.7305ZM6 18.5C6 18.7761 6.22386 19 6.5 19H11V14H6V18.5ZM13 19H17.5C17.7761 19 18 18.7761 18 18.5V14H13V19ZM4.5 9C4.22386 9 4 9.22386 4 9.5V11.5C4 11.7761 4.22386 12 4.5 12H11V9H4.5ZM13 12H19.5C19.7761 12 20 11.7761 20 11.5V9.5C20 9.22386 19.7761 9 19.5 9H13V12ZM19.5 7C20.8807 7 22 8.11929 22 9.5V11.5C22 12.7094 21.141 13.7175 20 13.9492V18.5C20 19.8807 18.8807 21 17.5 21H6.5C5.11929 21 4 19.8807 4 18.5V13.9492C2.85895 13.7175 2 12.7094 2 11.5V9.5C2 8.11929 3.11929 7 4.5 7H6.12598C6.04372 6.68039 6 6.34529 6 6C6 3.79089 7.7909 2.00005 10 2C10.3006 2 10.5934 2.03383 10.875 2.09668C10.2187 2.62282 9.69756 3.31094 9.37305 4.10059C8.57567 4.36367 8 5.11448 8 6C8 6.36462 8.09907 6.70564 8.26953 7H10.126C10.0437 6.68038 10 6.3453 10 6C10 3.79086 11.7909 2 14 2C16.2091 2.00001 18 3.79086 18 6C18 6.34529 17.9563 6.68038 17.874 7H19.5Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Gift24 as default };
//# sourceMappingURL=Gift24.js.map
