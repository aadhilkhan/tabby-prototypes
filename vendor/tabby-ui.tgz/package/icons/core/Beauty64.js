import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Beauty64(props) {
  const { dir, className, style = {}, color = "", size = 64, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Beauty64");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Beauty64 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Beauty64",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 64 64",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M28.0942 33.4432L23.207 39.5034C22.3673 39.1783 21.4545 39 20.5 39C16.3579 39 13 42.3579 13 46.5C13 50.6421 16.3579 54 20.5 54C24.6421 54 28 50.6421 28 46.5C28 45.4064 27.7659 44.3675 27.3452 43.4306L32 38L36.6548 43.4306C36.2341 44.3675 36 45.4064 36 46.5C36 50.6421 39.3579 54 43.5 54C47.6421 54 51 50.6421 51 46.5C51 42.3579 47.6421 39 43.5 39C42.5455 39 41.6327 39.1783 40.793 39.5034L17 10L16.4519 11.2788C14.9508 14.7814 15.5709 18.8327 18.0508 21.7259L28.0942 33.4432ZM37.6094 31.4557L45.9492 21.7259C48.4291 18.8327 49.0492 14.7814 47.5481 11.2788L47 10L33.6532 26.55L37.6094 31.4557ZM24.5 46.5C24.5 48.7091 22.7091 50.5 20.5 50.5C18.2909 50.5 16.5 48.7091 16.5 46.5C16.5 44.2909 18.2909 42.5 20.5 42.5C22.7091 42.5 24.5 44.2909 24.5 46.5ZM47.5 46.5C47.5 48.7091 45.7091 50.5 43.5 50.5C41.2909 50.5 39.5 48.7091 39.5 46.5C39.5 44.2909 41.2909 42.5 43.5 42.5C45.7091 42.5 47.5 44.2909 47.5 46.5ZM33.5 33C33.5 33.8284 32.8284 34.5 32 34.5C31.1716 34.5 30.5 33.8284 30.5 33C30.5 32.1716 31.1716 31.5 32 31.5C32.8284 31.5 33.5 32.1716 33.5 33Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Beauty64 as default };
//# sourceMappingURL=Beauty64.js.map
