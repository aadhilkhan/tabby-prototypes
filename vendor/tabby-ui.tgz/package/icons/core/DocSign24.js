import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function DocSign24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("DocSign24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-DocSign24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-DocSign24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M10.4287 17.7148L6.25 22H4V19.75L8.28516 15.5713L10.4287 17.7148ZM13 2C13.3395 2 13.6734 2.02457 14 2.07129C17.0656 2.50982 19.4902 4.93435 19.9287 8L19.9316 8.02148C19.9764 8.34126 20 8.6679 20 9V19C20 20.6569 18.6569 22 17 22H11V20H17C17.5523 20 18 19.5523 18 19V9.92871C14.9344 9.49018 12.5098 7.06565 12.0713 4H7C6.44771 4 6 4.44772 6 5V15H4V5C4 3.34315 5.34315 2 7 2H13ZM13 15.1426L11.2861 16.8574L9.14258 14.7139L10.8574 13L13 15.1426ZM14.1279 4.12793C14.5558 5.98361 16.0164 7.4442 17.8721 7.87207C17.4442 6.01639 15.9836 4.5558 14.1279 4.12793Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { DocSign24 as default };
//# sourceMappingURL=DocSign24.js.map
