import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Catalogue48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Catalogue48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Catalogue48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Catalogue48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M29 32C31.4967 32 33.7991 31.1682 35.6453 29.7666L41.0607 35.182L43.182 33.0607L37.7666 27.6453C39.1682 25.7991 40 23.4967 40 21C40 14.9249 35.0751 10 29 10C22.9249 10 18 14.9249 18 21C18 27.0751 22.9249 32 29 32ZM29 29C33.4183 29 37 25.4183 37 21C37 16.5817 33.4183 13 29 13C24.5817 13 21 16.5817 21 21C21 25.4183 24.5817 29 29 29ZM21 33H7V36H21V33ZM7 26H15V29H7V26ZM15 19H7V22H15V19Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Catalogue48 as default };
//# sourceMappingURL=Catalogue48.js.map
