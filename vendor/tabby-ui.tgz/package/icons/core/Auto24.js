import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Auto24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Auto24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Auto24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Auto24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M21.9261 13.2215C21.9749 12.8211 22 12.4135 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C12.0084 22 12.0167 22 12.0251 22C14.2758 21.9994 16.3527 21.2554 18.0236 20H18.001C18.7679 19.4238 19.4493 18.7399 20.0227 17.9707V18.001C21.0425 16.6436 21.7249 15.0183 21.9454 13.2496C21.939 13.2402 21.9326 13.2308 21.9261 13.2215ZM19.9354 10.9782C19.4336 7.04243 16.0721 4 12 4C7.9124 4 4.54082 7.06565 4.05904 11.0232C6.17767 9.14229 8.96678 8 12.0227 8C15.0541 8 17.8231 9.12409 19.9354 10.9782ZM19.748 14H18.0227C15.8135 14 14.0227 15.7909 14.0227 18V19.7421C16.8231 19.0125 19.0264 16.8037 19.748 14ZM10.0227 19.7538V18C10.0227 15.7909 8.23181 14 6.02267 14H4.25203C4.97754 16.8188 7.20069 19.0363 10.0227 19.7538ZM14.0227 12C14.0227 13.1046 13.1272 14 12.0227 14C10.9181 14 10.0227 13.1046 10.0227 12C10.0227 10.8954 10.9181 10 12.0227 10C13.1272 10 14.0227 10.8954 14.0227 12Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Auto24 as default };
//# sourceMappingURL=Auto24.js.map
