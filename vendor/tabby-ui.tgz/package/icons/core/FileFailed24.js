import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function FileFailed24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("FileFailed24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-FileFailed24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-FileFailed24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M3 5C3 3.34315 4.34315 2 6 2H12C12.0559 2 12.1117 2.00066 12.1672 2.00196C15.5894 2.08219 18.404 4.61841 18.9166 7.91617L18.9193 7.93397C18.9725 8.28156 19 8.63756 19 9V9.92908C18.6734 9.97579 18.3395 9.99997 18 9.99997C17.6605 9.99997 17.3266 9.97579 17 9.92908C13.9343 9.49056 11.5094 7.06569 11.0709 4H6C5.44772 4 5 4.44772 5 5V19C5 19.5523 5.44772 20 6 20H10.4268C10.6827 20.7242 11.0467 21.3973 11.4995 22H6C4.34315 22 3 20.6569 3 19V5ZM16.8723 7.87231C15.0164 7.4445 13.5555 5.98359 13.1277 4.12769C14.9836 4.5555 16.4445 6.01641 16.8723 7.87231Z",
          fill: "currentColor"
        }
      ),
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M7 12H12.4009C11.7832 12.5729 11.2622 13.2487 10.865 14H7V12Z",
          fill: "currentColor"
        }
      ),
      /* @__PURE__ */ React__default.createElement("path", { d: "M10 16V18H7V16H10Z", fill: "currentColor" }),
      /* @__PURE__ */ React__default.createElement("path", { d: "M7 8H11V10H7V8Z", fill: "currentColor" }),
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M23 17.5C23 20.5376 20.5376 23 17.5 23C14.4624 23 12 20.5376 12 17.5C12 14.4624 14.4624 12 17.5 12C20.5376 12 23 14.4624 23 17.5ZM16.6202 13.75H18.3702V17.75H16.6202V13.75ZM18.5001 20.25C18.5001 20.8023 18.0524 21.25 17.5001 21.25C16.9478 21.25 16.5001 20.8023 16.5001 20.25C16.5001 19.6977 16.9478 19.25 17.5001 19.25C18.0524 19.25 18.5001 19.6977 18.5001 20.25Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { FileFailed24 as default };
//# sourceMappingURL=FileFailed24.js.map
