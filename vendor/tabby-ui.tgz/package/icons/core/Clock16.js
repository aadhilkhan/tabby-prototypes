import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Clock16(props) {
  const { dir, className, style = {}, color = "", size = 16, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Clock16");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Clock16 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Clock16",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M15 8A7 7 0 1 1 1 8a7 7 0 0 1 14 0m-1.75 0a5.25 5.25 0 1 1-10.5 0 5.25 5.25 0 0 1 10.5 0m-4.375-.362V4.25h-1.75v4.112l2.506 2.507L10.87 9.63z",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { Clock16 as default };
//# sourceMappingURL=Clock16.js.map
