import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function AlertStroke24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("AlertStroke24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-AlertStroke24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-AlertStroke24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M22 7.85742V16.1426L16.1426 22H7.85742L2 16.1426V7.85742L7.85742 2H16.1426L22 7.85742ZM4 8.68652V15.3135L8.68652 20H15.3135L20 15.3135V8.68652L15.3135 4H8.68652L4 8.68652ZM12 14.75C12.6903 14.75 13.25 15.3097 13.25 16C13.25 16.6903 12.6903 17.25 12 17.25C11.3096 17.25 10.75 16.6904 10.75 16C10.75 15.3097 11.3097 14.75 12 14.75ZM13 13H11V7H13V13Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { AlertStroke24 as default };
//# sourceMappingURL=AlertStroke24.js.map
