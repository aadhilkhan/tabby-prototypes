import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function ChevronDown24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("ChevronDown24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-ChevronDown24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-ChevronDown24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M12.0002 13.1716L7.75748 8.92888L6.34326 10.3431L10.5859 14.5858L10.5859 14.5858L12.0001 16L17.657 10.3431L16.2428 8.92893L12.0002 13.1716Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { ChevronDown24 as default };
//# sourceMappingURL=ChevronDown24.js.map
