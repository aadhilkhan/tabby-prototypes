import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function FaceID24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("FaceID24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-FaceID24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-FaceID24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M5 2C3.34315 2 2 3.34315 2 5V8H4V5C4 4.44772 4.44772 4 5 4H8V2H5ZM2 19V16H4V19C4 19.5523 4.44772 20 5 20H8V22H5C3.34315 22 2 20.6569 2 19ZM16 22V20H19C19.5523 20 20 19.5523 20 19V16H22V19C22 20.6569 20.6569 22 19 22H16ZM22 8H20V5C20 4.44772 19.5523 4 19 4H16V2H19C20.6569 2 22 3.34315 22 5V8ZM8 7.2C8.55228 7.2 9 7.64772 9 8.2V9.62105C9 10.1733 8.55228 10.6211 8 10.6211C7.44772 10.6211 7 10.1733 7 9.62105V8.2C7 7.64772 7.44772 7.2 8 7.2ZM16 7.2C16.5523 7.2 17 7.64772 17 8.2V9.62105C17 10.1733 16.5523 10.6211 16 10.6211C15.4477 10.6211 15 10.1733 15 9.62105V8.2C15 7.64772 15.4477 7.2 16 7.2ZM12.4444 7.67368C12.9967 7.67368 13.4444 8.1214 13.4444 8.67368V12.9368C13.4444 13.4891 12.9967 13.9368 12.4444 13.9368H11.1111C10.5588 13.9368 10.1111 13.4891 10.1111 12.9368C10.1111 12.3846 10.5588 11.9368 11.1111 11.9368H11.4444V8.67368C11.4444 8.1214 11.8922 7.67368 12.4444 7.67368ZM9.22005 15.1477C8.87503 14.7236 8.25202 14.6549 7.82265 14.9958C7.39011 15.3392 7.31786 15.9682 7.66127 16.4007L7.66192 16.4016L7.6626 16.4024L7.66404 16.4042L7.66726 16.4082L7.67505 16.4178C7.68085 16.4249 7.68787 16.4333 7.6961 16.4429C7.71256 16.4623 7.73392 16.4867 7.76025 16.5154C7.81286 16.5729 7.88554 16.6479 7.97879 16.7343C8.165 16.907 8.43524 17.1272 8.79322 17.3444C9.51449 17.7821 10.5807 18.2 12 18.2C13.4193 18.2 14.4855 17.7821 15.2068 17.3444C15.5648 17.1272 15.835 16.907 16.0212 16.7343C16.1145 16.6479 16.1871 16.5729 16.2398 16.5154C16.2661 16.4867 16.2874 16.4623 16.3039 16.4429L16.313 16.4322L16.3249 16.4178L16.3327 16.4082L16.336 16.4042L16.3374 16.4024L16.3381 16.4016L16.3387 16.4007C16.6821 15.9682 16.6099 15.3392 16.1774 14.9958C15.748 14.6549 15.125 14.7236 14.78 15.1477L14.7799 15.1477C14.7614 15.168 14.7119 15.2209 14.6615 15.2677C14.5666 15.3556 14.417 15.4798 14.2112 15.6087C14.1974 15.6173 14.1835 15.6259 14.1693 15.6346C13.7196 15.9074 13.0081 16.2 12 16.2C10.9919 16.2 10.2804 15.9074 9.83074 15.6346C9.60324 15.4965 9.43971 15.3615 9.33853 15.2677C9.28807 15.2209 9.25365 15.1848 9.23508 15.1646C9.23132 15.1605 9.22822 15.157 9.22579 15.1543C9.22303 15.1512 9.22112 15.149 9.22005 15.1477Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { FaceID24 as default };
//# sourceMappingURL=FaceID24.js.map
