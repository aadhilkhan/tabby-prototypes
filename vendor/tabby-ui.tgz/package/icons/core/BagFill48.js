import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function BagFill48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("BagFill48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-BagFill48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-BagFill48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M41.02 27.2881C41.3604 32.0533 41.5309 34.4361 40.7085 36.2715C39.9857 37.8843 38.7491 39.2129 37.1919 40.0488C35.4197 41 33.0299 41 28.2524 41H19.7466C14.9693 41 12.5802 41 10.8081 40.0488C9.25089 39.2129 8.01432 37.8843 7.2915 36.2715C6.46904 34.4361 6.63863 32.0533 6.979 27.2881L7.99951 13H39.9995L41.02 27.2881ZM15.9995 17C15.9995 21.4181 19.5815 24.9997 23.9995 25C28.4178 25 31.9995 21.4183 31.9995 17H28.9995C28.9995 19.7614 26.7609 22 23.9995 22C21.2383 21.9997 18.9995 19.7613 18.9995 17H15.9995ZM24.0005 4C27.8663 4.00026 31.0005 7.13417 31.0005 11H27.9995C27.9995 8.79086 26.2087 7 23.9995 7C21.7906 7.00026 19.9995 8.79102 19.9995 11H17.0005C17.0005 7.13401 20.1345 4 24.0005 4Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { BagFill48 as default };
//# sourceMappingURL=BagFill48.js.map
