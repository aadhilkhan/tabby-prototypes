import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Document24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Document24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Document24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Document24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement("path", { d: "M7 11H17V13H7V11Z", fill: "currentColor" }),
      /* @__PURE__ */ React__default.createElement("path", { d: "M17 15H7V17H17V15Z", fill: "currentColor" }),
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M7.12602 4C7.57006 2.27477 9.13616 1 11 1H13C14.8638 1 16.4299 2.27477 16.874 4H17.9995C19.6564 4 20.9995 5.34315 20.9995 7V19C20.9995 20.6569 19.6564 22 17.9995 22H5.99951C4.34266 22 2.99951 20.6569 2.99951 19V7C2.99951 5.34315 4.34266 4 5.99951 4H7.12602ZM11 3H13C14.1046 3 15 3.89543 15 5V6H9V5C9 3.89543 9.89543 3 11 3ZM7 6H5.99951C5.44723 6 4.99951 6.44772 4.99951 7V19C4.99951 19.5523 5.44723 20 5.99951 20H17.9995C18.5518 20 18.9995 19.5523 18.9995 19V7C18.9995 6.44772 18.5518 6 17.9995 6H17C17 7.10457 16.1046 8 15 8H9C7.89543 8 7 7.10457 7 6Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Document24 as default };
//# sourceMappingURL=Document24.js.map
