import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Feed24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Feed24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Feed24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Feed24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M19.9914 20C19.9971 18.9306 20 18.1662 20 18C20 10.268 13.732 4 6 4C5.83382 4 5.06943 4.0029 4 4.00864V6.01013C5.06904 6.0034 5.83331 6 6 6C12.6274 6 18 11.3726 18 18C18 18.1667 17.9966 18.931 17.9899 20H19.9914ZM13.9938 20C13.9979 19.1743 14 18.6093 14 18.5C14 13.8056 10.1944 10 5.5 10C5.39069 10 4.82573 10.0021 4 10.0062V12.0082C4.82506 12.0027 5.38984 12 5.5 12C9.08985 12 12 14.9101 12 18.5C12 18.6102 11.9973 19.1749 11.9918 20H13.9938ZM6 20C7.10457 20 8 19.1046 8 18C8 16.8954 7.10457 16 6 16C4.89543 16 4 16.8954 4 18C4 19.1046 4.89543 20 6 20Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Feed24 as default };
//# sourceMappingURL=Feed24.js.map
