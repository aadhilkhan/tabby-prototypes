import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Case24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Case24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Case24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Case24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M20 8.09929V7C20 5.34315 18.6569 4 17 4H14.0938L12.638 2.7353C12.0922 2.26112 11.3935 2 10.6705 2H7C5.34315 2 4 3.34315 4 5V8.09925C2.48119 8.5001 1.47433 10.0558 1.8479 11.6746L3.46328 18.6746C3.77741 20.0358 4.98949 21 6.38646 21H17.6134C19.0103 21 20.2224 20.0358 20.5366 18.6746L22.1519 11.6746C22.5255 10.0558 21.5187 8.50021 20 8.09929ZM7 4C6.44772 4 6 4.44772 6 5V8H18V7C18 6.44772 17.5523 6 17 6H13.3463L11.3263 4.2451C11.1444 4.08704 10.9115 4 10.6705 4H7ZM4.77107 10H19.2288C19.8719 10 20.3478 10.5982 20.2032 11.2249L18.5878 18.2249C18.4831 18.6786 18.079 19 17.6134 19H6.38646C5.9208 19 5.51677 18.6786 5.41207 18.2249L3.79668 11.2249C3.65208 10.5982 4.12798 10 4.77107 10Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Case24 as default };
//# sourceMappingURL=Case24.js.map
