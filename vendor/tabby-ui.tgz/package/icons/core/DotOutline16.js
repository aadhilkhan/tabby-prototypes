import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function DotOutline16(props) {
  const { dir, className, style = {}, color = "", size = 16, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("DotOutline16");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-DotOutline16 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-DotOutline16",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M8 13A5 5 0 1 0 8 3a5 5 0 0 0 0 10m0-1.75a3.25 3.25 0 1 0 0-6.5 3.25 3.25 0 0 0 0 6.5",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { DotOutline16 as default };
//# sourceMappingURL=DotOutline16.js.map
