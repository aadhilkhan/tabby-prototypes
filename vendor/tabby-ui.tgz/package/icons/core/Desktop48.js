import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Desktop48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Desktop48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Desktop48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Desktop48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M21 34V40H27V34H21ZM10 9C8.34315 9 7 10.3431 7 12V28C7 29.6569 8.34315 31 10 31H38C39.6569 31 41 29.6569 41 28V12C41 10.3431 39.6569 9 38 9H10ZM30 40H36V43H12V40H18V34H10C6.68629 34 4 31.3137 4 28V12C4 8.68629 6.68629 6 10 6H38C41.3137 6 44 8.68629 44 12V28C44 31.3137 41.3137 34 38 34H30V40Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Desktop48 as default };
//# sourceMappingURL=Desktop48.js.map
