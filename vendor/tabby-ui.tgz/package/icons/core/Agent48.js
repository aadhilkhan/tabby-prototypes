import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Agent48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Agent48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Agent48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Agent48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M24 3C35.598 3 45 12.402 45 24C45 35.598 35.598 45 24 45C23.1716 45 22.5 44.3284 22.5 43.5C22.5 42.6716 23.1716 42 24 42C31.1677 42 37.3555 37.8099 40.251 31.7461C39.8613 31.9096 39.4378 32 39 32C36.7909 32 35 30.2091 35 28V22C35 19.7909 36.7909 18 39 18C39.7403 18 40.4488 18.1357 41.1035 18.3809C38.7431 11.1918 31.9787 6 24 6C16.0215 6 9.25615 11.1911 6.89551 18.3799C7.5504 18.1345 8.25946 18 9 18C11.2091 18 13 19.7909 13 22V28C13 30.2091 11.2091 32 9 32C5.68629 32 3 29.3137 3 26V24C3 12.402 12.402 3 24 3ZM19 22C20.6569 22 22 23.3431 22 25C22 26.6569 20.6569 28 19 28C17.3431 28 16 26.6569 16 25C16 23.3431 17.3431 22 19 22ZM29 22C30.6569 22 32 23.3431 32 25C32 26.6569 30.6569 28 29 28C27.3431 28 26 26.6569 26 25C26 23.3431 27.3431 22 29 22Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Agent48 as default };
//# sourceMappingURL=Agent48.js.map
