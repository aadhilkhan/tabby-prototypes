import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Grid24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Grid24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Grid24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Grid24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement("mask", { id: "path-1-inside-1_3285_3198", fill: "white" }, /* @__PURE__ */ React__default.createElement("path", { d: "M18 2C20.2091 2 22 3.79086 22 6V18C22 20.2091 20.2091 22 18 22H6C3.79086 22 2 20.2091 2 18V6C2 3.79086 3.79086 2 6 2H18ZM13 20H18C19.1046 20 20 19.1046 20 18V13H13V20ZM6 4C4.89543 4 4 4.89543 4 6V18C4 19.1046 4.89543 20 6 20H11V4H6ZM13 11H20V6C20 4.89543 19.1046 4 18 4H13V11Z" })),
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M18 2C20.2091 2 22 3.79086 22 6V18C22 20.2091 20.2091 22 18 22H6C3.79086 22 2 20.2091 2 18V6C2 3.79086 3.79086 2 6 2H18ZM13 20H18C19.1046 20 20 19.1046 20 18V13H13V20ZM6 4C4.89543 4 4 4.89543 4 6V18C4 19.1046 4.89543 20 6 20H11V4H6ZM13 11H20V6C20 4.89543 19.1046 4 18 4H13V11Z",
          fill: "currentColor"
        }
      ),
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M13 20H12V21H13V20ZM20 13H21V12H20V13ZM13 13V12H12V13H13ZM11 20V21H12V20H11ZM11 4H12V3H11V4ZM13 11H12V12H13V11ZM20 11V12H21V11H20ZM13 4V3H12V4H13ZM18 2V3C19.6569 3 21 4.34315 21 6H22H23C23 3.23858 20.7614 1 18 1V2ZM22 6H21V18H22H23V6H22ZM22 18H21C21 19.6569 19.6569 21 18 21V22V23C20.7614 23 23 20.7614 23 18H22ZM18 22V21H6V22V23H18V22ZM6 22V21C4.34315 21 3 19.6569 3 18H2H1C1 20.7614 3.23858 23 6 23V22ZM2 18H3V6H2H1V18H2ZM2 6H3C3 4.34315 4.34315 3 6 3V2V1C3.23858 1 1 3.23858 1 6H2ZM6 2V3H18V2V1H6V2ZM13 20V21H18V20V19H13V20ZM18 20V21C19.6569 21 21 19.6569 21 18H20H19C19 18.5523 18.5523 19 18 19V20ZM20 18H21V13H20H19V18H20ZM20 13V12H13V13V14H20V13ZM13 13H12V20H13H14V13H13ZM6 4V3C4.34315 3 3 4.34315 3 6H4H5C5 5.44772 5.44772 5 6 5V4ZM4 6H3V18H4H5V6H4ZM4 18H3C3 19.6569 4.34315 21 6 21V20V19C5.44772 19 5 18.5523 5 18H4ZM6 20V21H11V20V19H6V20ZM11 20H12V4H11H10V20H11ZM11 4V3H6V4V5H11V4ZM13 11V12H20V11V10H13V11ZM20 11H21V6H20H19V11H20ZM20 6H21C21 4.34315 19.6569 3 18 3V4V5C18.5523 5 19 5.44771 19 6H20ZM18 4V3H13V4V5H18V4ZM13 4H12V11H13H14V4H13Z",
          fill: "currentColor",
          mask: "url(#path-1-inside-1_3285_3198)"
        }
      )
    )
  );
}

export { Grid24 as default };
//# sourceMappingURL=Grid24.js.map
