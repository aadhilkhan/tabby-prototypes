import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Book16(props) {
  const { dir, className, style = {}, color = "", size = 16, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Book16");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Book16 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Book16",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M7.987 3.2C6.779 2.446 4.703 1.75 3.278 1.634A2.082 2.082 0 0 0 1 3.73v7.44c0 1.02.792 1.954 1.825 2.087l.173.024h.004c1.221.165 3.17.808 4.251 1.403l.029.015.012.006a1.5 1.5 0 0 0 .702.17l.017-.001h.014c.21-.004.462-.049.696-.182 1.08-.599 3.024-1.245 4.248-1.41l.197-.024h.003c1.037-.13 1.831-1.066 1.831-2.088V3.737a2.083 2.083 0 0 0-2.237-2.101h-.003a.882.882 0 0 0-.078.003c-1.412.122-3.472.813-4.686 1.569zm-5.228.53c0-.124.048-.213.108-.27a.326.326 0 0 1 .258-.083h.002c1.144.093 2.957.7 3.93 1.31l.013.008.149.09.031.019V12.5c0 .09.016.176.045.256-1.253-.554-2.887-1.05-4.05-1.207h-.002l-.174-.025-.01-.001c-.14-.018-.3-.19-.3-.352zm5.948 9.02c1.252-.553 2.874-1.047 4.034-1.202l.01-.001.199-.024c.14-.019.3-.19.3-.352V3.737a.353.353 0 0 0-.11-.27.34.34 0 0 0-.267-.084.867.867 0 0 1-.05.002H12.8c-1.146.11-2.932.715-3.894 1.322l-.1.065-.013.009a1.297 1.297 0 0 1-.044.026V12.5a.749.749 0 0 1-.043.25",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { Book16 as default };
//# sourceMappingURL=Book16.js.map
