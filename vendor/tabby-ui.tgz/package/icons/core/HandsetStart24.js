import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function HandsetStart24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("HandsetStart24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-HandsetStart24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-HandsetStart24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M7.39073 2.25324C7.71019 2.21425 8.03372 2.27904 8.31353 2.43805C8.59334 2.59705 8.81459 2.84183 8.9446 3.13624L11.0401 7.53731L11.052 7.56383C11.1494 7.79126 11.1891 8.03926 11.1675 8.28574C11.1459 8.53221 11.0636 8.76952 10.928 8.9765L9.36754 11.3603C10.0717 12.7923 11.2331 13.9486 12.6682 14.6464L15.0162 13.0806C15.2239 12.9419 15.4629 12.8573 15.7115 12.8344C15.9602 12.8114 16.2106 12.851 16.4402 12.9493L16.4667 12.9613L20.8664 15.0581C21.0345 15.1311 21.1876 15.2347 21.3179 15.3637C21.4795 15.5247 21.6022 15.7205 21.6768 15.9361C21.7513 16.1517 21.7757 16.3815 21.7481 16.6079C21.4173 19.2231 19.3344 21.0501 16.6834 21.0508C9.23761 21.0521 2.94988 14.7644 2.94922 7.31656C2.94856 4.6669 4.77554 2.58403 7.39073 2.25324Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { HandsetStart24 as default };
//# sourceMappingURL=HandsetStart24.js.map
