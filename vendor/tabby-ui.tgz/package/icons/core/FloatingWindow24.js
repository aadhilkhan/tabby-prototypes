import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function FloatingWindow24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("FloatingWindow24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-FloatingWindow24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-FloatingWindow24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M19 5C20.6569 5 22 6.34315 22 8V16C22 17.6569 20.6569 19 19 19H5C3.34315 19 2 17.6569 2 16V8C2 6.34315 3.34315 5 5 5H19ZM5.5 7C4.67157 7 4 7.67157 4 8.5V15.5C4 16.3284 4.67157 17 5.5 17H18.5C19.3284 17 20 16.3284 20 15.5V8.5C20 7.67157 19.3284 7 18.5 7H5.5ZM18 8C18.5523 8 19 8.44772 19 9V11C19 11.5523 18.5523 12 18 12H14C13.4477 12 13 11.5523 13 11V9C13 8.44772 13.4477 8 14 8H18Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { FloatingWindow24 as default };
//# sourceMappingURL=FloatingWindow24.js.map
