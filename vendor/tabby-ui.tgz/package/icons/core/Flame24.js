import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Flame24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Flame24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Flame24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Flame24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M10.5 2.5C14.992 3.53663 17.0935 7.19992 16.9746 10.8496L19.5635 9.12402C20.1605 10.2866 20.5 11.6041 20.5 13.001C20.4996 17.6951 16.6942 21.501 12 21.501C7.30581 21.501 3.50038 17.6951 3.5 13.001C3.5 10.0111 5.04511 7.3834 7.37891 5.86816C7.11085 6.86036 7.3828 7.79411 7.92773 8.86914C8.98335 6.6379 10.812 5.93104 10.5 2.5ZM12.252 5.35645C12.0548 6.0426 11.7671 6.63998 11.4248 7.19043C11.0992 7.71404 10.6936 8.23696 10.4365 8.59082C10.1489 8.98679 9.92073 9.33277 9.73535 9.72461L7.98926 13.415L6.24707 9.97852C5.77082 10.8821 5.5 11.9098 5.5 13.001C5.50037 16.5907 8.41059 19.501 12 19.501C15.4774 19.501 18.317 16.7695 18.4912 13.335L18.5 13.001C18.5 12.7518 18.4844 12.5062 18.457 12.2646L18.084 12.5137L14.8486 14.6699L14.9756 10.7842C15.0448 8.6567 14.1658 6.58649 12.252 5.35645Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Flame24 as default };
//# sourceMappingURL=Flame24.js.map
