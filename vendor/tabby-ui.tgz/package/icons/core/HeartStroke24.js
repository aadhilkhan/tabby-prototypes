import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function HeartStroke24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("HeartStroke24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-HeartStroke24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-HeartStroke24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M9.60453 6.97268C8.31378 5.67577 6.21536 5.67577 4.92461 6.97268C3.64163 8.26178 3.64163 10.3458 4.92461 11.635L12 18.7441L19.0754 11.635C20.3584 10.3458 20.3584 8.26178 19.0754 6.97268C17.7846 5.67577 15.6862 5.67577 14.3955 6.97268L12 9.37957L9.60453 6.97268ZM3.54691 5.54844C5.60169 3.48385 8.92745 3.48386 10.9822 5.54844L12 6.57106L13.0178 5.54844C15.0726 3.48386 18.3983 3.48385 20.4531 5.54844C22.5156 7.62083 22.5156 10.9868 20.4531 13.0592L12.924 20.6242C12.6669 20.8826 12.3296 21.0059 12 20.9998C11.6704 21.0059 11.3331 20.8825 11.076 20.6242L3.54691 13.0592C1.48436 10.9868 1.48436 7.62083 3.54691 5.54844Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { HeartStroke24 as default };
//# sourceMappingURL=HeartStroke24.js.map
