import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Email24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Email24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Email24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Email24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M17.0004 2C18.6571 2.0002 20.0004 3.34327 20.0004 5V10.0107C21.6291 10.1505 22.8673 11.5876 22.7289 13.249L22.2289 19.249C22.0993 20.8039 20.7999 22 19.2396 22H4.76013C3.19996 21.9999 1.90044 20.8038 1.77087 19.249L1.27087 13.249C1.13247 11.5875 2.37139 10.1503 4.00037 10.0107V5C4.00037 3.34315 5.34351 2 7.00037 2H17.0004ZM3.29529 12.7393C3.26591 12.8481 3.2541 12.9637 3.26404 13.083L3.76404 19.083C3.80722 19.6012 4.24014 19.9999 4.76013 20H19.2396C19.7597 20 20.1925 19.6013 20.2357 19.083L20.7357 13.083C20.7456 12.964 20.7337 12.8488 20.7045 12.7402L11.9984 17.7676L11.9935 17.7588L11.9916 17.7607L3.29529 12.7393ZM7.00037 4C6.44808 4 6.00037 4.44772 6.00037 5V11.9922L12.0004 15.457L18.0004 11.9932V5C18.0004 4.44784 17.5525 4.0002 17.0004 4H7.00037ZM16.0004 12H8.00037V10H16.0004V12ZM16.0004 8H8.00037V6H16.0004V8Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Email24 as default };
//# sourceMappingURL=Email24.js.map
