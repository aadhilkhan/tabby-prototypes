import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Fingerprint48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Fingerprint48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Fingerprint48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Fingerprint48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M24.5 22C25.3284 22 26 22.6716 26 23.5V41.5C26 42.3284 25.3284 43 24.5 43C23.6716 43 23 42.3284 23 41.5V23.5C23 22.6716 23.6716 22 24.5 22ZM17 28.5C17.8284 28.5 18.5 29.1716 18.5 30V37C18.5 37.8284 17.8284 38.5 17 38.5C16.1716 38.5 15.5 37.8284 15.5 37V30C15.5 29.1716 16.1716 28.5 17 28.5ZM24.5 14.5C29.3714 14.5 33.5 18.2098 33.5 23V37C33.5 37.8284 32.8284 38.5 32 38.5C31.1716 38.5 30.5 37.8284 30.5 37V23C30.5 20.0582 27.9129 17.5 24.5 17.5C21.0871 17.5 18.5 20.0582 18.5 23C18.5 23.8284 17.8284 24.5 17 24.5C16.1716 24.5 15.5 23.8284 15.5 23C15.5 18.2098 19.6286 14.5 24.5 14.5ZM24 7.5C26.055 7.5 28.0201 7.90473 29.8184 8.64062C30.5848 8.95441 30.9521 9.83014 30.6387 10.5967C30.3249 11.3634 29.4483 11.7308 28.6816 11.417C27.2374 10.826 25.6581 10.5 24 10.5C17.1119 10.5 11.5 16.1503 11.5 23.1543V32C11.5 32.8284 10.8284 33.5 10 33.5C9.17157 33.5 8.5 32.8284 8.5 32V23.1543C8.5 14.5244 15.4242 7.5 24 7.5ZM34.4971 13.1328C35.1462 12.6181 36.0898 12.7268 36.6045 13.376C38.7294 16.0559 40 19.4582 40 23.1543V32C40 32.8284 39.3284 33.5 38.5 33.5C37.6716 33.5 37 32.8284 37 32V23.1543C37 20.156 35.9716 17.4056 34.2539 15.2393C33.7396 14.5903 33.8485 13.6475 34.4971 13.1328Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Fingerprint48 as default };
//# sourceMappingURL=Fingerprint48.js.map
