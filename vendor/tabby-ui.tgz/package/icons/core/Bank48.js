import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Bank48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Bank48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Bank48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Bank48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M41 15.0001L24 6L7 15.0001V18.0001H41V15.0001ZM26.5 12.5001C26.5 13.8808 25.3807 15.0001 24 15.0001C22.6193 15.0001 21.5 13.8808 21.5 12.5001C21.5 11.1194 22.6193 10.0001 24 10.0001C25.3807 10.0001 26.5 11.1194 26.5 12.5001ZM15.5 20H11.5V32H8.5V35H39.5V32H36.5V20H32.5V32H29.5V20.0001H25.5V32H22.5V20.0001H18.5V32H15.5V20ZM42 40V37H6V40H42Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Bank48 as default };
//# sourceMappingURL=Bank48.js.map
