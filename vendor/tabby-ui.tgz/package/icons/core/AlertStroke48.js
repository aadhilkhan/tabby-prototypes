import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function AlertStroke48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("AlertStroke48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-AlertStroke48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-AlertStroke48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M8 17.3726L17.3726 8H30.6274L40 17.3726V30.6274L30.6274 40H17.3726L8 30.6274V17.3726ZM11 18.6152L18.6152 11H29.3848L37 18.6152V29.3848L29.3848 37H18.6152L11 29.3848V18.6152ZM22.5 15H25.5V26H22.5V15ZM26 30.5C26 31.6046 25.1046 32.5 24 32.5C22.8954 32.5 22 31.6046 22 30.5C22 29.3954 22.8954 28.5 24 28.5C25.1046 28.5 26 29.3954 26 30.5Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { AlertStroke48 as default };
//# sourceMappingURL=AlertStroke48.js.map
