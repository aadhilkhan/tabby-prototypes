import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Flowers24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Flowers24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Flowers24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Flowers24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M18 2C14.6863 2 12 4.68629 12 8C12 5.79086 10.2091 4 8 4H7V5C7 7.20914 8.79086 9 11 9V12H5V13.3333C5 13.7015 5.44772 14 6 14H18C18.5523 14 19 13.7015 19 13.3333V12H13V9C16.3137 9 19 6.31371 19 3V2H18ZM7.72147 20.3288L7 16H17L16.2785 20.3288C16.1178 21.2932 15.2834 22 14.3057 22H9.69425C8.71658 22 7.8822 21.2932 7.72147 20.3288Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Flowers24 as default };
//# sourceMappingURL=Flowers24.js.map
