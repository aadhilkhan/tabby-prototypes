import Agent24 from './Agent24.js';
import Agent48 from './Agent48.js';
import AlertCircleStroke16 from './AlertCircleStroke16.js';
import AlertCircleStroke24 from './AlertCircleStroke24.js';
import AlertCircleStrokeFill24 from './AlertCircleStrokeFill24.js';
import AlertFill24 from './AlertFill24.js';
import AlertFill48 from './AlertFill48.js';
import AlertStroke16 from './AlertStroke16.js';
import AlertStroke24 from './AlertStroke24.js';
import AlertStroke48 from './AlertStroke48.js';
import Arabic16 from './Arabic16.js';
import Arabic24 from './Arabic24.js';
import ArchiveBox24 from './ArchiveBox24.js';
import ArrowBack24 from './ArrowBack24.js';
import ArrowDown16 from './ArrowDown16.js';
import ArrowDown24 from './ArrowDown24.js';
import ArrowDown48 from './ArrowDown48.js';
import ArrowForward24 from './ArrowForward24.js';
import ArrowIn24 from './ArrowIn24.js';
import ArrowOut24 from './ArrowOut24.js';
import ArrowOut48 from './ArrowOut48.js';
import ArrowOutside16 from './ArrowOutside16.js';
import ArrowOutside24 from './ArrowOutside24.js';
import ArrowUp24 from './ArrowUp24.js';
import ArtAndAntiques24 from './ArtAndAntiques24.js';
import Attachment24 from './Attachment24.js';
import Auto24 from './Auto24.js';
import Backspace24 from './Backspace24.js';
import Backspace48 from './Backspace48.js';
import BagFill24 from './BagFill24.js';
import BagFill48 from './BagFill48.js';
import BagStroke24 from './BagStroke24.js';
import BagStroke48 from './BagStroke48.js';
import Bank24 from './Bank24.js';
import Bank48 from './Bank48.js';
import Bcc24 from './Bcc24.js';
import Beauty24 from './Beauty24.js';
import Beauty64 from './Beauty64.js';
import Bell24 from './Bell24.js';
import Bell48 from './Bell48.js';
import BellCrossed24 from './BellCrossed24.js';
import Bills24 from './Bills24.js';
import Biometrics24 from './Biometrics24.js';
import Biometrics48 from './Biometrics48.js';
import Bold24 from './Bold24.js';
import Book16 from './Book16.js';
import Book24 from './Book24.js';
import Books24 from './Books24.js';
import Breadcrumbs24 from './Breadcrumbs24.js';
import BrokenHeartFill24 from './BrokenHeartFill24.js';
import BulletedList24 from './BulletedList24.js';
import CC24 from './CC24.js';
import CSV24 from './CSV24.js';
import CVV24 from './CVV24.js';
import Calendar16 from './Calendar16.js';
import Calendar24 from './Calendar24.js';
import Call48 from './Call48.js';
import Camera24 from './Camera24.js';
import CameraFill24 from './CameraFill24.js';
import CameraStroke24 from './CameraStroke24.js';
import Cancel16 from './Cancel16.js';
import Cancel24 from './Cancel24.js';
import Cancel48 from './Cancel48.js';
import Card16 from './Card16.js';
import Card24 from './Card24.js';
import Card48 from './Card48.js';
import CardFailure24 from './CardFailure24.js';
import CardFailure48 from './CardFailure48.js';
import CardPayMinimum24 from './CardPayMinimum24.js';
import CardPayTotal24 from './CardPayTotal24.js';
import CardReissue24 from './CardReissue24.js';
import CardReissue48 from './CardReissue48.js';
import Case24 from './Case24.js';
import CashWithdrawals24 from './CashWithdrawals24.js';
import Cashback16 from './Cashback16.js';
import Cashback24 from './Cashback24.js';
import Catalogue24 from './Catalogue24.js';
import Catalogue48 from './Catalogue48.js';
import ChartA24 from './ChartA24.js';
import ChartB24 from './ChartB24.js';
import Chat16 from './Chat16.js';
import Chat24 from './Chat24.js';
import Chat48 from './Chat48.js';
import Chatbot24 from './Chatbot24.js';
import CheckCircle24 from './CheckCircle24.js';
import CheckCircle48 from './CheckCircle48.js';
import CheckDouble16 from './CheckDouble16.js';
import CheckDouble24 from './CheckDouble24.js';
import CheckM16 from './CheckM16.js';
import CheckM24 from './CheckM24.js';
import CheckM48 from './CheckM48.js';
import CheckS24 from './CheckS24.js';
import ChevronBack24 from './ChevronBack24.js';
import ChevronDown16 from './ChevronDown16.js';
import ChevronDown24 from './ChevronDown24.js';
import ChevronForward16 from './ChevronForward16.js';
import ChevronForward24 from './ChevronForward24.js';
import ChevronUp16 from './ChevronUp16.js';
import ChevronUp24 from './ChevronUp24.js';
import ChildrenProducts24 from './ChildrenProducts24.js';
import Cinema24 from './Cinema24.js';
import CircleDashed24 from './CircleDashed24.js';
import Clock16 from './Clock16.js';
import Clock24 from './Clock24.js';
import Clock48 from './Clock48.js';
import ClockCrossedOut24 from './ClockCrossedOut24.js';
import Close16 from './Close16.js';
import Close24 from './Close24.js';
import Clothing24 from './Clothing24.js';
import Code24 from './Code24.js';
import Coin24 from './Coin24.js';
import Collapse24 from './Collapse24.js';
import Columns16 from './Columns16.js';
import Columns24 from './Columns24.js';
import ContactlessPay24 from './ContactlessPay24.js';
import Copy16 from './Copy16.js';
import Copy24 from './Copy24.js';
import Coupon16 from './Coupon16.js';
import Coupon24 from './Coupon24.js';
import CrossFill24 from './CrossFill24.js';
import CrossFill48 from './CrossFill48.js';
import CrossStroke24 from './CrossStroke24.js';
import CrossStroke48 from './CrossStroke48.js';
import Data24 from './Data24.js';
import DateExtended24 from './DateExtended24.js';
import DateExtension16 from './DateExtension16.js';
import DateExtension24 from './DateExtension24.js';
import DateExtension48 from './DateExtension48.js';
import Deal16 from './Deal16.js';
import Deal24 from './Deal24.js';
import Desktop24 from './Desktop24.js';
import Desktop48 from './Desktop48.js';
import Devices24 from './Devices24.js';
import DigitalMediaGoods24 from './DigitalMediaGoods24.js';
import Dirham24 from './Dirham24.js';
import DocSign24 from './DocSign24.js';
import DocSign48 from './DocSign48.js';
import Document24 from './Document24.js';
import DocumentsListBidirectional_Handoff24 from './DocumentsListBidirectional_Handoff24.js';
import DotL16 from './DotL16.js';
import DotL24 from './DotL24.js';
import DotM16 from './DotM16.js';
import DotM24 from './DotM24.js';
import DotOutline16 from './DotOutline16.js';
import DotOutline24 from './DotOutline24.js';
import DotS16 from './DotS16.js';
import DotS24 from './DotS24.js';
import DotXL16 from './DotXL16.js';
import DotXL24 from './DotXL24.js';
import DotXS16 from './DotXS16.js';
import DotXS24 from './DotXS24.js';
import DoubleChevronBack24 from './DoubleChevronBack24.js';
import DoubleChevronForward24 from './DoubleChevronForward24.js';
import Downgrade24 from './Downgrade24.js';
import Download16 from './Download16.js';
import Download24 from './Download24.js';
import Download48 from './Download48.js';
import Drawer24 from './Drawer24.js';
import DutyFree24 from './DutyFree24.js';
import Edit24 from './Edit24.js';
import Education24 from './Education24.js';
import Email24 from './Email24.js';
import Emoji24 from './Emoji24.js';
import Entertainment24 from './Entertainment24.js';
import Envelope24 from './Envelope24.js';
import Expand24 from './Expand24.js';
import EyeClosed24 from './EyeClosed24.js';
import EyeOpen24 from './EyeOpen24.js';
import FaceID24 from './FaceID24.js';
import FaceID48 from './FaceID48.js';
import Feed24 from './Feed24.js';
import Feedback48 from './Feedback48.js';
import File24 from './File24.js';
import File48 from './File48.js';
import FileCheck24 from './FileCheck24.js';
import FileCheck48 from './FileCheck48.js';
import FileFailed24 from './FileFailed24.js';
import FinancialServices24 from './FinancialServices24.js';
import Fingerprint24 from './Fingerprint24.js';
import Fingerprint48 from './Fingerprint48.js';
import Fitness24 from './Fitness24.js';
import Flame24 from './Flame24.js';
import Flask24 from './Flask24.js';
import FloatingWindow24 from './FloatingWindow24.js';
import Flowers24 from './Flowers24.js';
import Folder24 from './Folder24.js';
import Folder48 from './Folder48.js';
import Food24 from './Food24.js';
import Freeze16 from './Freeze16.js';
import Freeze24 from './Freeze24.js';
import Freeze48 from './Freeze48.js';
import FullScreen24 from './FullScreen24.js';
import Furniture24 from './Furniture24.js';
import Gear24 from './Gear24.js';
import Gift16 from './Gift16.js';
import Gift24 from './Gift24.js';
import Gift48 from './Gift48.js';
import Glass24 from './Glass24.js';
import GlobalTransfer24 from './GlobalTransfer24.js';
import GlobalTransfer48 from './GlobalTransfer48.js';
import GlobalTransferNew24 from './GlobalTransferNew24.js';
import Globe24 from './Globe24.js';
import Government24 from './Government24.js';
import Graph16 from './Graph16.js';
import Graph24 from './Graph24.js';
import GraphDown24 from './GraphDown24.js';
import Grid24 from './Grid24.js';
import Groceries24 from './Groceries24.js';
import Groceries64 from './Groceries64.js';
import HandsetStart24 from './HandsetStart24.js';
import HandsetStop24 from './HandsetStop24.js';
import HeartFill24 from './HeartFill24.js';
import HeartStroke24 from './HeartStroke24.js';
import HeartStroke48 from './HeartStroke48.js';
import History24 from './History24.js';
import HomeRenovation24 from './HomeRenovation24.js';
import Hotels24 from './Hotels24.js';
import ID24 from './ID24.js';
import ID48 from './ID48.js';
import Icons24X24NavigationDoubleChevronDown24 from './Icons24X24NavigationDoubleChevronDown24.js';
import Icons24X24NavigationDoubleChevronUp24 from './Icons24X24NavigationDoubleChevronUp24.js';
import Image24 from './Image24.js';
import Info16 from './Info16.js';
import Info24 from './Info24.js';
import Info48 from './Info48.js';
import InfoFilled24 from './InfoFilled24.js';
import Instagram24 from './Instagram24.js';
import Interest24 from './Interest24.js';
import InterestXL24 from './InterestXL24.js';
import InternalPurchases24 from './InternalPurchases24.js';
import ItServices24 from './ItServices24.js';
import Italic24 from './Italic24.js';
import Items24 from './Items24.js';
import Jewellery24 from './Jewellery24.js';
import Lightning16 from './Lightning16.js';
import Lightning24 from './Lightning24.js';
import Lightning48 from './Lightning48.js';
import LightningStroke24 from './LightningStroke24.js';
import Link24 from './Link24.js';
import Linkedin24 from './Linkedin24.js';
import List24 from './List24.js';
import LockClosed16 from './LockClosed16.js';
import LockClosed24 from './LockClosed24.js';
import LockClosed48 from './LockClosed48.js';
import LockOpen24 from './LockOpen24.js';
import LockOpen48 from './LockOpen48.js';
import MapPin24 from './MapPin24.js';
import MapPin48 from './MapPin48.js';
import MapPinFill24 from './MapPinFill24.js';
import MapPinFill48 from './MapPinFill48.js';
import Marketplace24 from './Marketplace24.js';
import MedicalServices24 from './MedicalServices24.js';
import Megaphone24 from './Megaphone24.js';
import Menu24 from './Menu24.js';
import MenuBurger24 from './MenuBurger24.js';
import Microphone24 from './Microphone24.js';
import MicrophoneOff24 from './MicrophoneOff24.js';
import Minus16 from './Minus16.js';
import Minus24 from './Minus24.js';
import MoneyTransfers24 from './MoneyTransfers24.js';
import More16 from './More16.js';
import More24 from './More24.js';
import Muqasama24 from './Muqasama24.js';
import Music24 from './Music24.js';
import Navigation24 from './Navigation24.js';
import NavigationArrowBackBidirectional_Handoff24 from './NavigationArrowBackBidirectional_Handoff24.js';
import NavigationArrowForwardBidirectional_Handoff24 from './NavigationArrowForwardBidirectional_Handoff24.js';
import NavigationArrowOutsideBidirectional_Handoff24 from './NavigationArrowOutsideBidirectional_Handoff24.js';
import NavigationBreadcrumbsBidirectional_Handoff24 from './NavigationBreadcrumbsBidirectional_Handoff24.js';
import NavigationChevronBackBidirectional_Handoff24 from './NavigationChevronBackBidirectional_Handoff24.js';
import NavigationChevronForwardBidirectional_Handoff24 from './NavigationChevronForwardBidirectional_Handoff24.js';
import NavigationDoubleChevronBackBidirectional_Handoff24 from './NavigationDoubleChevronBackBidirectional_Handoff24.js';
import NavigationDoubleChevronForwardBidirectional_Handoff24 from './NavigationDoubleChevronForwardBidirectional_Handoff24.js';
import NavigationSendBidirectional_Handoff24 from './NavigationSendBidirectional_Handoff24.js';
import NoFee24 from './NoFee24.js';
import NoWiFi24 from './NoWiFi24.js';
import NoWiFi48 from './NoWiFi48.js';
import Nonprofits24 from './Nonprofits24.js';
import Note24 from './Note24.js';
import NumberedList24 from './NumberedList24.js';
import Numpad24 from './Numpad24.js';
import Numpad48 from './Numpad48.js';
import NumpadEdit24 from './NumpadEdit24.js';
import Online24 from './Online24.js';
import OnlineStroke24 from './OnlineStroke24.js';
import Options24 from './Options24.js';
import OrgStructure24 from './OrgStructure24.js';
import Other24 from './Other24.js';
import OverdueExtension24 from './OverdueExtension24.js';
import OverdueExtension48 from './OverdueExtension48.js';
import PDF24 from './PDF24.js';
import Pause24 from './Pause24.js';
import PayLater24 from './PayLater24.js';
import Payments24 from './Payments24.js';
import Peg24 from './Peg24.js';
import Percent48 from './Percent48.js';
import PetCare24 from './PetCare24.js';
import Petrol64 from './Petrol64.js';
import PetrolStations24 from './PetrolStations24.js';
import Pharmacy24 from './Pharmacy24.js';
import Pharmacy64 from './Pharmacy64.js';
import PhoneTransfer48 from './PhoneTransfer48.js';
import PhotoAndvideo24 from './PhotoAndvideo24.js';
import Pin16 from './Pin16.js';
import Pin24 from './Pin24.js';
import Pin48 from './Pin48.js';
import PlanExtension24 from './PlanExtension24.js';
import PlanExtension48 from './PlanExtension48.js';
import Plane24 from './Plane24.js';
import Plane48 from './Plane48.js';
import PlaneTickets24 from './PlaneTickets24.js';
import Play16 from './Play16.js';
import Play24 from './Play24.js';
import Plus16 from './Plus16.js';
import Plus24 from './Plus24.js';
import Plus48 from './Plus48.js';
import Privacy24 from './Privacy24.js';
import PublicTransport24 from './PublicTransport24.js';
import QRCode24 from './QRCode24.js';
import Question24 from './Question24.js';
import Question48 from './Question48.js';
import RealEstate24 from './RealEstate24.js';
import Refresh24 from './Refresh24.js';
import Refund24 from './Refund24.js';
import Refund48 from './Refund48.js';
import Restaurant64 from './Restaurant64.js';
import RestaurantsDining24 from './RestaurantsDining24.js';
import Riyal24 from './Riyal24.js';
import SafeBox24 from './SafeBox24.js';
import SafeBox48 from './SafeBox48.js';
import SafeBoxStroke24 from './SafeBoxStroke24.js';
import SafeBoxStroke48 from './SafeBoxStroke48.js';
import Search16 from './Search16.js';
import Search24 from './Search24.js';
import Search48 from './Search48.js';
import SearchFile24 from './SearchFile24.js';
import SearchFile48 from './SearchFile48.js';
import Send24 from './Send24.js';
import Server24 from './Server24.js';
import ServiceProviders24 from './ServiceProviders24.js';
import ShareAndroid24 from './ShareAndroid24.js';
import ShareiOS24 from './ShareiOS24.js';
import Shariah24 from './Shariah24.js';
import ShariahFill24 from './ShariahFill24.js';
import ShariahStroke24 from './ShariahStroke24.js';
import Shield24 from './Shield24.js';
import Shield48 from './Shield48.js';
import ShieldFill16 from './ShieldFill16.js';
import ShieldFill24 from './ShieldFill24.js';
import ShoppingBags24 from './ShoppingBags24.js';
import ShoppingBags48 from './ShoppingBags48.js';
import ShoppingBags96 from './ShoppingBags96.js';
import Signature24 from './Signature24.js';
import Smartphone24 from './Smartphone24.js';
import Smartphone48 from './Smartphone48.js';
import Sorting16 from './Sorting16.js';
import Sorting24 from './Sorting24.js';
import Sorting48 from './Sorting48.js';
import SoundOff24 from './SoundOff24.js';
import SoundOn24 from './SoundOn24.js';
import Souvenirs24 from './Souvenirs24.js';
import Sparks24 from './Sparks24.js';
import Split16 from './Split16.js';
import Split24 from './Split24.js';
import Split48 from './Split48.js';
import SplitFill24 from './SplitFill24.js';
import SplitSmall24 from './SplitSmall24.js';
import SportingGoods24 from './SportingGoods24.js';
import StarFill16 from './StarFill16.js';
import StarFill24 from './StarFill24.js';
import StarFill48 from './StarFill48.js';
import StarStroke24 from './StarStroke24.js';
import StarStroke48 from './StarStroke48.js';
import Stationery24 from './Stationery24.js';
import Store24 from './Store24.js';
import Store48 from './Store48.js';
import StoreFill24 from './StoreFill24.js';
import StoreMultiple24 from './StoreMultiple24.js';
import Strikethrough24 from './Strikethrough24.js';
import Sun24 from './Sun24.js';
import Tabby16 from './Tabby16.js';
import Tabby24 from './Tabby24.js';
import TabbyAdvance24 from './TabbyAdvance24.js';
import TabbyAdvance48 from './TabbyAdvance48.js';
import TabbyCard24 from './TabbyCard24.js';
import TabbyCardFill24 from './TabbyCardFill24.js';
import TabbyPlus16 from './TabbyPlus16.js';
import TabbyPlus24 from './TabbyPlus24.js';
import Target24 from './Target24.js';
import Taxi64 from './Taxi64.js';
import Taxis24 from './Taxis24.js';
import Telecoms24 from './Telecoms24.js';
import TextSize24 from './TextSize24.js';
import ThumbsDownFill24 from './ThumbsDownFill24.js';
import ThumbsDownStroke24 from './ThumbsDownStroke24.js';
import ThumbsUpFill24 from './ThumbsUpFill24.js';
import ThumbsUpStroke24 from './ThumbsUpStroke24.js';
import ThumbsUpStroke48 from './ThumbsUpStroke48.js';
import TikTok24 from './TikTok24.js';
import Toggle24 from './Toggle24.js';
import TrainTickets24 from './TrainTickets24.js';
import Transfer24 from './Transfer24.js';
import Transfer48 from './Transfer48.js';
import Transportation24 from './Transportation24.js';
import Trash16 from './Trash16.js';
import Trash24 from './Trash24.js';
import TravelAgencies24 from './TravelAgencies24.js';
import Underline24 from './Underline24.js';
import Unfreeze24 from './Unfreeze24.js';
import Unfreeze48 from './Unfreeze48.js';
import Upgrade24 from './Upgrade24.js';
import User16 from './User16.js';
import User24 from './User24.js';
import UserFill24 from './UserFill24.js';
import UserStandalone24 from './UserStandalone24.js';
import UserStroke24 from './UserStroke24.js';
import Users24 from './Users24.js';
import Users48 from './Users48.js';
import UsersStroke24 from './UsersStroke24.js';
import UsersStroke48 from './UsersStroke48.js';
import Utilities24 from './Utilities24.js';
import Van24 from './Van24.js';
import Van48 from './Van48.js';
import VehicleRental24 from './VehicleRental24.js';
import Verification48 from './Verification48.js';
import Video24 from './Video24.js';
import ViewAsCoworker24 from './ViewAsCoworker24.js';
import Wallet24 from './Wallet24.js';
import Wallet48 from './Wallet48.js';
import WalletFill24 from './WalletFill24.js';
import WiFi24 from './WiFi24.js';
import WiFi48 from './WiFi48.js';
import X24 from './X24.js';
import XLS24 from './XLS24.js';

const allIcons = [
  { name: "Agent24", Component: Agent24 },
  { name: "Agent48", Component: Agent48 },
  { name: "AlertCircleStroke16", Component: AlertCircleStroke16 },
  { name: "AlertCircleStroke24", Component: AlertCircleStroke24 },
  { name: "AlertCircleStrokeFill24", Component: AlertCircleStrokeFill24 },
  { name: "AlertFill24", Component: AlertFill24 },
  { name: "AlertFill48", Component: AlertFill48 },
  { name: "AlertStroke16", Component: AlertStroke16 },
  { name: "AlertStroke24", Component: AlertStroke24 },
  { name: "AlertStroke48", Component: AlertStroke48 },
  { name: "Arabic16", Component: Arabic16 },
  { name: "Arabic24", Component: Arabic24 },
  { name: "ArchiveBox24", Component: ArchiveBox24 },
  { name: "ArrowBack24", Component: ArrowBack24 },
  { name: "ArrowDown16", Component: ArrowDown16 },
  { name: "ArrowDown24", Component: ArrowDown24 },
  { name: "ArrowDown48", Component: ArrowDown48 },
  { name: "ArrowForward24", Component: ArrowForward24 },
  { name: "ArrowIn24", Component: ArrowIn24 },
  { name: "ArrowOut24", Component: ArrowOut24 },
  { name: "ArrowOut48", Component: ArrowOut48 },
  { name: "ArrowOutside16", Component: ArrowOutside16 },
  { name: "ArrowOutside24", Component: ArrowOutside24 },
  { name: "ArrowUp24", Component: ArrowUp24 },
  { name: "ArtAndAntiques24", Component: ArtAndAntiques24 },
  { name: "Attachment24", Component: Attachment24 },
  { name: "Auto24", Component: Auto24 },
  { name: "Backspace24", Component: Backspace24 },
  { name: "Backspace48", Component: Backspace48 },
  { name: "BagFill24", Component: BagFill24 },
  { name: "BagFill48", Component: BagFill48 },
  { name: "BagStroke24", Component: BagStroke24 },
  { name: "BagStroke48", Component: BagStroke48 },
  { name: "Bank24", Component: Bank24 },
  { name: "Bank48", Component: Bank48 },
  { name: "Bcc24", Component: Bcc24 },
  { name: "Beauty24", Component: Beauty24 },
  { name: "Beauty64", Component: Beauty64 },
  { name: "Bell24", Component: Bell24 },
  { name: "Bell48", Component: Bell48 },
  { name: "BellCrossed24", Component: BellCrossed24 },
  { name: "Bills24", Component: Bills24 },
  { name: "Biometrics24", Component: Biometrics24 },
  { name: "Biometrics48", Component: Biometrics48 },
  { name: "Bold24", Component: Bold24 },
  { name: "Book16", Component: Book16 },
  { name: "Book24", Component: Book24 },
  { name: "Books24", Component: Books24 },
  { name: "Breadcrumbs24", Component: Breadcrumbs24 },
  { name: "BrokenHeartFill24", Component: BrokenHeartFill24 },
  { name: "BulletedList24", Component: BulletedList24 },
  { name: "CC24", Component: CC24 },
  { name: "CSV24", Component: CSV24 },
  { name: "CVV24", Component: CVV24 },
  { name: "Calendar16", Component: Calendar16 },
  { name: "Calendar24", Component: Calendar24 },
  { name: "Call48", Component: Call48 },
  { name: "Camera24", Component: Camera24 },
  { name: "CameraFill24", Component: CameraFill24 },
  { name: "CameraStroke24", Component: CameraStroke24 },
  { name: "Cancel16", Component: Cancel16 },
  { name: "Cancel24", Component: Cancel24 },
  { name: "Cancel48", Component: Cancel48 },
  { name: "Card16", Component: Card16 },
  { name: "Card24", Component: Card24 },
  { name: "Card48", Component: Card48 },
  { name: "CardFailure24", Component: CardFailure24 },
  { name: "CardFailure48", Component: CardFailure48 },
  { name: "CardPayMinimum24", Component: CardPayMinimum24 },
  { name: "CardPayTotal24", Component: CardPayTotal24 },
  { name: "CardReissue24", Component: CardReissue24 },
  { name: "CardReissue48", Component: CardReissue48 },
  { name: "Case24", Component: Case24 },
  { name: "CashWithdrawals24", Component: CashWithdrawals24 },
  { name: "Cashback16", Component: Cashback16 },
  { name: "Cashback24", Component: Cashback24 },
  { name: "Catalogue24", Component: Catalogue24 },
  { name: "Catalogue48", Component: Catalogue48 },
  { name: "ChartA24", Component: ChartA24 },
  { name: "ChartB24", Component: ChartB24 },
  { name: "Chat16", Component: Chat16 },
  { name: "Chat24", Component: Chat24 },
  { name: "Chat48", Component: Chat48 },
  { name: "Chatbot24", Component: Chatbot24 },
  { name: "CheckCircle24", Component: CheckCircle24 },
  { name: "CheckCircle48", Component: CheckCircle48 },
  { name: "CheckDouble16", Component: CheckDouble16 },
  { name: "CheckDouble24", Component: CheckDouble24 },
  { name: "CheckM16", Component: CheckM16 },
  { name: "CheckM24", Component: CheckM24 },
  { name: "CheckM48", Component: CheckM48 },
  { name: "CheckS24", Component: CheckS24 },
  { name: "ChevronBack24", Component: ChevronBack24 },
  { name: "ChevronDown16", Component: ChevronDown16 },
  { name: "ChevronDown24", Component: ChevronDown24 },
  { name: "ChevronForward16", Component: ChevronForward16 },
  { name: "ChevronForward24", Component: ChevronForward24 },
  { name: "ChevronUp16", Component: ChevronUp16 },
  { name: "ChevronUp24", Component: ChevronUp24 },
  { name: "ChildrenProducts24", Component: ChildrenProducts24 },
  { name: "Cinema24", Component: Cinema24 },
  { name: "CircleDashed24", Component: CircleDashed24 },
  { name: "Clock16", Component: Clock16 },
  { name: "Clock24", Component: Clock24 },
  { name: "Clock48", Component: Clock48 },
  { name: "ClockCrossedOut24", Component: ClockCrossedOut24 },
  { name: "Close16", Component: Close16 },
  { name: "Close24", Component: Close24 },
  { name: "Clothing24", Component: Clothing24 },
  { name: "Code24", Component: Code24 },
  { name: "Coin24", Component: Coin24 },
  { name: "Collapse24", Component: Collapse24 },
  { name: "Columns16", Component: Columns16 },
  { name: "Columns24", Component: Columns24 },
  { name: "ContactlessPay24", Component: ContactlessPay24 },
  { name: "Copy16", Component: Copy16 },
  { name: "Copy24", Component: Copy24 },
  { name: "Coupon16", Component: Coupon16 },
  { name: "Coupon24", Component: Coupon24 },
  { name: "CrossFill24", Component: CrossFill24 },
  { name: "CrossFill48", Component: CrossFill48 },
  { name: "CrossStroke24", Component: CrossStroke24 },
  { name: "CrossStroke48", Component: CrossStroke48 },
  { name: "Data24", Component: Data24 },
  { name: "DateExtended24", Component: DateExtended24 },
  { name: "DateExtension16", Component: DateExtension16 },
  { name: "DateExtension24", Component: DateExtension24 },
  { name: "DateExtension48", Component: DateExtension48 },
  { name: "Deal16", Component: Deal16 },
  { name: "Deal24", Component: Deal24 },
  { name: "Desktop24", Component: Desktop24 },
  { name: "Desktop48", Component: Desktop48 },
  { name: "Devices24", Component: Devices24 },
  { name: "DigitalMediaGoods24", Component: DigitalMediaGoods24 },
  { name: "Dirham24", Component: Dirham24 },
  { name: "DocSign24", Component: DocSign24 },
  { name: "DocSign48", Component: DocSign48 },
  { name: "Document24", Component: Document24 },
  {
    name: "DocumentsListBidirectional_Handoff24",
    Component: DocumentsListBidirectional_Handoff24
  },
  { name: "DotL16", Component: DotL16 },
  { name: "DotL24", Component: DotL24 },
  { name: "DotM16", Component: DotM16 },
  { name: "DotM24", Component: DotM24 },
  { name: "DotOutline16", Component: DotOutline16 },
  { name: "DotOutline24", Component: DotOutline24 },
  { name: "DotS16", Component: DotS16 },
  { name: "DotS24", Component: DotS24 },
  { name: "DotXL16", Component: DotXL16 },
  { name: "DotXL24", Component: DotXL24 },
  { name: "DotXS16", Component: DotXS16 },
  { name: "DotXS24", Component: DotXS24 },
  { name: "DoubleChevronBack24", Component: DoubleChevronBack24 },
  { name: "DoubleChevronForward24", Component: DoubleChevronForward24 },
  { name: "Downgrade24", Component: Downgrade24 },
  { name: "Download16", Component: Download16 },
  { name: "Download24", Component: Download24 },
  { name: "Download48", Component: Download48 },
  { name: "Drawer24", Component: Drawer24 },
  { name: "DutyFree24", Component: DutyFree24 },
  { name: "Edit24", Component: Edit24 },
  { name: "Education24", Component: Education24 },
  { name: "Email24", Component: Email24 },
  { name: "Emoji24", Component: Emoji24 },
  { name: "Entertainment24", Component: Entertainment24 },
  { name: "Envelope24", Component: Envelope24 },
  { name: "Expand24", Component: Expand24 },
  { name: "EyeClosed24", Component: EyeClosed24 },
  { name: "EyeOpen24", Component: EyeOpen24 },
  { name: "FaceID24", Component: FaceID24 },
  { name: "FaceID48", Component: FaceID48 },
  { name: "Feed24", Component: Feed24 },
  { name: "Feedback48", Component: Feedback48 },
  { name: "File24", Component: File24 },
  { name: "File48", Component: File48 },
  { name: "FileCheck24", Component: FileCheck24 },
  { name: "FileCheck48", Component: FileCheck48 },
  { name: "FileFailed24", Component: FileFailed24 },
  { name: "FinancialServices24", Component: FinancialServices24 },
  { name: "Fingerprint24", Component: Fingerprint24 },
  { name: "Fingerprint48", Component: Fingerprint48 },
  { name: "Fitness24", Component: Fitness24 },
  { name: "Flame24", Component: Flame24 },
  { name: "Flask24", Component: Flask24 },
  { name: "FloatingWindow24", Component: FloatingWindow24 },
  { name: "Flowers24", Component: Flowers24 },
  { name: "Folder24", Component: Folder24 },
  { name: "Folder48", Component: Folder48 },
  { name: "Food24", Component: Food24 },
  { name: "Freeze16", Component: Freeze16 },
  { name: "Freeze24", Component: Freeze24 },
  { name: "Freeze48", Component: Freeze48 },
  { name: "FullScreen24", Component: FullScreen24 },
  { name: "Furniture24", Component: Furniture24 },
  { name: "Gear24", Component: Gear24 },
  { name: "Gift16", Component: Gift16 },
  { name: "Gift24", Component: Gift24 },
  { name: "Gift48", Component: Gift48 },
  { name: "Glass24", Component: Glass24 },
  { name: "GlobalTransfer24", Component: GlobalTransfer24 },
  { name: "GlobalTransfer48", Component: GlobalTransfer48 },
  { name: "GlobalTransferNew24", Component: GlobalTransferNew24 },
  { name: "Globe24", Component: Globe24 },
  { name: "Government24", Component: Government24 },
  { name: "Graph16", Component: Graph16 },
  { name: "Graph24", Component: Graph24 },
  { name: "GraphDown24", Component: GraphDown24 },
  { name: "Grid24", Component: Grid24 },
  { name: "Groceries24", Component: Groceries24 },
  { name: "Groceries64", Component: Groceries64 },
  { name: "HandsetStart24", Component: HandsetStart24 },
  { name: "HandsetStop24", Component: HandsetStop24 },
  { name: "HeartFill24", Component: HeartFill24 },
  { name: "HeartStroke24", Component: HeartStroke24 },
  { name: "HeartStroke48", Component: HeartStroke48 },
  { name: "History24", Component: History24 },
  { name: "HomeRenovation24", Component: HomeRenovation24 },
  { name: "Hotels24", Component: Hotels24 },
  { name: "ID24", Component: ID24 },
  { name: "ID48", Component: ID48 },
  {
    name: "Icons24X24NavigationDoubleChevronDown24",
    Component: Icons24X24NavigationDoubleChevronDown24
  },
  {
    name: "Icons24X24NavigationDoubleChevronUp24",
    Component: Icons24X24NavigationDoubleChevronUp24
  },
  { name: "Image24", Component: Image24 },
  { name: "Info16", Component: Info16 },
  { name: "Info24", Component: Info24 },
  { name: "Info48", Component: Info48 },
  { name: "InfoFilled24", Component: InfoFilled24 },
  { name: "Instagram24", Component: Instagram24 },
  { name: "Interest24", Component: Interest24 },
  { name: "InterestXL24", Component: InterestXL24 },
  { name: "InternalPurchases24", Component: InternalPurchases24 },
  { name: "ItServices24", Component: ItServices24 },
  { name: "Italic24", Component: Italic24 },
  { name: "Items24", Component: Items24 },
  { name: "Jewellery24", Component: Jewellery24 },
  { name: "Lightning16", Component: Lightning16 },
  { name: "Lightning24", Component: Lightning24 },
  { name: "Lightning48", Component: Lightning48 },
  { name: "LightningStroke24", Component: LightningStroke24 },
  { name: "Link24", Component: Link24 },
  { name: "Linkedin24", Component: Linkedin24 },
  { name: "List24", Component: List24 },
  { name: "LockClosed16", Component: LockClosed16 },
  { name: "LockClosed24", Component: LockClosed24 },
  { name: "LockClosed48", Component: LockClosed48 },
  { name: "LockOpen24", Component: LockOpen24 },
  { name: "LockOpen48", Component: LockOpen48 },
  { name: "MapPin24", Component: MapPin24 },
  { name: "MapPin48", Component: MapPin48 },
  { name: "MapPinFill24", Component: MapPinFill24 },
  { name: "MapPinFill48", Component: MapPinFill48 },
  { name: "Marketplace24", Component: Marketplace24 },
  { name: "MedicalServices24", Component: MedicalServices24 },
  { name: "Megaphone24", Component: Megaphone24 },
  { name: "Menu24", Component: Menu24 },
  { name: "MenuBurger24", Component: MenuBurger24 },
  { name: "Microphone24", Component: Microphone24 },
  { name: "MicrophoneOff24", Component: MicrophoneOff24 },
  { name: "Minus16", Component: Minus16 },
  { name: "Minus24", Component: Minus24 },
  { name: "MoneyTransfers24", Component: MoneyTransfers24 },
  { name: "More16", Component: More16 },
  { name: "More24", Component: More24 },
  { name: "Muqasama24", Component: Muqasama24 },
  { name: "Music24", Component: Music24 },
  { name: "Navigation24", Component: Navigation24 },
  {
    name: "NavigationArrowBackBidirectional_Handoff24",
    Component: NavigationArrowBackBidirectional_Handoff24
  },
  {
    name: "NavigationArrowForwardBidirectional_Handoff24",
    Component: NavigationArrowForwardBidirectional_Handoff24
  },
  {
    name: "NavigationArrowOutsideBidirectional_Handoff24",
    Component: NavigationArrowOutsideBidirectional_Handoff24
  },
  {
    name: "NavigationBreadcrumbsBidirectional_Handoff24",
    Component: NavigationBreadcrumbsBidirectional_Handoff24
  },
  {
    name: "NavigationChevronBackBidirectional_Handoff24",
    Component: NavigationChevronBackBidirectional_Handoff24
  },
  {
    name: "NavigationChevronForwardBidirectional_Handoff24",
    Component: NavigationChevronForwardBidirectional_Handoff24
  },
  {
    name: "NavigationDoubleChevronBackBidirectional_Handoff24",
    Component: NavigationDoubleChevronBackBidirectional_Handoff24
  },
  {
    name: "NavigationDoubleChevronForwardBidirectional_Handoff24",
    Component: NavigationDoubleChevronForwardBidirectional_Handoff24
  },
  {
    name: "NavigationSendBidirectional_Handoff24",
    Component: NavigationSendBidirectional_Handoff24
  },
  { name: "NoFee24", Component: NoFee24 },
  { name: "NoWiFi24", Component: NoWiFi24 },
  { name: "NoWiFi48", Component: NoWiFi48 },
  { name: "Nonprofits24", Component: Nonprofits24 },
  { name: "Note24", Component: Note24 },
  { name: "NumberedList24", Component: NumberedList24 },
  { name: "Numpad24", Component: Numpad24 },
  { name: "Numpad48", Component: Numpad48 },
  { name: "NumpadEdit24", Component: NumpadEdit24 },
  { name: "Online24", Component: Online24 },
  { name: "OnlineStroke24", Component: OnlineStroke24 },
  { name: "Options24", Component: Options24 },
  { name: "OrgStructure24", Component: OrgStructure24 },
  { name: "Other24", Component: Other24 },
  { name: "OverdueExtension24", Component: OverdueExtension24 },
  { name: "OverdueExtension48", Component: OverdueExtension48 },
  { name: "PDF24", Component: PDF24 },
  { name: "Pause24", Component: Pause24 },
  { name: "PayLater24", Component: PayLater24 },
  { name: "Payments24", Component: Payments24 },
  { name: "Peg24", Component: Peg24 },
  { name: "Percent48", Component: Percent48 },
  { name: "PetCare24", Component: PetCare24 },
  { name: "Petrol64", Component: Petrol64 },
  { name: "PetrolStations24", Component: PetrolStations24 },
  { name: "Pharmacy24", Component: Pharmacy24 },
  { name: "Pharmacy64", Component: Pharmacy64 },
  { name: "PhoneTransfer48", Component: PhoneTransfer48 },
  { name: "PhotoAndvideo24", Component: PhotoAndvideo24 },
  { name: "Pin16", Component: Pin16 },
  { name: "Pin24", Component: Pin24 },
  { name: "Pin48", Component: Pin48 },
  { name: "PlanExtension24", Component: PlanExtension24 },
  { name: "PlanExtension48", Component: PlanExtension48 },
  { name: "Plane24", Component: Plane24 },
  { name: "Plane48", Component: Plane48 },
  { name: "PlaneTickets24", Component: PlaneTickets24 },
  { name: "Play16", Component: Play16 },
  { name: "Play24", Component: Play24 },
  { name: "Plus16", Component: Plus16 },
  { name: "Plus24", Component: Plus24 },
  { name: "Plus48", Component: Plus48 },
  { name: "Privacy24", Component: Privacy24 },
  { name: "PublicTransport24", Component: PublicTransport24 },
  { name: "QRCode24", Component: QRCode24 },
  { name: "Question24", Component: Question24 },
  { name: "Question48", Component: Question48 },
  { name: "RealEstate24", Component: RealEstate24 },
  { name: "Refresh24", Component: Refresh24 },
  { name: "Refund24", Component: Refund24 },
  { name: "Refund48", Component: Refund48 },
  { name: "Restaurant64", Component: Restaurant64 },
  { name: "RestaurantsDining24", Component: RestaurantsDining24 },
  { name: "Riyal24", Component: Riyal24 },
  { name: "SafeBox24", Component: SafeBox24 },
  { name: "SafeBox48", Component: SafeBox48 },
  { name: "SafeBoxStroke24", Component: SafeBoxStroke24 },
  { name: "SafeBoxStroke48", Component: SafeBoxStroke48 },
  { name: "Search16", Component: Search16 },
  { name: "Search24", Component: Search24 },
  { name: "Search48", Component: Search48 },
  { name: "SearchFile24", Component: SearchFile24 },
  { name: "SearchFile48", Component: SearchFile48 },
  { name: "Send24", Component: Send24 },
  { name: "Server24", Component: Server24 },
  { name: "ServiceProviders24", Component: ServiceProviders24 },
  { name: "ShareAndroid24", Component: ShareAndroid24 },
  { name: "ShareiOS24", Component: ShareiOS24 },
  { name: "Shariah24", Component: Shariah24 },
  { name: "ShariahFill24", Component: ShariahFill24 },
  { name: "ShariahStroke24", Component: ShariahStroke24 },
  { name: "Shield24", Component: Shield24 },
  { name: "Shield48", Component: Shield48 },
  { name: "ShieldFill16", Component: ShieldFill16 },
  { name: "ShieldFill24", Component: ShieldFill24 },
  { name: "ShoppingBags24", Component: ShoppingBags24 },
  { name: "ShoppingBags48", Component: ShoppingBags48 },
  { name: "ShoppingBags96", Component: ShoppingBags96 },
  { name: "Signature24", Component: Signature24 },
  { name: "Smartphone24", Component: Smartphone24 },
  { name: "Smartphone48", Component: Smartphone48 },
  { name: "Sorting16", Component: Sorting16 },
  { name: "Sorting24", Component: Sorting24 },
  { name: "Sorting48", Component: Sorting48 },
  { name: "SoundOff24", Component: SoundOff24 },
  { name: "SoundOn24", Component: SoundOn24 },
  { name: "Souvenirs24", Component: Souvenirs24 },
  { name: "Sparks24", Component: Sparks24 },
  { name: "Split16", Component: Split16 },
  { name: "Split24", Component: Split24 },
  { name: "Split48", Component: Split48 },
  { name: "SplitFill24", Component: SplitFill24 },
  { name: "SplitSmall24", Component: SplitSmall24 },
  { name: "SportingGoods24", Component: SportingGoods24 },
  { name: "StarFill16", Component: StarFill16 },
  { name: "StarFill24", Component: StarFill24 },
  { name: "StarFill48", Component: StarFill48 },
  { name: "StarStroke24", Component: StarStroke24 },
  { name: "StarStroke48", Component: StarStroke48 },
  { name: "Stationery24", Component: Stationery24 },
  { name: "Store24", Component: Store24 },
  { name: "Store48", Component: Store48 },
  { name: "StoreFill24", Component: StoreFill24 },
  { name: "StoreMultiple24", Component: StoreMultiple24 },
  { name: "Strikethrough24", Component: Strikethrough24 },
  { name: "Sun24", Component: Sun24 },
  { name: "Tabby16", Component: Tabby16 },
  { name: "Tabby24", Component: Tabby24 },
  { name: "TabbyAdvance24", Component: TabbyAdvance24 },
  { name: "TabbyAdvance48", Component: TabbyAdvance48 },
  { name: "TabbyCard24", Component: TabbyCard24 },
  { name: "TabbyCardFill24", Component: TabbyCardFill24 },
  { name: "TabbyPlus16", Component: TabbyPlus16 },
  { name: "TabbyPlus24", Component: TabbyPlus24 },
  { name: "Target24", Component: Target24 },
  { name: "Taxi64", Component: Taxi64 },
  { name: "Taxis24", Component: Taxis24 },
  { name: "Telecoms24", Component: Telecoms24 },
  { name: "TextSize24", Component: TextSize24 },
  { name: "ThumbsDownFill24", Component: ThumbsDownFill24 },
  { name: "ThumbsDownStroke24", Component: ThumbsDownStroke24 },
  { name: "ThumbsUpFill24", Component: ThumbsUpFill24 },
  { name: "ThumbsUpStroke24", Component: ThumbsUpStroke24 },
  { name: "ThumbsUpStroke48", Component: ThumbsUpStroke48 },
  { name: "TikTok24", Component: TikTok24 },
  { name: "Toggle24", Component: Toggle24 },
  { name: "TrainTickets24", Component: TrainTickets24 },
  { name: "Transfer24", Component: Transfer24 },
  { name: "Transfer48", Component: Transfer48 },
  { name: "Transportation24", Component: Transportation24 },
  { name: "Trash16", Component: Trash16 },
  { name: "Trash24", Component: Trash24 },
  { name: "TravelAgencies24", Component: TravelAgencies24 },
  { name: "Underline24", Component: Underline24 },
  { name: "Unfreeze24", Component: Unfreeze24 },
  { name: "Unfreeze48", Component: Unfreeze48 },
  { name: "Upgrade24", Component: Upgrade24 },
  { name: "User16", Component: User16 },
  { name: "User24", Component: User24 },
  { name: "UserFill24", Component: UserFill24 },
  { name: "UserStandalone24", Component: UserStandalone24 },
  { name: "UserStroke24", Component: UserStroke24 },
  { name: "Users24", Component: Users24 },
  { name: "Users48", Component: Users48 },
  { name: "UsersStroke24", Component: UsersStroke24 },
  { name: "UsersStroke48", Component: UsersStroke48 },
  { name: "Utilities24", Component: Utilities24 },
  { name: "Van24", Component: Van24 },
  { name: "Van48", Component: Van48 },
  { name: "VehicleRental24", Component: VehicleRental24 },
  { name: "Verification48", Component: Verification48 },
  { name: "Video24", Component: Video24 },
  { name: "ViewAsCoworker24", Component: ViewAsCoworker24 },
  { name: "Wallet24", Component: Wallet24 },
  { name: "Wallet48", Component: Wallet48 },
  { name: "WalletFill24", Component: WalletFill24 },
  { name: "WiFi24", Component: WiFi24 },
  { name: "WiFi48", Component: WiFi48 },
  { name: "X24", Component: X24 },
  { name: "XLS24", Component: XLS24 }
];

export { allIcons };
//# sourceMappingURL=allIcons.js.map
