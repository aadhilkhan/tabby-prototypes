import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Columns24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Columns24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Columns24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Columns24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M4.86109 4.99854C4.38249 4.99854 3.90476 5.32422 3.90476 6V18C3.90476 18.5984 4.27379 19 4.85714 19H8V4.99854H4.86109ZM10 4.99854V19H14V4.99854H10ZM19.1496 19H16V4.99854H19.157C19.6481 4.99854 20.0935 5.493 20.0935 5.99219V18C20.0935 18.5761 19.6261 19 19.1496 19ZM2 6C2 4.34315 3.27919 3 4.85714 3H19.1429C20.7208 3 22 4.34315 22 6V18C22 19.6569 20.7208 21 19.1429 21H4.85714C3.27919 21 2 19.6569 2 18V6Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Columns24 as default };
//# sourceMappingURL=Columns24.js.map
