import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function DocSign48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("DocSign48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-DocSign48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-DocSign48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M14 7H25V15C25 17.2091 26.7909 19 29 19H37V38C37 39.6569 35.6569 41 34 41H22V44H34C37.3137 44 40 41.3137 40 38V17.6569C40 16.596 39.5786 15.5786 38.8284 14.8284L29.1794 5.17939C28.4292 4.42924 27.4118 4.00781 26.351 4.00781H25V4H14C10.6863 4 8 6.68629 8 10V30H11V10C11 8.34315 12.3431 7 14 7ZM28 15V8.24264L35.7574 16H29C28.4477 16 28 15.5523 28 15ZM23.3631 24C22.7542 24 22.1512 24.1199 21.5887 24.353C21.0261 24.586 20.5149 24.9275 20.0844 25.3581L8.43934 37.0031C8.15804 37.2844 8 37.666 8 38.0638V42.5C8 43.3284 8.67157 44 9.5 44H13.9362C14.334 44 14.7156 43.842 14.9969 43.5607L26.6419 31.9156C27.0725 31.4851 27.414 30.9739 27.647 30.4113C27.8801 29.8487 28 29.2458 28 28.6369C28 28.028 27.8801 27.425 27.647 26.8624C27.414 26.2998 27.0725 25.7887 26.6419 25.3581C26.2113 24.9275 25.7002 24.586 25.1376 24.353C24.575 24.1199 23.9721 24 23.3631 24ZM22.7367 27.1246C22.9353 27.0423 23.1482 27 23.3631 27C23.5781 27 23.7909 27.0423 23.9895 27.1246C24.1881 27.2069 24.3686 27.3274 24.5206 27.4794C24.6726 27.6314 24.7931 27.8119 24.8754 28.0105C24.9577 28.2091 25 28.4219 25 28.6369C25 28.8518 24.9577 29.0647 24.8754 29.2633C24.7931 29.4619 24.6726 29.6423 24.5206 29.7943L13.3149 41H11V38.6851L22.2057 27.4794C22.3577 27.3274 22.5381 27.2069 22.7367 27.1246Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { DocSign48 as default };
//# sourceMappingURL=DocSign48.js.map
