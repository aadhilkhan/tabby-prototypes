import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Education24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Education24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Education24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Education24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M18 15.4785C18 16.2523 17.6284 16.9728 17.0342 17.3438L12.3916 20.2373C11.8345 20.5871 11.1655 20.5871 10.6084 20.2373L5.96582 17.3438C5.37156 16.9728 5.00001 16.2523 5 15.4785V12.5L10.6084 15.998C11.1655 16.3478 11.8345 16.3478 12.3916 15.998L18 12.5V15.4785ZM10.5596 3.72949C11.1334 3.42363 11.8217 3.42359 12.3955 3.72949L21.5029 8.69434C21.8089 8.86656 22 9.1823 22 9.53613V15.668C22 16.1941 21.5691 16.624 21.043 16.624C20.5171 16.6238 20.087 16.1939 20.0869 15.668V10.0146L12.3955 14.25C11.8217 14.5655 11.1334 14.5655 10.5596 14.25L2.49512 9.81348C1.83507 9.44997 1.83507 8.49339 2.49512 8.12988L10.5596 3.72949Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Education24 as default };
//# sourceMappingURL=Education24.js.map
