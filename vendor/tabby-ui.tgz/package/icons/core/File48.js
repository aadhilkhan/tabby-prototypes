import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function File48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("File48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-File48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-File48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M14 7H25V15C25 17.2091 26.7909 19 29 19H37V38C37 39.6569 35.6569 41 34 41H14C12.3431 41 11 39.6569 11 38V10C11 8.34315 12.3431 7 14 7ZM40 19V38C40 41.3137 37.3137 44 34 44H14C10.6863 44 8 41.3137 8 38V10C8 6.68629 10.6863 4 14 4H25V4.00781H26.351C27.4118 4.00781 28.4292 4.42924 29.1794 5.17939L38.8284 14.8284C39.5786 15.5786 40 16.596 40 17.6569V19ZM28 15V8.24264L35.7574 16H29C28.4477 16 28 15.5523 28 15ZM14 16H22V19H14V16ZM34 22H14V25H34V22ZM14 28H34V31H14V28ZM34 34H14V37H34V34Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { File48 as default };
//# sourceMappingURL=File48.js.map
