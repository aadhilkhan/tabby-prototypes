import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function EyeClosed24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("EyeClosed24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-EyeClosed24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-EyeClosed24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M20.4854 3.51468L19.0712 2.10046L15.577 5.59464C14.4556 5.20923 13.2523 5 12.0001 5C7.33615 5 3.35017 7.90258 1.75 11.9999C2.41028 13.6907 3.47685 15.178 4.82968 16.342L2.1006 19.071L3.51482 20.4852L6.48212 17.5179C6.48214 17.5179 6.48215 17.5179 6.48217 17.518L7.95711 16.043C7.9571 16.043 7.95709 16.043 7.95707 16.043L9.52522 14.4748C9.52523 14.4749 9.52524 14.4749 9.52525 14.4749L10.9395 13.0607C10.9395 13.0606 10.9394 13.0606 10.9394 13.0606L13.0608 10.9393C13.0608 10.9393 13.0608 10.9393 13.0608 10.9393L14.475 9.52513C14.475 9.52512 14.475 9.5251 14.475 9.52509L16.0431 7.95697C16.0431 7.95698 16.0431 7.95699 16.0431 7.95699L17.5181 6.48205C17.5181 6.48204 17.518 6.48203 17.518 6.48202L20.4854 3.51468ZM13.958 7.2136C13.3276 7.07374 12.6724 7 12.0001 7C8.46916 7 5.4091 9.03398 3.93508 11.9999C4.49661 13.1298 5.28834 14.1245 6.24861 14.923L8.55438 12.6173C8.51873 12.4169 8.50012 12.2106 8.50012 12C8.50012 10.067 10.0671 8.5 12.0001 8.5C12.2107 8.5 12.417 8.5186 12.6174 8.55426L13.958 7.2136ZM15.4459 11.3827L11.3828 15.4457C11.5832 15.4814 11.7895 15.5 12.0001 15.5C13.9331 15.5 15.5001 13.933 15.5001 12C15.5001 11.7894 15.4815 11.5831 15.4459 11.3827ZM12.0002 17C11.3279 17 10.6726 16.9263 10.0422 16.7864L8.4232 18.4053C9.54462 18.7908 10.748 19 12.0002 19C16.6641 19 20.6501 16.0974 22.2502 12.0001C21.59 10.3093 20.5234 8.82194 19.1705 7.65802L17.7516 9.07695C18.7119 9.87545 19.5036 10.8702 20.0652 12.0001C18.5911 14.966 15.5311 17 12.0002 17Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { EyeClosed24 as default };
//# sourceMappingURL=EyeClosed24.js.map
