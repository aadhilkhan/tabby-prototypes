import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Cashback24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Cashback24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Cashback24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Cashback24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C8.7288 2 5.82446 3.57069 4 5.99902V5C4 4.44772 3.55228 4 3 4C2.44772 4 2 4.44772 2 5V9H2.4578H4.58152H6C6.55228 9 7 8.55228 7 8C7 7.44772 6.55228 7 6 7H5.75463C7.22075 5.17108 9.47362 4 12 4C16.4183 4 20 7.58172 20 12C20 16.4183 16.4183 20 12 20C7.58172 20 4 16.4183 4 12V11H2V12C2 17.5228 6.47715 22 12 22ZM14.918 7.66797L7.66797 14.918L9.08218 16.3322L16.3322 9.08218L14.918 7.66797ZM14.75 16.25C15.5784 16.25 16.25 15.5784 16.25 14.75C16.25 13.9216 15.5784 13.25 14.75 13.25C13.9216 13.25 13.25 13.9216 13.25 14.75C13.25 15.5784 13.9216 16.25 14.75 16.25ZM10.75 9.25006C10.75 10.0785 10.0784 10.7501 9.25 10.7501C8.42157 10.7501 7.75 10.0785 7.75 9.25006C7.75 8.42163 8.42157 7.75006 9.25 7.75006C10.0784 7.75006 10.75 8.42163 10.75 9.25006Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Cashback24 as default };
//# sourceMappingURL=Cashback24.js.map
