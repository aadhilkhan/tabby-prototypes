import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Dirham24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Dirham24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Dirham24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Dirham24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M12.0361 3C14.2512 3.00006 16.0702 3.5596 17.4932 4.67871C18.9242 5.79807 19.8546 7.36476 20.2832 9.37793H22.3086C22.5187 9.37793 22.6844 9.50718 22.8057 9.76465C22.935 10.0143 23 10.4253 23 10.9971H20.5137C20.5298 11.3192 20.5381 11.6454 20.5381 11.9756C20.5381 12.4426 20.518 12.9016 20.4775 13.3525H22.3086C22.5188 13.3525 22.6844 13.4817 22.8057 13.7393C22.935 13.9889 23 14.3999 23 14.9717H20.1865C19.7095 16.8802 18.7552 18.362 17.3242 19.417C15.9011 20.472 14.0771 21 11.8535 21H5.97168V14.9717H3.69141C3.48125 14.9717 3.311 14.8591 3.18164 14.6338C3.06036 14.4002 3 13.9727 3 13.3525H5.97168V10.9971H3.69141C3.4812 10.9971 3.31101 10.8846 3.18164 10.6592C3.06036 10.4256 3 9.99805 3 9.37793H5.97168V3H12.0361ZM8.74902 18.584H11.6963C13.2002 18.584 14.4251 18.2771 15.3711 17.665C16.317 17.0449 16.9886 16.1474 17.3848 14.9717H8.74902V18.584ZM8.74902 13.3525H17.748C17.7965 12.9177 17.8213 12.4587 17.8213 11.9756C17.8213 11.6374 17.8094 11.3111 17.7852 10.9971H8.74902V13.3525ZM8.74902 9.37793H17.5059C17.1501 8.08957 16.4987 7.10709 15.5527 6.43066C14.6067 5.7543 13.3735 5.41602 11.8535 5.41602H8.74902V9.37793Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Dirham24 as default };
//# sourceMappingURL=Dirham24.js.map
