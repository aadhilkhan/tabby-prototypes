import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function EyeOpen24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("EyeOpen24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-EyeOpen24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-EyeOpen24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M12 5C16.6639 5 20.6498 7.90268 22.25 12C20.6498 16.0973 16.6639 19 12 19C7.3361 18.9999 3.35011 16.0973 1.75 12C3.35017 7.90273 7.33612 5.00003 12 5ZM12 7C8.46916 7.00003 5.40957 9.03416 3.93555 12C5.40955 14.9658 8.46919 16.9999 12 17C15.5309 17 18.5914 14.9659 20.0654 12C18.5915 9.03397 15.531 7 12 7ZM12 8.5C13.933 8.5 15.5 10.067 15.5 12C15.5 13.933 13.933 15.5 12 15.5C10.0671 15.4999 8.5 13.933 8.5 12C8.5 10.067 10.0671 8.50007 12 8.5ZM12 10.5C11.1716 10.5001 10.5 11.1716 10.5 12C10.5 12.8284 11.1716 13.4999 12 13.5C12.8284 13.5 13.5 12.8284 13.5 12C13.5 11.1716 12.8284 10.5 12 10.5Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { EyeOpen24 as default };
//# sourceMappingURL=EyeOpen24.js.map
