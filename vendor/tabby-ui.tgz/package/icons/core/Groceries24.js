import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Groceries24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Groceries24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Groceries24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Groceries24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M20.1631 18.4551C19.9384 19.9189 18.6811 20.9998 17.2002 21H6.7998C5.31887 20.9998 4.06157 19.9189 3.83691 18.4551L3 13H21L20.1631 18.4551ZM6.61035 18.4141C6.69069 18.8961 7.10803 19.2498 7.59668 19.25H9L8.5 14.75H6L6.61035 18.4141ZM11 19.25H13L13.25 14.75H10.75L11 19.25ZM15 19.25H16.4033C16.892 19.2498 17.3093 18.8961 17.3896 18.4141L18 14.75H15.5L15 19.25ZM7.9541 9H16.0459L14 3H14.3184C14.8281 3.00006 15.303 3.259 15.5791 3.6875L19 9H22V11C22 11.5523 21.5523 12 21 12H3C2.44772 12 2 11.5523 2 11V9H5L6.70996 6.34375L8.4209 3.6875C8.69701 3.259 9.17187 3.00006 9.68164 3H10L7.9541 9Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Groceries24 as default };
//# sourceMappingURL=Groceries24.js.map
