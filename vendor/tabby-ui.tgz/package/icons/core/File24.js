import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function File24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("File24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-File24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-File24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement("path", { d: "M16 18V16H8V18H16Z", fill: "currentColor" }),
      /* @__PURE__ */ React__default.createElement("path", { d: "M16 12V14H8V12H16Z", fill: "currentColor" }),
      /* @__PURE__ */ React__default.createElement("path", { d: "M12 8H8V10H12V8Z", fill: "currentColor" }),
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M19.9321 8.02104L19.9291 8C19.4906 4.93431 17.0657 2.5094 14 2.07089C13.6734 2.02417 13.3395 2 13 2H7C5.34315 2 4 3.34315 4 5V19C4 20.6569 5.34315 22 7 22H17C18.6569 22 20 20.6569 20 19V9C20 8.66777 19.9769 8.34094 19.9321 8.02104ZM17.8723 7.87231C16.0164 7.4445 14.5555 5.98359 14.1277 4.12769C15.9836 4.5555 17.4445 6.01641 17.8723 7.87231ZM7 4H12.0709C12.5094 7.06569 14.9343 9.4906 18 9.92911V19C18 19.5523 17.5523 20 17 20H7C6.44772 20 6 19.5523 6 19V5C6 4.44772 6.44771 4 7 4Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { File24 as default };
//# sourceMappingURL=File24.js.map
