import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function BellCrossed24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("BellCrossed24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-BellCrossed24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-BellCrossed24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M13.5001 3.5C13.5001 3.72586 13.4502 3.94005 13.3608 4.13216C14.3065 4.31847 15.1838 4.69523 15.9511 5.22084L19.0714 2.10059L20.4709 3.50007L3.50031 20.4706L2.10083 19.0711L5.0001 16.1719V11C5.0001 7.59958 7.42472 4.76546 10.6394 4.13216C10.55 3.94005 10.5001 3.72586 10.5001 3.5C10.5001 2.67157 11.1717 2 12.0001 2C12.8285 2 13.5001 2.67157 13.5001 3.5ZM7.79937 19H10.0001V20C10.0001 21.1046 10.8956 22 12.0001 22C13.1047 22 14.0001 21.1046 14.0001 20V19H21.0001V17H19.0001V11C19.0001 10.0536 18.8123 9.15098 18.4719 8.32752L16.8825 9.9169C16.9595 10.2657 17.0001 10.6281 17.0001 11V17H9.79937L7.79937 19ZM12.0001 6C12.9116 6 13.7661 6.2439 14.502 6.67L7.0001 14.1719V11C7.0001 8.23858 9.23868 6 12.0001 6Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { BellCrossed24 as default };
//# sourceMappingURL=BellCrossed24.js.map
