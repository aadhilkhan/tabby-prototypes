import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function GlobalTransfer24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("GlobalTransfer24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-GlobalTransfer24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-GlobalTransfer24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M2.31504 9.5C2.10938 10.299 2 11.1368 2 12C2 12.8632 2.10938 13.701 2.31504 14.5C2.44821 15.0174 2.62174 15.5186 2.83209 16C4.3752 19.5318 7.89936 22 12 22C16.1006 22 19.6248 19.5318 21.1679 16H17.5007C16.5749 19.5318 14.4604 22 12 22V20.5C13.7197 20.5 15.2141 18.6779 15.9716 16H12V14.5H16.3022C16.4308 13.7096 16.5 12.8701 16.5 12C16.5 11.1299 16.4308 10.2904 16.3022 9.5H12V8H15.9716C15.2141 5.32211 13.7197 3.5 12 3.5V2C14.4604 2 16.5749 4.46819 17.5007 8H21.1679C19.6248 4.46819 16.1006 2 12 2C7.89936 2 4.3752 4.46819 2.83209 8C2.62174 8.48142 2.44821 8.98261 2.31504 9.5ZM12 3.51632V8H8.02841C8.75936 5.41596 10.1765 3.62876 11.8201 3.50667C11.8802 3.50919 11.9402 3.5124 12 3.51632ZM12 9.5V14.5H7.69779C7.56921 13.7096 7.5 12.8701 7.5 12C7.5 11.1299 7.56921 10.2904 7.69779 9.5H12ZM12 20.4837C11.9402 20.4876 11.8802 20.4908 11.8201 20.4933C10.1765 20.3712 8.75936 18.584 8.02841 16H12V20.4837ZM3.5 12C3.5 11.1299 3.62303 10.2904 3.85163 9.5H6.18903C6.06563 10.299 6 11.1368 6 12C6 12.8632 6.06563 13.701 6.18903 14.5H3.85163C3.62304 13.7096 3.5 12.8701 3.5 12ZM8.20704 19.7488C6.59575 18.9745 5.269 17.6497 4.43941 16H6.49925C6.88369 17.4665 7.47307 18.7496 8.20704 19.7488ZM4.43941 8C5.269 6.35035 6.59576 5.02545 8.20704 4.25122C7.47307 5.2504 6.88369 6.53351 6.49925 8H4.43941ZM21.685 9.5H17.811C17.9344 10.299 18 11.1368 18 12C18 12.8632 17.9344 13.701 17.811 14.5H21.685C21.8906 13.701 22 12.8632 22 12C22 11.1368 21.8906 10.299 21.685 9.5Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { GlobalTransfer24 as default };
//# sourceMappingURL=GlobalTransfer24.js.map
