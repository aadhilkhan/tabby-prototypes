import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Fitness24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Fitness24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Fitness24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Fitness24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M9.17149 13.4143L13.4141 9.17168L10.5857 6.34326L11.9999 4.92904C12.3904 4.53852 13.0236 4.53852 13.4141 4.92904L19.071 10.5859C19.4615 10.9764 19.4615 11.6096 19.071 12.0001L17.6568 13.4143L14.8283 10.5859L10.5857 14.8285L13.4141 17.657L11.9999 19.0712C11.6094 19.4617 10.9762 19.4617 10.5857 19.0712L4.92884 13.4143C4.53832 13.0238 4.53832 12.3906 4.92884 12.0001L6.34306 10.5859L9.17149 13.4143ZM9.17149 19.0712L8.46438 19.7783C8.07385 20.1688 7.44069 20.1688 7.05016 19.7783L6.34306 19.0712C5.95253 19.4617 5.31937 19.4617 4.92884 19.0712C4.56279 18.7051 4.53961 18.1257 4.85979 17.7329L4.92884 17.657L4.22174 16.9499C3.83121 16.5593 3.83121 15.9262 4.22174 15.5356L4.92884 14.8285L9.17149 19.0712ZM15.5354 4.22194C15.926 3.83141 16.5591 3.83141 16.9497 4.22194L17.6568 4.92904L17.7327 4.85999C18.1255 4.53981 18.7049 4.56299 19.071 4.92904C19.4615 5.31957 19.4615 5.95273 19.071 6.34326L19.7781 7.05036C20.1686 7.44089 20.1686 8.07405 19.7781 8.46458L19.071 9.17168L14.8283 4.92904L15.5354 4.22194Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Fitness24 as default };
//# sourceMappingURL=Fitness24.js.map
