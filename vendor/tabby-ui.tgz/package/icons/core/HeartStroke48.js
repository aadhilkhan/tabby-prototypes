import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function HeartStroke48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("HeartStroke48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-HeartStroke48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-HeartStroke48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M19.2091 13.9454C16.6276 11.3515 12.4307 11.3515 9.84922 13.9454C7.28325 16.5236 7.28325 20.6917 9.84922 23.2699L24 37.4882L38.1508 23.2699C40.7167 20.6917 40.7167 16.5236 38.1508 13.9454C35.5693 11.3515 31.3724 11.3515 28.7909 13.9454L24 18.7591L19.2091 13.9454ZM7.09382 11.0969C11.2034 6.96771 17.8549 6.96771 21.9645 11.0969L24 13.1421L26.0355 11.0969C30.1451 6.96771 36.7966 6.96771 40.9062 11.0969C45.0313 15.2417 45.0313 21.9736 40.9062 26.1184L25.8479 41.2485C25.3337 41.7651 24.6593 42.0118 24 41.9995C23.3407 42.0118 22.6663 41.7651 22.1521 41.2485L7.09383 26.1184C2.96873 21.9736 2.96872 15.2417 7.09382 11.0969Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { HeartStroke48 as default };
//# sourceMappingURL=HeartStroke48.js.map
