import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Deal24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Deal24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Deal24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Deal24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M14.719 3.63086L18.4661 3.10059L19.1194 6.82715L22.4612 8.60059L20.8 12L22.4612 15.3994L19.1194 17.1729L18.4661 20.8994L14.719 20.3691L12.0002 23L9.28052 20.3691L5.53442 20.8994L4.88013 17.1729L1.53833 15.3994L3.20044 12L1.53833 8.60059L4.88013 6.82715L5.53442 3.10059L9.28052 3.63086L12.0002 1L14.719 3.63086ZM7.29321 15.293L8.70728 16.707L16.7073 8.70703L15.2932 7.29297L7.29321 15.293ZM15.0002 13.5C14.1719 13.5 13.5003 14.1717 13.5002 15C13.5003 15.8283 14.1719 16.5 15.0002 16.5C15.8285 16.4998 16.5002 15.8282 16.5002 15C16.5002 14.1718 15.8285 13.5002 15.0002 13.5ZM9.00024 7.5C8.17189 7.50004 7.50031 8.17165 7.50024 9C7.50031 9.82835 8.17189 10.5 9.00024 10.5C9.82846 10.4998 10.5002 9.82825 10.5002 9C10.5002 8.17175 9.82846 7.5002 9.00024 7.5Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Deal24 as default };
//# sourceMappingURL=Deal24.js.map
