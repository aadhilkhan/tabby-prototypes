import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function ArchiveBox24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("ArchiveBox24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-ArchiveBox24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-ArchiveBox24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M19 2C20.6569 2 22 3.34315 22 5V9H21V19C21 20.6569 19.6569 22 18 22H6C4.34315 22 3 20.6569 3 19V9H2V5C2 3.34315 3.34315 2 5 2H19ZM5 19C5 19.5523 5.44772 20 6 20H18C18.5523 20 19 19.5523 19 19V9H5V19ZM15 13H9V11H15V13ZM5 4C4.44771 4 4 4.44772 4 5V7H20V5C20 4.44771 19.5523 4 19 4H5Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { ArchiveBox24 as default };
//# sourceMappingURL=ArchiveBox24.js.map
