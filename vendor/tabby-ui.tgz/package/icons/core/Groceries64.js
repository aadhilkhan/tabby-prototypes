import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Groceries64(props) {
  const { dir, className, style = {}, color = "", size = 64, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Groceries64");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Groceries64 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Groceries64",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 64 64",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M48 25L40.6682 12.9241C39.9429 11.7294 38.6466 11 37.249 11H37L41.5 25H22.5L27 11H26.751C25.3534 11 24.0571 11.7294 23.3318 12.9241L16 25H7V29C7 30.1046 7.89543 31 9 31H55C56.1046 31 57 30.1046 57 29V25H48ZM10 33H54L51.6663 47.7798C51.2826 50.2101 49.1924 52 46.732 52H32H17.268C14.8076 52 12.7174 50.2101 12.3337 47.7798L10 33ZM42.7359 46.2702L44 37H39L38 48H40.7542C41.7544 48 42.6007 47.2612 42.7359 46.2702ZM34.5 37H29.5L30 48H34L34.5 37ZM21.2641 46.2702L20 37H25L26 48H23.2458C22.2456 48 21.3993 47.2612 21.2641 46.2702Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Groceries64 as default };
//# sourceMappingURL=Groceries64.js.map
