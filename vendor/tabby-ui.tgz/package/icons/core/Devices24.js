import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Devices24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Devices24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Devices24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Devices24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M3.9 4.9V12.4C3.9 12.9523 4.34771 13.4 4.9 13.4H10.55V15.3V18.15V20.05H5.8V18.15H8.65V15.3H5H4.85C3.27599 15.3 2 14.024 2 12.45V12.3V5V4.85C2 3.27599 3.27599 2 4.85 2H5H18H18.15C19.724 2 21 3.27599 21 4.85V5V6.75H19.1V4.9C19.1 4.34772 18.6523 3.9 18.1 3.9H4.9C4.34772 3.9 3.9 4.34772 3.9 4.9ZM14.8 8C13.1432 8 11.8 9.34315 11.8 11V19C11.8 20.6569 13.1432 22 14.8 22H20C21.6569 22 23 20.6569 23 19V11C23 9.34315 21.6569 8 20.0001 8H19.2667H15.5334H14.8ZM15.5334 10.2333V9.86667H14.6667C14.1144 9.86667 13.6667 10.3144 13.6667 10.8667V19.1333C13.6667 19.6856 14.1144 20.1333 14.6667 20.1333H20.1333C20.6856 20.1333 21.1333 19.6856 21.1333 19.1333V10.8667C21.1333 10.3144 20.6856 9.86667 20.1333 9.86667H19.2667V10.2333C19.2667 11.0618 18.5951 11.7333 17.7667 11.7333H17.0334C16.205 11.7333 15.5334 11.0618 15.5334 10.2333Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Devices24 as default };
//# sourceMappingURL=Devices24.js.map
