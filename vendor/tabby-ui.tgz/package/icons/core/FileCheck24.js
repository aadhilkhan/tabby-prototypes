import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function FileCheck24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("FileCheck24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-FileCheck24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-FileCheck24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M19.9291 8L19.9321 8.02104C19.9769 8.34094 20 8.66777 20 9V19C20 20.6569 18.6569 22 17 22H7C5.34315 22 4 20.6569 4 19V5C4 3.34315 5.34315 2 7 2H13C13.3395 2 13.6734 2.02417 14 2.07089C17.0657 2.5094 19.4906 4.93431 19.9291 8ZM17.8723 7.87231C16.0164 7.4445 14.5555 5.98359 14.1277 4.12769C15.9836 4.5555 17.4445 6.01641 17.8723 7.87231ZM12.0709 4H7C6.44771 4 6 4.44772 6 5V19C6 19.5523 6.44772 20 7 20H17C17.5523 20 18 19.5523 18 19V9.92911C14.9343 9.4906 12.5094 7.06569 12.0709 4ZM11.2952 17.1488L11.3019 17.142L11.3026 17.1428L16.1726 12.2728L14.8998 11L11.2959 14.6039L9.44523 12.7533L8.17244 14.0261L11.2952 17.1488Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { FileCheck24 as default };
//# sourceMappingURL=FileCheck24.js.map
