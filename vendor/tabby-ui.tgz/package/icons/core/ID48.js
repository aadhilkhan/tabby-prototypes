import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function ID48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("ID48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-ID48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-ID48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M39 9C42.3137 9 45 11.6863 45 15V33C45 36.3137 42.3137 39 39 39H9C5.68629 39 3 36.3137 3 33V15C3 11.6863 5.68629 9 9 9H39ZM9 12C7.34315 12 6 13.3431 6 15V33C6 34.6569 7.34315 36 9 36H39C40.6569 36 42 34.6569 42 33V15C42 13.3431 40.6569 12 39 12H9ZM17 28C19.9734 28.0001 22.6103 29.2819 24.249 31.2578C24.5023 31.5632 24.2707 31.9998 23.874 32H10.126C9.72944 31.9997 9.49701 31.5632 9.75 31.2578C11.3886 29.2817 14.0264 28.0001 17 28ZM30 24C31.1046 24 32 24.8954 32 26C32 27.1046 31.1046 28 30 28C28.8954 28 28 27.1046 28 26C28 24.8954 28.8954 24 30 24ZM16.9951 16C19.7565 16 21.9951 18.2386 21.9951 21C21.9951 23.7614 19.7565 26 16.9951 26C14.2339 25.9998 11.9951 23.7613 11.9951 21C11.9951 18.2387 14.2339 16.0002 16.9951 16ZM30 18C31.1046 18 32 18.8954 32 20C32 21.1046 31.1046 22 30 22C28.8954 22 28 21.1046 28 20C28 18.8954 28.8954 18 30 18ZM36 18C37.1046 18 38 18.8954 38 20C38 21.1046 37.1046 22 36 22C34.8954 22 34 21.1046 34 20C34 18.8954 34.8954 18 36 18Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { ID48 as default };
//# sourceMappingURL=ID48.js.map
