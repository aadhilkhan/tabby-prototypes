import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Cinema24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Cinema24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Cinema24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Cinema24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M4 2L4 22L6 22L6 21L8.5 21L8.5 22L15.5 22L15.5 21L18 21L18 22L20 22L20 2L18 2L18 3.5L15.5 3.5L15.5 2L8.5 2L8.5 3.5L6 3.5L6 2L4 2ZM6 6L8.5 6L8.5 8.5L6 8.5L6 6ZM15.5 6L18 6L18 8.5L15.5 8.5L15.5 6ZM8.5 11L6 11L6 13.5L8.5 13.5L8.5 11ZM15.5 11L18 11L18 13.5L15.5 13.5L15.5 11ZM8.5 16L6 16L6 18.5L8.5 18.5L8.5 16ZM15.5 16L18 16L18 18.5L15.5 18.5L15.5 16Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Cinema24 as default };
//# sourceMappingURL=Cinema24.js.map
