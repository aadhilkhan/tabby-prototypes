import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Chatbot24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Chatbot24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Chatbot24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Chatbot24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M12 0C13.6569 0 15 1.34315 15 3C15 4.30574 14.1645 5.41299 13 5.8252V7H17C19.4703 7 21.5207 8.7918 21.9258 11.1465C23.1294 11.5367 24 12.6663 24 14C24 15.3336 23.1293 16.4622 21.9258 16.8525C21.521 19.2077 19.4707 21 17 21H7C4.52926 21 2.47792 19.2078 2.07324 16.8525C0.87019 16.462 0 15.3333 0 14C0 12.6666 0.870041 11.537 2.07324 11.1465C2.47831 8.79172 4.5296 7 7 7H11V5.8252C9.83548 5.41299 9 4.30574 9 3C9 1.34315 10.3431 0 12 0ZM7 9C5.34315 9 4 10.3431 4 12V16C4 17.6569 5.34315 19 7 19H17C18.6569 19 20 17.6569 20 16V12C20 10.3431 18.6569 9 17 9H7ZM8.5 11C10.1569 11 11.5 12.3431 11.5 14C11.5 15.6569 10.1569 17 8.5 17C6.84315 17 5.5 15.6569 5.5 14C5.5 12.3431 6.84315 11 8.5 11ZM15.5 11C17.1569 11 18.5 12.3431 18.5 14C18.5 15.6569 17.1569 17 15.5 17C13.8431 17 12.5 15.6569 12.5 14C12.5 12.3431 13.8431 11 15.5 11ZM8.5 13C7.94772 13 7.5 13.4477 7.5 14C7.5 14.5523 7.94772 15 8.5 15C9.05228 15 9.5 14.5523 9.5 14C9.5 13.4477 9.05228 13 8.5 13ZM15.5 13C14.9477 13 14.5 13.4477 14.5 14C14.5 14.5523 14.9477 15 15.5 15C16.0523 15 16.5 14.5523 16.5 14C16.5 13.4477 16.0523 13 15.5 13ZM12 2C11.4477 2 11 2.44772 11 3C11 3.55228 11.4477 4 12 4C12.5523 4 13 3.55228 13 3C13 2.44772 12.5523 2 12 2Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Chatbot24 as default };
//# sourceMappingURL=Chatbot24.js.map
