import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Clothing24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Clothing24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Clothing24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Clothing24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M14.5693 3.87278C15.1018 3.41884 15.8418 3.19786 16.438 3.56418C17.2997 4.09362 18.2019 4.8037 18.9015 5.55335C20.2343 6.98477 20.7833 8.29679 21 8.99901C20.3594 9.58596 19.2353 10.7285 18.5599 11.422C18.1993 11.7924 18 12.2886 18 12.8056V17.9999C18 20.3561 14 20.9999 12.0007 20.9999C10.0013 20.9999 6.00001 20.3557 6.00001 17.9999V12.8054C6.00001 12.2886 5.80077 11.7924 5.44021 11.4221C4.76498 10.7286 3.64097 9.586 3.00001 8.99901C3.21803 8.29679 3.76699 6.98477 5.09981 5.55335C5.96669 4.62194 6.77234 4.00294 7.55288 3.54467C8.15627 3.19042 8.89932 3.4189 9.43173 3.8729C10.9986 5.20896 13.0018 5.20892 14.5693 3.87278ZM13.75 10.7499C14.7165 10.7499 15.5 9.96641 15.5 8.99991H12C12 9.96641 12.7835 10.7499 13.75 10.7499Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Clothing24 as default };
//# sourceMappingURL=Clothing24.js.map
