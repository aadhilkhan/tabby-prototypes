import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Flask24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Flask24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Flask24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Flask24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M14 2C14.5304 2 15.039 2.21086 15.4141 2.58594C15.7891 2.96101 16 3.46957 16 4V5C16 5.26522 15.8946 5.5195 15.707 5.70703C15.5195 5.89457 15.2652 6 15 6V7.80957L20.5 17.3701C20.82 17.8401 21 18.4 21 19C21 19.7956 20.6837 20.5585 20.1211 21.1211C19.5585 21.6837 18.7956 22 18 22H6C5.20435 22 4.44152 21.6837 3.87891 21.1211C3.3163 20.5585 3 19.7956 3 19C3 18.4 3.18003 17.8401 3.5 17.3701L9 7.80957V6C8.73478 6 8.4805 5.89457 8.29297 5.70703C8.10543 5.5195 8 5.26522 8 5V4C8 3.46957 8.21087 2.96101 8.58594 2.58594C8.96101 2.21086 9.46957 2 10 2H14ZM5.17969 18.4297C5.06969 18.5897 5 18.79 5 19C5 19.2652 5.10543 19.5195 5.29297 19.707C5.48051 19.8946 5.73478 20 6 20H18C18.2652 20 18.5195 19.8946 18.707 19.707C18.8946 19.5195 19 19.2652 19 19C19 18.79 18.9303 18.5897 18.8203 18.4297L15.707 12.75H8.25L5.17969 18.4297Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Flask24 as default };
//# sourceMappingURL=Flask24.js.map
