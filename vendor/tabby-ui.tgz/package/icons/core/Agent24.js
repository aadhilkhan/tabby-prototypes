import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Agent24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Agent24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Agent24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Agent24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M12 1C18.0751 1 23 5.92487 23 12C23 18.0751 18.0751 23 12 23C11.4477 23 11 22.5523 11 22C11 21.4477 11.4477 21 12 21C15.5345 21 18.5911 18.9616 20.0635 15.9971C20.0424 15.9979 20.0212 16 20 16C18.8954 16 18 15.1046 18 14V11C18 9.89543 18.8954 9 20 9C20.1704 9 20.3374 9.0147 20.5 9.04199C19.2762 5.52492 15.934 3 12 3C8.06618 3 4.72299 5.52424 3.49902 9.04102C3.6619 9.01364 3.82934 9 4 9C5.10457 9 6 9.89543 6 11V14C6 15.1046 5.10457 16 4 16C2.34315 16 1 14.6569 1 13V12C1 11.9476 1.00125 11.8955 1.00391 11.8438C1.08751 5.84067 5.97705 1 12 1ZM9.5 11C10.3284 11 11 11.6716 11 12.5C11 13.3284 10.3284 14 9.5 14C8.67157 14 8 13.3284 8 12.5C8 11.6716 8.67157 11 9.5 11ZM14.5 11C15.3284 11 16 11.6716 16 12.5C16 13.3284 15.3284 14 14.5 14C13.6716 14 13 13.3284 13 12.5C13 11.6716 13.6716 11 14.5 11Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Agent24 as default };
//# sourceMappingURL=Agent24.js.map
