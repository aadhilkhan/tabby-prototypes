import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function CardReissue24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("CardReissue24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-CardReissue24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-CardReissue24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M24 21C24 21.5523 23.5523 22 23 22C22.4477 22 22 21.5523 22 21V20.3154C20.9255 21.9331 19.0876 22.9999 17 23C14.3878 22.9998 12.1655 21.3301 11.3418 19H13.5361C14.2278 20.1952 15.5198 20.9999 17 21C18.4801 20.9999 19.7712 20.195 20.4629 19H20C19.4477 19 19 18.5523 19 18C19 17.4477 19.4477 17 20 17H24V21ZM16 2C17.6569 2 19 3.34315 19 5V9.25195C18.3608 9.08743 17.6906 9 17 9H2V14C2 14.5523 2.44772 15 3 15H8V17H3C1.34315 17 0 15.6569 0 14V5C0 3.34315 1.34315 2 3 2H16ZM17 11C19.6122 11.0002 21.8345 12.6699 22.6582 15H20.4639C19.7722 13.8048 18.4802 13.0001 17 13C15.5199 13.0001 14.2288 13.805 13.5371 15H14C14.5523 15 15 15.4477 15 16C15 16.5523 14.5523 17 14 17H10V13C10 12.4477 10.4477 12 11 12C11.5523 12 12 12.4477 12 13V13.6846C13.0745 12.0669 14.9124 11.0001 17 11ZM3 4C2.44772 4 2 4.44772 2 5V6H17V5C17 4.44771 16.5523 4 16 4H3Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { CardReissue24 as default };
//# sourceMappingURL=CardReissue24.js.map
