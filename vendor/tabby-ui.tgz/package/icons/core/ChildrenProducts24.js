import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function ChildrenProducts24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("ChildrenProducts24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-ChildrenProducts24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-ChildrenProducts24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M11.9363 10C12.3558 9.9675 12.3558 9.36988 12.3558 9.28312V7.12684C12.3558 4.3399 14.3812 2 17.0555 2C18.2366 2 19.0853 2.32625 19.7866 2.88269L19.8114 2.90362C19.9231 2.99303 20.0314 3.08878 20.1364 3.19087C20.3158 3.36589 20.4886 3.55613 20.6546 3.76158C21.033 4.22766 20.9738 4.52347 20.477 4.64903C20.2417 4.708 20.0503 4.90584 20.0503 5.15696V8.5479C20.0506 8.63659 20.034 8.72445 20.0015 8.80648C19.9691 8.88852 19.9214 8.9631 19.8612 9.02599C19.801 9.08888 19.7295 9.13883 19.6507 9.173C19.572 9.20717 19.4875 9.22489 19.4021 9.22514H19.2877C19.0286 9.22514 18.8455 9.22514 18.5662 9.00256C18.4801 8.93133 18.3981 8.85478 18.3208 8.77333L17.0839 7.6947L17.0262 7.64999C16.9109 7.55677 16.8697 7.52348 16.7635 7.56819C16.6545 7.61289 16.5868 8.03617 16.5859 8.24162C16.5863 8.26831 16.5878 8.29497 16.5904 8.32152L17.3696 12L17.369 11.9998C17.4159 12.1327 17.4539 12.2702 17.4822 12.4117L18.5302 17.6516C17.5203 17.9162 16.4863 18.1216 15.4324 18.2638C15.0868 16.4063 13.4577 15 11.5 15C9.5861 15 7.98615 16.3442 7.59269 18.14C6.54392 17.9642 5.51643 17.7256 4.51423 17.4283L5.35677 13.2155C5.73071 11.3458 7.37237 10 9.27909 10H11.9363ZM20.9282 19.4848C20.7462 18.9655 20.1782 18.6939 19.6522 18.8556C17.233 19.5995 14.6633 20 12.0001 20C8.97853 20 6.07738 19.4845 3.37974 18.5368C2.86045 18.3544 2.28211 18.6035 2.07991 19.1154C1.87776 19.6272 2.12838 20.2078 2.64706 20.3917C8.34303 22.4104 14.5407 22.5319 20.3114 20.738C20.8369 20.5746 21.1101 20.0042 20.9282 19.4848ZM1 15.9999C1 13.0489 3.13055 10.5954 5.9374 10.0938C4.99903 10.8304 4.3173 11.8925 4.06952 13.1342L3.61731 15.4005C2.82635 15.7846 1.93833 15.9999 1 15.9999Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { ChildrenProducts24 as default };
//# sourceMappingURL=ChildrenProducts24.js.map
