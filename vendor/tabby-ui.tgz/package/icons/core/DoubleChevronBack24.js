import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function DoubleChevronBack24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("DoubleChevronBack24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-DoubleChevronBack24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-DoubleChevronBack24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M12.0711 7.75748L7.82845 12.0002L12.0711 16.2428L10.6569 17.657L5 12.0001L6.41421 10.5859L6.41423 10.5859L10.6569 6.34326L12.0711 7.75748ZM18.0711 7.75748L13.8284 12.0002L18.0711 16.2428L16.6569 17.657L11 12.0001L12.4142 10.5859L12.4142 10.5859L16.6569 6.34326L18.0711 7.75748Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { DoubleChevronBack24 as default };
//# sourceMappingURL=DoubleChevronBack24.js.map
