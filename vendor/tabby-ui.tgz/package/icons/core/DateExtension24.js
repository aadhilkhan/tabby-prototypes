import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function DateExtension24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("DateExtension24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-DateExtension24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-DateExtension24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M10 2H8V4H7C4.79086 4 3 5.79086 3 8V17C3 19.2091 4.79086 21 7 21H17C19.2091 21 21 19.2091 21 17V8C21 5.79086 19.2091 4 17 4H16V2H14V4H10V2ZM14 8V6H10V8H8V6H7C5.89543 6 5 6.89543 5 8V17C5 18.1046 5.89543 19 7 19H17C18.1046 19 19 18.1046 19 17V8C19 6.89543 18.1046 6 17 6H16V8H14ZM13 9.5H11V11.5H13V9.5ZM9 9.5V11.5H7V9.5H9ZM17 11.5V9.5H15V11.5H17ZM14.343 14.8499C13.7226 15.4094 12.901 15.7499 11.9999 15.7499C10.7107 15.7499 9.58432 15.0529 8.977 14.0152L7.72725 14.8484C8.60491 16.2884 10.1901 17.2499 11.9999 17.2499C13.2407 17.2499 14.3759 16.798 15.2499 16.0497V17.3499H16.7499V14.8499V13.3499H15.2499H12.7499V14.8499H14.343Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { DateExtension24 as default };
//# sourceMappingURL=DateExtension24.js.map
