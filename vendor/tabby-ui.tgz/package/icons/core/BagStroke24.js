import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function BagStroke24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("BagStroke24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-BagStroke24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-BagStroke24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M20.51 14.1436C20.6802 16.5261 20.7659 17.718 20.3547 18.6357C19.9933 19.4422 19.3746 20.1064 18.5959 20.5244C17.7098 21 16.515 21 14.1262 21H9.87329C7.48489 21 6.29058 20.9999 5.40454 20.5244C4.62588 20.1064 4.00718 19.4422 3.64575 18.6357C3.23452 17.718 3.31931 16.5262 3.4895 14.1436L4.00024 7H20.0002L20.51 14.1436ZM5.48462 14.2861C5.3971 15.5114 5.34231 16.3072 5.34985 16.9141C5.35715 17.4991 5.42501 17.7159 5.47095 17.8184C5.65163 18.2213 5.96081 18.5528 6.34985 18.7617C6.4488 18.8148 6.65959 18.8983 7.24243 18.9473C7.84721 18.9981 8.64483 19 9.87329 19H14.1262C15.3546 19 16.1523 18.998 16.7571 18.9473C17.3399 18.8983 17.5507 18.8148 17.6497 18.7617C18.0389 18.5528 18.3488 18.2215 18.5295 17.8184C18.5755 17.7159 18.6433 17.4991 18.6506 16.9141C18.6582 16.3072 18.6034 15.5114 18.5159 14.2861L18.1379 9H5.86255L5.48462 14.2861ZM10.0002 10C10.0002 11.1046 10.8957 12 12.0002 12C13.1047 11.9999 14.0002 11.1045 14.0002 10H16.0002C16.0002 12.2091 14.2093 13.9999 12.0002 14C9.79111 14 8.00024 12.2091 8.00024 10H10.0002ZM12.0002 2C14.2093 2.00013 16.0002 3.79094 16.0002 6H14.0002C14.0002 4.89551 13.1047 4.00013 12.0002 4C10.8957 4 10.0002 4.89543 10.0002 6H8.00024C8.00024 3.79086 9.79111 2 12.0002 2Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { BagStroke24 as default };
//# sourceMappingURL=BagStroke24.js.map
