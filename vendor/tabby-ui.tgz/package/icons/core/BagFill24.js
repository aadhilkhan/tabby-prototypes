import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function BagFill24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("BagFill24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-BagFill24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-BagFill24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M10 6C10 4.89543 10.8954 4 12 4C13.1046 4 14 4.89543 14 6H16C16 3.79086 14.2091 2 12 2C9.79086 2 8 3.79086 8 6H10ZM20 7H4.00005L3.48976 14.144C3.31956 16.5268 3.23446 17.7181 3.64576 18.6359C4.00718 19.4423 4.62551 20.1064 5.40417 20.5244C6.29027 21 7.48468 21 9.8735 21H14.1266C16.5154 21 17.7098 21 18.5959 20.5244C19.3746 20.1064 19.9929 19.4423 20.3543 18.6359C20.7656 17.7181 20.6805 16.5268 20.5103 14.144L20 7ZM12 11C13.1046 11 14 10.1046 14 9H16C16 11.2091 14.2091 13 12 13C9.79086 13 8 11.2091 8 9H10C10 10.1046 10.8954 11 12 11Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { BagFill24 as default };
//# sourceMappingURL=BagFill24.js.map
