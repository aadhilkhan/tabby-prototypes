import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Collapse24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Collapse24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Collapse24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Collapse24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M12.7084 5.31424V11.3142L14.7084 11.3142V11.3142L18.7085 11.3142V9.31422H16.1228L20.1228 5.31424L18.7086 3.90002L14.7084 7.9002V5.31424L12.7084 5.31424ZM5.29412 12.7285H11.2941L11.2941 14.7285H11.2941L11.2941 18.7285H9.29409V16.1428L5.2941 20.1428L3.87988 18.7286L7.88005 14.7285H5.29412L5.29412 12.7285Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Collapse24 as default };
//# sourceMappingURL=Collapse24.js.map
