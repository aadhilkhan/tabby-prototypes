import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Glass24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Glass24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Glass24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Glass24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M3.5 2H20.5L19.7701 9.29851C19.6713 10.2868 19.1002 11.1233 18.2941 11.5931C17.7937 11.2192 17.1727 10.9978 16.5 10.9978C15.604 10.9978 14.7997 11.3906 14.25 12.0134C13.7003 11.3906 12.896 10.9978 12 10.9978C11.104 10.9978 10.2997 11.3906 9.75 12.0134C9.20029 11.3906 8.39602 10.9978 7.5 10.9978C6.8273 10.9978 6.20631 11.2192 5.70593 11.5931C4.89979 11.1233 4.32868 10.2868 4.22985 9.29851L3.5 2ZM6.68182 18.5L6.20385 13.2423C6.46397 12.797 6.94705 12.4978 7.5 12.4978C8.32843 12.4978 9 13.1694 9 13.9978V18.5H6.68182ZM6.81818 20L7 22H17L17.1818 20H15H13.5H10.5H9H6.81818ZM17.7962 13.2423L17.3182 18.5H17.25H15V13.9978C15 13.1694 15.6716 12.4978 16.5 12.4978C17.053 12.4978 17.536 12.797 17.7962 13.2423ZM12 12.4978C12.8284 12.4978 13.5 13.1694 13.5 13.9978V18.5H10.5V13.9978C10.5 13.1694 11.1716 12.4978 12 12.4978Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Glass24 as default };
//# sourceMappingURL=Glass24.js.map
