import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Freeze24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Freeze24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Freeze24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Freeze24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M12.9121 4.50098L14.4756 2.93945L15.5361 4L12.835 6.69922L12.6914 10.7998L16.2148 8.59863L17.166 5.04785L18.6152 5.43652L18.0811 7.43262L20.1602 6.13379L21.1602 7.86523L18.8135 9.1123L21.0898 9.72266L20.7021 11.1719L16.873 10.1445L13.3828 12L17.0068 13.9268L20.6963 12.9375L21.084 14.3867L18.9492 14.959L21.1602 16.1348L20.1602 17.8662L18.0371 16.54L18.6094 18.6738L17.1602 19.0615L16.1719 15.374L12.6914 13.1982L12.835 17.2998L15.5361 20L14.4756 21.0605L12.9121 19.498L13 22H11L11.0869 19.498L9.52539 21.0605L8.46484 20L11.1641 17.2998L11.3076 13.1963L7.82715 15.373L6.83984 19.0625L5.39062 18.6738L5.96289 16.5391L3.83984 17.8652L2.83984 16.1338L5.0498 14.958L2.91602 14.3867L3.30371 12.9385L6.99219 13.9258L10.6152 12L6.99121 10.0742L3.30371 11.0615L2.91602 9.61328L5.04883 9.04199L2.83984 7.86621L3.83984 6.13477L5.96191 7.46094L5.39062 5.32617L6.83984 4.9375L7.82715 8.62695L11.3076 10.8018L11.1641 6.69922L8.46484 4L9.52539 2.93945L11.0869 4.50098L11 2H13L12.9121 4.50098Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Freeze24 as default };
//# sourceMappingURL=Freeze24.js.map
