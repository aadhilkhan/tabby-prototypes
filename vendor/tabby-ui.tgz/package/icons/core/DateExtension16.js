import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function DateExtension16(props) {
  const { dir, className, style = {}, color = "", size = 16, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("DateExtension16");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-DateExtension16 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-DateExtension16",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M6.667 1.333H5.333v1.334h-.666A2.667 2.667 0 0 0 2 5.333v6A2.667 2.667 0 0 0 4.667 14h6.666A2.667 2.667 0 0 0 14 11.333v-6a2.667 2.667 0 0 0-2.667-2.666h-.666V1.333H9.333v1.334H6.667zm2.666 4V4H6.667v1.333H5.333V4h-.666c-.737 0-1.334.597-1.334 1.333v6c0 .737.597 1.334 1.334 1.334h6.666c.737 0 1.334-.597 1.334-1.334v-6c0-.736-.597-1.333-1.334-1.333h-.666v1.333zm-.666 1.334H7.333V8h1.334zm-4 0H6V8H4.667zm6.666 0H10V8h1.333zm-2.5 2.909a.5.5 0 0 1 .5-.5h1.334a.5.5 0 0 1 .5.5v1.333a.5.5 0 1 1-1 0v-.12c-.186.16-.39.301-.607.42a3.783 3.783 0 0 1-4.595-.771.5.5 0 1 1 .737-.675 2.783 2.783 0 0 0 3.38.568 2.44 2.44 0 0 0 .379-.255h-.128a.5.5 0 0 1-.5-.5",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { DateExtension16 as default };
//# sourceMappingURL=DateExtension16.js.map
