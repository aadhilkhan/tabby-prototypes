import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function CircleDashed24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("CircleDashed24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-CircleDashed24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-CircleDashed24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 22 22",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M13.498 20.6855C12.6996 20.8909 11.8625 21 11 21C10.1371 21 9.29971 20.891 8.50098 20.6855L9 18.748C9.63715 18.9119 10.3068 19 11 19C11.6932 19 12.3629 18.9119 13 18.748L13.498 20.6855ZM4.10742 15.0635C4.79591 16.2281 5.77186 17.2041 6.93652 17.8926L6.42676 18.7529L6.27051 19.0195L5.91895 19.6123C4.46419 18.7522 3.24666 17.535 2.38672 16.0801L4.10742 15.0635ZM19.165 15.8154L19.6123 16.0801C18.7522 17.535 17.535 18.7522 16.0801 19.6123L15.5723 18.7539L15.0635 17.8926C16.2281 17.2041 17.2041 16.2281 17.8926 15.0635L19.165 15.8154ZM1.31445 8.50195L3.25195 9C3.08808 9.63715 3 10.3068 3 11C3 11.6932 3.08808 12.3629 3.25195 13L1.31348 13.498C1.10818 12.6997 1 11.8625 1 11C1 10.1372 1.10803 9.29964 1.31348 8.50098L1.31445 8.50195ZM20.6855 8.50195C20.891 9.30068 21 10.1371 21 11C21 11.8625 20.8909 12.6996 20.6855 13.498L18.748 13C18.9119 12.3629 19 11.6932 19 11C19 10.3068 18.9119 9.63715 18.748 9L20.6855 8.50195ZM6.93652 4.10742C5.77186 4.79591 4.79591 5.77186 4.10742 6.93652L2.91699 6.2334L2.38672 5.91895C3.24672 4.46424 4.46424 3.24672 5.91895 2.38672L6.93652 4.10742ZM16.0801 2.38672C17.535 3.24666 18.7522 4.46419 19.6123 5.91895L19.083 6.2334L17.8926 6.93652C17.2041 5.77186 16.2281 4.79591 15.0635 4.10742L15.6797 3.06543L16.0801 2.38672ZM11 1C11.8625 1 12.6997 1.10818 13.498 1.31348L13 3.25195C12.3629 3.08808 11.6932 3 11 3C10.3068 3 9.63715 3.08808 9 3.25195L8.50195 1.31445L8.50098 1.31348C9.29964 1.10803 10.1372 1 11 1Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { CircleDashed24 as default };
//# sourceMappingURL=CircleDashed24.js.map
