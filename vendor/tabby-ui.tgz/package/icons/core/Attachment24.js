import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Attachment24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Attachment24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Attachment24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Attachment24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M17.9498 4.63613C16.7782 3.46455 14.8787 3.46455 13.7072 4.63613L6.6361 11.7072C4.68347 13.6598 4.68348 16.8256 6.6361 18.7783C8.58872 20.7309 11.7545 20.7309 13.7072 18.7783L16.5356 15.9498L17.9498 17.364L15.1214 20.1925C12.3877 22.9261 7.95555 22.9261 5.22188 20.1925C2.48821 17.4588 2.48821 13.0267 5.22188 10.293L12.293 3.22191C14.2456 1.26929 17.4114 1.26929 19.364 3.22191C21.3166 5.17453 21.3166 8.34036 19.364 10.293L12.293 17.364C11.1214 18.5356 9.22188 18.5356 8.05031 17.364C6.87874 16.1925 6.87874 14.293 8.05031 13.1214L13.7072 7.46455L15.1214 8.87877L9.46452 14.5356C9.074 14.9261 9.074 15.5593 9.46452 15.9498C9.85505 16.3404 10.4882 16.3404 10.8787 15.9498L17.9498 8.87877C19.1214 7.70719 19.1214 5.8077 17.9498 4.63613Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Attachment24 as default };
//# sourceMappingURL=Attachment24.js.map
