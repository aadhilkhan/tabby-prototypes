import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Arabic24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Arabic24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Arabic24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Arabic24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M18.5355 5.12132L16.4142 3L14.2929 5.12132L16.4142 7.24264L18.5355 5.12132ZM13.5675 14H18.347C18.7512 12.9195 18.7209 11.9444 18.4376 11.2552C18.1253 10.4955 17.4841 10 16.5 10C15.5974 10 14.8759 10.5403 14.3272 11.5426C13.9319 12.2648 13.6796 13.1476 13.5675 14ZM12.5728 10.5824C13.3241 9.20974 14.6026 8 16.5 8C18.3159 8 19.6747 9.00454 20.2874 10.4948C20.8815 11.9398 20.7457 13.7446 19.8944 15.4472L19.618 16H12.6194C12.4967 16.7147 12.2095 17.3875 11.7072 17.925C11.0406 18.6383 10.101 19 9.00001 19C7.95515 19 7.08084 18.7356 6.41057 18.1712C5.74984 17.6148 5.40411 16.8645 5.21738 16.1176C5.03215 15.3767 4.98467 14.5638 4.97663 13.7917C4.97238 13.3836 4.98056 12.909 4.98839 12.4552L4.98839 12.4551C4.9943 12.1125 5.00001 11.7816 5.00001 11.5H7.00001C7.00001 11.8849 6.99345 12.2275 6.98707 12.5605L6.98707 12.5605V12.5605C6.97944 12.9591 6.97207 13.3439 6.97652 13.7709C6.98411 14.4988 7.03039 15.1234 7.15766 15.6325C7.28344 16.1356 7.46896 16.4478 7.69885 16.6414C7.9192 16.8269 8.29489 17 9.00001 17C9.64897 17 10.0219 16.7992 10.2459 16.5595C10.4846 16.304 10.6638 15.8856 10.6883 15.2726C10.7381 14.0264 10.1235 12.2641 8.74075 10.6508L10.2593 9.34924C10.9802 10.1903 11.5557 11.1011 11.9655 12.0188C12.124 11.5205 12.3254 11.0344 12.5728 10.5824Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Arabic24 as default };
//# sourceMappingURL=Arabic24.js.map
