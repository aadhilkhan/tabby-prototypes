import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function FinancialServices24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("FinancialServices24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-FinancialServices24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-FinancialServices24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2ZM12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4ZM13 7.00488C13.8645 7.03231 14.5451 7.25248 15.041 7.66895C15.5718 8.11476 15.8369 8.74221 15.8369 9.55078V10.1729H13.5381V9.75293C13.5381 9.34858 13.4476 9.07386 13.2666 8.92871C13.0856 8.78361 12.754 8.71094 12.2715 8.71094H11.5654C11.0708 8.71096 10.7327 8.79409 10.5518 8.95996C10.3831 9.11558 10.2988 9.4264 10.2988 9.89258V10.1885C10.299 10.6756 10.794 10.9558 11.7832 11.0283C12.8086 11.1009 13.7194 11.2768 14.5156 11.5566C14.9379 11.7121 15.2879 11.9922 15.5654 12.3965C15.855 12.7905 16 13.2988 16 13.9209V14.4492C16 15.2577 15.7348 15.8852 15.2041 16.3311C14.674 16.7762 13.939 16.9983 13 16.999V19H11V16.999C10.0696 16.9955 9.34111 16.7733 8.81445 16.3311C8.28361 15.8852 8.01855 15.2579 8.01855 14.4492V14.1387C8.01855 13.9209 8.03516 13.8115 8.03516 13.8115H10.3164V14.2627C10.3164 14.6564 10.4071 14.9261 10.5879 15.0713C10.7689 15.2164 11.1013 15.2891 11.584 15.2891H12.4346C12.9051 15.289 13.2311 15.2112 13.4121 15.0557C13.6049 14.9001 13.7011 14.6101 13.7012 14.1855V13.998C13.701 13.6976 13.5561 13.4699 13.2666 13.3145C12.9891 13.1486 12.639 13.0497 12.2168 13.0186C11.7946 12.9874 11.3363 12.9306 10.8418 12.8477C10.3593 12.7544 9.90661 12.6406 9.48438 12.5059C9.06211 12.3607 8.70559 12.0859 8.41602 11.6816C8.13849 11.2669 8 10.7375 8 10.0947V9.55078C8 8.74227 8.26523 8.11475 8.7959 7.66895C9.32597 7.22383 10.061 7.00071 11 7V5H13V7.00488Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { FinancialServices24 as default };
//# sourceMappingURL=FinancialServices24.js.map
