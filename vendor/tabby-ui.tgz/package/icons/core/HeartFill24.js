import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function HeartFill24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("HeartFill24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-HeartFill24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-HeartFill24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M13.0176 5.54858C15.0724 3.484 18.3983 3.484 20.4531 5.54858C22.5155 7.62099 22.5156 10.987 20.4531 13.0593L12.9238 20.6238C12.6668 20.8821 12.3296 21.0059 12 20.9998C11.6704 21.0059 11.3333 20.8821 11.0762 20.6238L3.54688 13.0593C1.48436 10.987 1.48442 7.62098 3.54688 5.54858C5.60166 3.484 8.92764 3.484 10.9824 5.54858L12 6.57104L13.0176 5.54858Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { HeartFill24 as default };
//# sourceMappingURL=HeartFill24.js.map
