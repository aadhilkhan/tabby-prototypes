import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Coupon16(props) {
  const { dir, className, style = {}, color = "", size = 16, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Coupon16");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Coupon16 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Coupon16",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M12 3.5H8.828a.5.5 0 0 0-.353.146l-3.06 3.06 3.88 3.878 3.059-3.059a.5.5 0 0 0 .146-.353V4a.5.5 0 0 0-.5-.5M3.475 8.646l.88-.88 3.879 3.879-.88.88a.5.5 0 0 1-.708 0L3.475 9.354a.5.5 0 0 1 0-.708M12 2H8.828a2 2 0 0 0-1.414.586l-5 5a2 2 0 0 0 0 2.828l3.172 3.172a2 2 0 0 0 2.828 0l5-5A2 2 0 0 0 14 7.172V4a2 2 0 0 0-2-2m-1.5 4.5a1 1 0 1 0 0-2 1 1 0 0 0 0 2",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { Coupon16 as default };
//# sourceMappingURL=Coupon16.js.map
