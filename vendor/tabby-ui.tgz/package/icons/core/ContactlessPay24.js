import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function ContactlessPay24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("ContactlessPay24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-ContactlessPay24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-ContactlessPay24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M3.79952 15.278C4.24944 14.2776 4.49976 13.1681 4.49976 12C4.49976 10.832 4.24943 9.72242 3.7995 8.72203L5.54692 7.73436C6.15802 9.02819 6.49976 10.4742 6.49976 12C6.49976 13.5258 6.15803 14.9718 5.54694 16.2657L3.79952 15.278ZM7.70179 6.51638L9.47273 5.51542C10.45 7.46671 11 9.66914 11 12C11 14.3309 10.45 16.5333 9.47275 18.4846L7.65087 17.4548C8.47201 15.7898 8.93333 13.9155 8.93333 11.9334C8.93333 9.99264 8.49106 8.15522 7.70179 6.51638ZM11.6518 4.28374L13.3948 3.29858C14.7403 5.90561 15.5 8.8641 15.5 12C15.5 15.136 14.7403 18.0944 13.3949 20.7015L11.6519 19.7163C12.8335 17.4006 13.4999 14.7782 13.4999 12.0001C13.4999 9.22193 12.8335 6.59945 11.6518 4.28374ZM15.5731 2.06737L17.3154 1.0826C19.0299 4.34468 20 8.05913 20 12.0002C20 15.9411 19.0299 19.6555 17.3155 22.9175L15.5731 21.9326C17.1234 18.9616 18 15.5831 18 11.9999C18 8.41677 17.1235 5.03834 15.5731 2.06737Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { ContactlessPay24 as default };
//# sourceMappingURL=ContactlessPay24.js.map
