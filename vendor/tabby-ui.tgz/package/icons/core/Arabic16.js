import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Arabic16(props) {
  const { dir, className, style = {}, color = "", size = 16, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Arabic16");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Arabic16 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Arabic16",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M12.357 2.914 10.943 1.5 9.529 2.914l1.414 1.414zm-3.07 6.211h2.797c.202-.623.17-1.167.015-1.542-.177-.43-.53-.708-1.1-.708-.497 0-.92.29-1.265.92-.214.39-.363.86-.446 1.33M8.2 6.955C8.721 6 9.631 5.125 11 5.125c1.298 0 2.279.723 2.718 1.792.424 1.03.32 2.297-.268 3.474l-.242.484H8.584a2.61 2.61 0 0 1-.627 1.217c-.49.525-1.176.783-1.957.783-.732 0-1.367-.186-1.86-.601-.486-.41-.733-.955-.864-1.478-.13-.518-.161-1.08-.167-1.6-.002-.27.003-.597.008-.905.004-.229.008-.447.008-.624h1.75c0 .267-.004.496-.009.716-.005.26-.01.509-.007.796.005.48.036.877.115 1.192.077.31.184.473.293.564.1.084.298.19.733.19.386 0 .575-.117.678-.227.116-.125.224-.35.24-.724.03-.765-.352-1.89-1.249-2.938l1.329-1.139c.375.439.695.906.95 1.385.075-.181.158-.357.251-.527",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { Arabic16 as default };
//# sourceMappingURL=Arabic16.js.map
