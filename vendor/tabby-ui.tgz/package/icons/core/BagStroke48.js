import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function BagStroke48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("BagStroke48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-BagStroke48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-BagStroke48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M24 7C21.7909 7 20 8.79086 20 11H17C17 7.13401 20.134 4 24 4C27.866 4 31 7.13401 31 11H28C28 8.79086 26.2091 7 24 7ZM10.7934 16L9.97189 27.5018C9.79805 29.9357 9.68338 31.5757 9.69917 32.8412C9.71455 34.074 9.85744 34.6617 10.0292 35.0448C10.4809 36.0529 11.2538 36.883 12.2272 37.4055C12.5971 37.604 13.1731 37.7884 14.4017 37.8916C15.6629 37.9975 17.3069 38 19.747 38H28.2532C30.6933 38 32.3373 37.9975 33.5985 37.8916C34.8271 37.7884 35.403 37.604 35.773 37.4055C36.7463 36.883 37.5192 36.0529 37.971 35.0448C38.1427 34.6617 38.2856 34.074 38.301 32.8412C38.3168 31.5757 38.2021 29.9356 38.0283 27.5018L37.2067 16H10.7934ZM40.0001 13H8.00009L6.97952 27.288C6.63912 32.0535 6.46893 34.4363 7.29151 36.2718C8.01436 37.8847 9.25101 39.2128 10.8083 40.0487C12.5805 41 14.9694 41 19.747 41H28.2532C33.0308 41 35.4196 41 37.1918 40.0487C38.7492 39.2128 39.9858 37.8847 40.7087 36.2718C41.5313 34.4363 41.3611 32.0535 41.0207 27.288L40.0001 13ZM29 18H32C32 22.4183 28.4183 26 24 26C19.5817 26 16 22.4183 16 18H19C19 20.7614 21.2386 23 24 23C26.7614 23 29 20.7614 29 18Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { BagStroke48 as default };
//# sourceMappingURL=BagStroke48.js.map
