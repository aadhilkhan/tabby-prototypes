import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Bell48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Bell48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Bell48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Bell48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M24 6C25.6569 6 27 7.34315 27 9C27 9.40519 26.9181 9.79095 26.7725 10.1436C32.0047 10.9913 36 15.5284 36 21V33H39V36H27V37C27 38.6569 25.6569 40 24 40C22.3431 40 21 38.6569 21 37V36H9V33H12V21C12 15.5287 15.9948 10.9916 21.2266 10.1436C21.0811 9.79104 21 9.40506 21 9C21 7.34315 22.3431 6 24 6ZM23 13C18.5817 13 15 16.5817 15 21V33H33V21C33 16.5817 29.4183 13 25 13H23Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Bell48 as default };
//# sourceMappingURL=Bell48.js.map
