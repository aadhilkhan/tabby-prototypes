import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Icons24X24NavigationDoubleChevronDown24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes(
    "Icons24X24NavigationDoubleChevronDown24"
  );
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Icons24X24NavigationDoubleChevronDown24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Icons24X24NavigationDoubleChevronDown24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M7.29297 11.4644L11.5352 15.7075L15.7783 11.4644L17.1924 12.8784L11.5361 18.5356L10.1211 17.1216L5.87891 12.8784L7.29297 11.4644ZM7.29297 5.46436L11.5352 9.70752L15.7783 5.46436L17.1924 6.87842L11.5361 12.5356L10.1211 11.1216L5.87891 6.87842L7.29297 5.46436Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Icons24X24NavigationDoubleChevronDown24 as default };
//# sourceMappingURL=Icons24X24NavigationDoubleChevronDown24.js.map
