import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function ArrowOut24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("ArrowOut24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-ArrowOut24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-ArrowOut24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M3 22h6v-2H5V4h4V2H3zm19.485-10zl-1.414-1.415-4.246-4.245-1.414 1.414L18.656 11H9v2h9.657l-3.24 3.239 1.415 1.414 4.239-4.239z",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { ArrowOut24 as default };
//# sourceMappingURL=ArrowOut24.js.map
