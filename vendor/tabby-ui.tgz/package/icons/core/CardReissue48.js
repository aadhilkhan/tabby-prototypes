import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function CardReissue48(props) {
  const { dir, className, style = {}, color = "", size = 48, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("CardReissue48");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-CardReissue48 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-CardReissue48",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fillRule: "evenodd",
          clipRule: "evenodd",
          d: "M8 11H36C37.6569 11 39 12.3431 39 14V15H5V14C5 12.3431 6.34315 11 8 11ZM5 21V32C5 33.6569 6.34315 35 8 35H21V38H8C4.68629 38 2 35.3137 2 32V14C2 10.6863 4.68629 8 8 8H36C39.3137 8 42 10.6863 42 14V18V22.4644C40.205 21.5289 38.1643 21 36 21H5ZM21 26V28H9V25H21V26ZM36 27C38.7924 27 41.2029 28.6351 42.3264 31H45.5422C44.2679 26.9429 40.4776 24 36 24C32.0418 24 28.6207 26.2997 27 29.6359V27.5C27 26.6716 26.3284 26 25.5 26C24.6716 26 24 26.6716 24 27.5V32V35H27H31.5C32.3284 35 33 34.3284 33 33.5C33 32.6716 32.3284 32 31.5 32H29.2899C30.1504 29.1085 32.829 27 36 27ZM36 42C33.2076 42 30.7971 40.3649 29.6736 38H26.4578C27.7321 42.0571 31.5224 45 36 45C39.9582 45 43.3793 42.7003 45 39.3641V41.5C45 42.3284 45.6716 43 46.5 43C47.3284 43 48 42.3284 48 41.5V37V34H45H40.5C39.6716 34 39 34.6716 39 35.5C39 36.3284 39.6716 37 40.5 37H42.7101C41.8496 39.8915 39.171 42 36 42Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { CardReissue48 as default };
//# sourceMappingURL=CardReissue48.js.map
