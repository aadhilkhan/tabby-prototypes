import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Cashback16(props) {
  const { dir, className, style = {}, color = "", size = 16, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Cashback16");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Cashback16 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Cashback16",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        fill: "none"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          fill: "currentColor",
          fillRule: "evenodd",
          d: "M15 8A7 7 0 1 1 1 8v-.004h1.75V8a5.25 5.25 0 1 0 1.157-3.287.667.667 0 0 1-.24 1.289H1V3.335a.667.667 0 1 1 1.334 0v.554A7 7 0 0 1 15 8M9.945 4.995l-4.95 4.95 1.06 1.06 4.95-4.95zM9.75 11a1 1 0 1 0 0-2 1 1 0 0 0 0 2m-2.5-5a1 1 0 1 1-2 0 1 1 0 0 1 2 0",
          clipRule: "evenodd"
        }
      )
    )
  );
}

export { Cashback16 as default };
//# sourceMappingURL=Cashback16.js.map
