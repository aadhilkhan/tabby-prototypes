import cn from 'classnames';
import React__default from 'react';
import { flipOnRtlIcons } from '../../core/Icon/styles/index.js';

function Folder24(props) {
  const { dir, className, style = {}, color = "", size = 24, ...rest } = props;
  const colorStyle = color ? { color } : {};
  const isFlipOnRtl = flipOnRtlIcons.includes("Folder24");
  const getStyleTransform = () => {
    if (!dir) return void 0;
    if (dir === "rtl" && isFlipOnRtl) return "scaleX(-1)";
    return "none";
  };
  const flippedStyle = isFlipOnRtl ? `
  [dir="rtl"] .tui-icon-Folder24 {
    transform: scaleX(-1);
  }` : null;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ...rest,
      style: {
        lineHeight: 0,
        ...style,
        ...colorStyle,
        transform: getStyleTransform()
      },
      className: cn(
        "Tui-Component",
        "Tui-Icon",
        "TuiIcon-root",
        "tui-icon-Folder24",
        className
      )
    },
    flippedStyle && /* @__PURE__ */ React__default.createElement("style", null, flippedStyle),
    /* @__PURE__ */ React__default.createElement(
      "svg",
      {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg"
      },
      /* @__PURE__ */ React__default.createElement(
        "path",
        {
          d: "M7.19629 2C8.47197 2 9.60262 2.80599 10.0244 4H17C19.7614 4 22 6.23858 22 9V18C22 19.6569 20.6569 21 19 21H5C3.34315 21 2 19.6569 2 18V5C2 3.34315 3.34315 2 5 2H7.19629ZM5 4C4.44772 4 4 4.44772 4 5V18C4 18.5523 4.44772 19 5 19H19C19.5523 19 20 18.5523 20 18V12C20 11.4477 19.5523 11 19 11H13.7754C11.5769 10.9998 9.63658 9.56347 8.99414 7.46094L8.15234 4.70801C8.02385 4.28747 7.63601 4 7.19629 4H5ZM10.9072 6.87695C11.2928 8.1382 12.4565 8.99982 13.7754 9H19C19.3506 9 19.6872 9.06035 20 9.1709V9C20 7.34315 18.6569 6 17 6H10.6387L10.9072 6.87695Z",
          fill: "currentColor"
        }
      )
    )
  );
}

export { Folder24 as default };
//# sourceMappingURL=Folder24.js.map
