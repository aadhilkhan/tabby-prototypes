const SingleFileUploaderClasses = {
  root: "tui-single-file-uploader",
  component: "tui-o25-component",
  state: {
    uploader: "tui-single-file-uploader_state-uploader",
    loading: "tui-single-file-uploader_state-loading",
    uploaded: "tui-single-file-uploader_state-uploaded"
  },
  size: {
    desktop: "tui-single-file-uploader_size-desktop",
    mobile: "tui-single-file-uploader_size-mobile"
  },
  error: "tui-single-file-uploader_error",
  disabled: "tui-single-file-uploader_disabled",
  loadingRoot: "tui-single-file-uploader_loading",
  uploader: "tui-single-file-uploader__uploader",
  uploaderError: "tui-single-file-uploader__uploader_error",
  uploaderDragging: "tui-single-file-uploader__uploader_dragging",
  dropzoneWrapper: "tui-single-file-uploader__dropzone-wrapper",
  dropzone: "tui-single-file-uploader__dropzone",
  dropzoneContent: "tui-single-file-uploader__dropzone-content",
  dropzoneContentDragging: "tui-single-file-uploader__dropzone-content_dragging",
  iconWrapper: "tui-single-file-uploader__icon-wrapper",
  textContent: "tui-single-file-uploader__text-content",
  mainText: "tui-single-file-uploader__main-text",
  subtitleText: "tui-single-file-uploader__subtitle-text",
  dragText: "tui-single-file-uploader__drag-text",
  errorMessage: "tui-single-file-uploader__error-message",
  loading: "tui-single-file-uploader__loading",
  loadingIndicator: "tui-single-file-uploader__loading-indicator",
  uploadingText: "tui-single-file-uploader__uploading-text",
  loadingSpinner: "tui-single-file-uploader__loading-spinner",
  uploaded: "tui-single-file-uploader__uploaded",
  filePreview: "tui-single-file-uploader__file-preview",
  filePreviewImage: "tui-single-file-uploader__file-preview_image",
  previewImage: "tui-single-file-uploader__preview-image",
  fileIcon: "tui-single-file-uploader__file-icon",
  fileInfoWrapper: "tui-single-file-uploader__file-info-wrapper",
  fileInfo: "tui-single-file-uploader__file-info",
  fileName: "tui-single-file-uploader__file-name",
  fileSize: "tui-single-file-uploader__file-size",
  actions: "tui-single-file-uploader__actions",
  actionButton: "tui-single-file-uploader__action-button"
};

export { SingleFileUploaderClasses };
//# sourceMappingURL=classes.js.map
