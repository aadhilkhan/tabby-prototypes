const NavBarClasses = {
  component: "tui-o25-component",
  root: "tui-nav-bar",
  type: {
    transparent: "tui-nav-bar_type-transparent",
    filled: "tui-nav-bar_type-filled",
    floating: "tui-nav-bar_type-floating"
  },
  triggered: "tui-nav-bar_triggered",
  lead: "tui-nav-bar__lead",
  trail: "tui-nav-bar__trail",
  content: "tui-nav-bar__content",
  contentLeftPadding: "tui-nav-bar__content_left-padding",
  contentRightPadding: "tui-nav-bar__content_right-padding",
  contentFullWidth: "tui-nav-bar__content-full-width",
  heading: "tui-nav-bar__heading",
  subheading: "tui-nav-bar__subheading",
  trigger: "tui-nav-bar-trigger"
};

export { NavBarClasses };
//# sourceMappingURL=classes.js.map
