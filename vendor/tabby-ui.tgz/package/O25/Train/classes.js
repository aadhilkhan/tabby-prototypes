const TrainClasses = {
  root: "tui-train",
  component: "tui-o25-component",
  type: {
    body1: "tui-train_type-body1",
    body2: "tui-train_type-body2",
    caption: "tui-train_type-caption",
    capsL: "tui-train_type-caps-l",
    capsM: "tui-train_type-caps-m",
    capsS: "tui-train_type-caps-s",
    microtext: "tui-train_type-microtext"
  },
  item: "tui-train__item",
  itemLabel: "tui-train__item-label",
  icon: "tui-train__icon",
  iconLead: "tui-train__icon_lead",
  iconTrail: "tui-train__icon_trail",
  separator: "tui-train__separator"
};

export { TrainClasses };
//# sourceMappingURL=classes.js.map
