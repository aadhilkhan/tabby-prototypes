const LineClasses = {
  root: "tui-line",
  component: "tui-o25-component",
  gap: {
    l: "tui-line_gap-l",
    m: "tui-line_gap-m",
    s: "tui-line_gap-s"
  },
  iconSize: {
    xl: "tui-line_icon-size-xl",
    l: "tui-line_icon-size-l",
    m: "tui-line_icon-size-m",
    sm: "tui-line_icon-size-sm",
    s: "tui-line_icon-size-s",
    xs: "tui-line_icon-size-xs",
    xxs: "tui-line_icon-size-xxs"
  },
  icon: "tui-line__icon",
  chevron: "tui-line__chevron"
};

export { LineClasses };
//# sourceMappingURL=classes.js.map
