import { Slot } from '@radix-ui/react-slot';
import cn from 'classnames';
import React__default from 'react';
import { useAsChild } from '../hooks/useAsChild.js';
import { putDevError } from '../utils/putDevError.js';
import img from '../assets/loader-invert.png.js';
import img$1 from '../assets/loader.png.js';
import { Text } from '../Text/Text.js';
import "./Button.css";
import { ButtonClasses } from './classes.js';

const getLabelTextVariant = (size, variant) => {
  if (variant === "primary") {
    switch (size) {
      case "xl":
      case "l":
        return "body1TightBold";
      case "m":
      case "s":
        return "body2TightBold";
      case "xs":
      default:
        return "captionBold";
    }
  }
  switch (size) {
    case "xl":
    case "l":
      return "body1Tight";
    case "m":
    case "s":
      return "body2Tight";
    case "xs":
    default:
      return "caption";
  }
};
const shouldShowSubLabel = (size) => {
  switch (size) {
    case "xl":
    case "l":
      return true;
    default:
      return false;
  }
};
const Button = React__default.forwardRef(
  (props, ref) => {
    const {
      size = "m",
      variant = "primary",
      tone = "neutral",
      level = 2,
      className,
      label,
      subLabel,
      lead,
      trail,
      isLoading,
      isSelected,
      asChild = false,
      children,
      onClick,
      disabled,
      ...rest
    } = props;
    const Component = asChild ? Slot : "button";
    const handleClick = (event) => {
      if (isLoading || disabled) {
        event.preventDefault();
        event.stopPropagation();
        return;
      }
      onClick?.(event);
    };
    const renderLoader = () => {
      const getSrc = () => {
        if (variant === "primary") {
          return tone === "inverted" ? img : img$1;
        }
        return tone === "inverted" ? img$1 : img;
      };
      return /* @__PURE__ */ React__default.createElement(
        "div",
        {
          className: cn(
            ButtonClasses.loadingWrap,
            ButtonClasses.loadingWrapSize[size]
          )
        },
        /* @__PURE__ */ React__default.createElement(
          "img",
          {
            className: cn(
              ButtonClasses.loadingIcon,
              ButtonClasses.loadingIconSize[size]
            ),
            src: getSrc(),
            alt: "loading"
          }
        )
      );
    };
    const renderContainer = (content) => {
      const labelVariant = getLabelTextVariant(size, variant);
      const labelContent = content || label;
      const isShouldShowSublabel = shouldShowSubLabel(size);
      if (subLabel && !isShouldShowSublabel) {
        putDevError("subLabel prop is not supported for this size of button");
      }
      return /* @__PURE__ */ React__default.createElement("div", { className: ButtonClasses.wrapper }, /* @__PURE__ */ React__default.createElement("div", { className: ButtonClasses.container }, lead && /* @__PURE__ */ React__default.createElement("div", { className: cn(ButtonClasses.icon, ButtonClasses.iconStart) }, lead), /* @__PURE__ */ React__default.createElement("div", { className: ButtonClasses.content }, /* @__PURE__ */ React__default.createElement(Text, { className: ButtonClasses.label, variant: labelVariant }, labelContent), subLabel && isShouldShowSublabel ? /* @__PURE__ */ React__default.createElement(Text, { className: ButtonClasses.sublabel, variant: "body2Tight" }, subLabel) : null), trail && /* @__PURE__ */ React__default.createElement("div", { className: cn(ButtonClasses.icon, ButtonClasses.iconEnd) }, trail), isLoading && renderLoader()));
    };
    const buttonContent = useAsChild({
      render: (content) => renderContainer(content),
      children,
      asChild
    });
    const disabledProps = asChild ? { "aria-disabled": disabled } : { disabled };
    return /* @__PURE__ */ React__default.createElement(
      Component,
      {
        ...rest,
        ...disabledProps,
        ref,
        onClick: handleClick,
        className: cn(
          ButtonClasses.component,
          ButtonClasses.root,
          ButtonClasses.size[size],
          ButtonClasses.variant[variant],
          ButtonClasses.tone[tone],
          level && ButtonClasses.level[level],
          isLoading && ButtonClasses.loading,
          disabled && ButtonClasses.disabled,
          isSelected && ButtonClasses.selected,
          lead && ButtonClasses.lead,
          trail && ButtonClasses.trail,
          className
        )
      },
      buttonContent
    );
  }
);
Button.displayName = "Button";

export { Button };
//# sourceMappingURL=Button.js.map
