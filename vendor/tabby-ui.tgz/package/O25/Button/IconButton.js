import { Slot } from '@radix-ui/react-slot';
import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { putDevError } from '../utils/putDevError.js';
import "./Button.css";
import { ButtonClasses } from './classes.js';

const IconButton = forwardRef(
  (props, externalRef) => {
    const {
      size = "m",
      variant = "primary",
      tone = "neutral",
      level = 2,
      className,
      children,
      asChild,
      isSelected,
      ...rest
    } = props;
    const Component = asChild ? Slot : "button";
    if (tone === "muted" && variant !== "ghost") {
      putDevError("muted tone is only supported for ghost variant");
    }
    if (!rest["aria-label"] && !rest["aria-labelledby"]) {
      putDevError(
        "IconButton requires aria-label or aria-labelledby for accessibility"
      );
    }
    return /* @__PURE__ */ React__default.createElement(
      Component,
      {
        ref: externalRef,
        className: cn(
          ButtonClasses.component,
          ButtonClasses.root,
          ButtonClasses.iconModifier,
          ButtonClasses.variant[variant],
          ButtonClasses.tone[tone],
          ButtonClasses.size[size],
          ButtonClasses.level[level],
          isSelected && ButtonClasses.selected,
          className
        ),
        ...rest
      },
      /* @__PURE__ */ React__default.createElement("div", { className: ButtonClasses.icon }, children)
    );
  }
);
IconButton.displayName = "IconButton";

export { IconButton };
//# sourceMappingURL=IconButton.js.map
