const ButtonClasses = {
  root: "tui-button",
  component: "tui-o25-component",
  size: {
    xl: "tui-button_size-xl",
    l: "tui-button_size-l",
    m: "tui-button_size-m",
    s: "tui-button_size-s",
    xs: "tui-button_size-xs",
    xxs: "tui-button_size-xxs"
  },
  variant: {
    primary: "tui-button_variant-primary",
    secondary: "tui-button_variant-secondary",
    tertiary: "tui-button_variant-tertiary",
    ghost: "tui-button_variant-ghost"
  },
  tone: {
    neutral: "tui-button_tone-neutral",
    negative: "tui-button_tone-negative",
    warning: "tui-button_tone-warning",
    positive: "tui-button_tone-positive",
    accent: "tui-button_tone-accent",
    inverted: "tui-button_tone-inverted",
    muted: "tui-button_tone-muted"
  },
  level: {
    1: "tui-button_level-1",
    2: "tui-button_level-2",
    3: "tui-button_level-3"
  },
  loading: "tui-button_loading",
  disabled: "tui-button_disabled",
  lead: "tui-button_lead",
  trail: "tui-button_trail",
  selected: "tui-button_selected",
  iconModifier: "tui-button_icon",
  floating: "tui-button_floating",
  wrapper: "tui-button__wrapper",
  container: "tui-button__container",
  content: "tui-button__content",
  label: "tui-button__label",
  sublabel: "tui-button__sublabel",
  icon: "tui-button__icon",
  iconStart: "tui-button__icon_start",
  iconEnd: "tui-button__icon_end",
  loadingWrap: "tui-button__loading-wrap",
  loadingWrapSize: {
    xl: "tui-button__loading-wrap_size-xl",
    l: "tui-button__loading-wrap_size-l",
    m: "tui-button__loading-wrap_size-m",
    s: "tui-button__loading-wrap_size-s",
    xs: "tui-button__loading-wrap_size-xs"
  },
  loadingIcon: "tui-button__loading-icon",
  loadingIconSize: {
    xl: "tui-button__loading-icon_size-xl",
    l: "tui-button__loading-icon_size-l",
    m: "tui-button__loading-icon_size-m",
    s: "tui-button__loading-icon_size-s",
    xs: "tui-button__loading-icon_size-xs"
  }
};

export { ButtonClasses };
//# sourceMappingURL=classes.js.map
