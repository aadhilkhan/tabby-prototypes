import { Slot } from '@radix-ui/react-slot';
import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { putDevError } from '../utils/putDevError.js';
import "./Button.css";
import { ButtonClasses } from './classes.js';

const FloatingButton = forwardRef((props, externalRef) => {
  const {
    size = "m",
    variant = "primary",
    tone = "neutral",
    className,
    children,
    asChild,
    isSelected,
    ...rest
  } = props;
  const Component = asChild ? Slot : "button";
  if (!rest["aria-label"] && !rest["aria-labelledby"]) {
    putDevError(
      "FloatingButton requires aria-label or aria-labelledby for accessibility"
    );
  }
  return /* @__PURE__ */ React__default.createElement(
    Component,
    {
      ref: externalRef,
      className: cn(
        ButtonClasses.component,
        ButtonClasses.root,
        ButtonClasses.floating,
        ButtonClasses.variant[variant],
        ButtonClasses.tone[tone],
        ButtonClasses.size[size],
        isSelected && ButtonClasses.selected,
        className
      ),
      ...rest
    },
    /* @__PURE__ */ React__default.createElement("div", { className: ButtonClasses.icon }, children)
  );
});
FloatingButton.displayName = "FloatingButton";

export { FloatingButton };
//# sourceMappingURL=FloatingButton.js.map
