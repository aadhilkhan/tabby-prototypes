const TableClasses = {
  root: "tui-table",
  component: "tui-o25-component",
  wrapper: "tui-table__wrapper",
  scroll: "tui-table__scroll",
  scrollScrolled: "tui-table__scroll_scrolled",
  table: "tui-table__table",
  cell: "tui-table__cell",
  cellContent: "tui-table__cell-content",
  cellContentInner: "tui-table__cell-content-inner",
  cellLead: "tui-table__cell-lead",
  cellTrail: "tui-table__cell-trail",
  cellLabel: "tui-table__cell-label",
  cellSubLabel: "tui-table__cell-sublabel",
  cellAlignRight: "tui-table__cell_align-right",
  headerCellAlignRight: "tui-table__header-cell_align-right",
  rowSelected: "tui-table__row_selected",
  rowClickable: "tui-table__row_clickable"
};

export { TableClasses };
//# sourceMappingURL=classes.js.map
