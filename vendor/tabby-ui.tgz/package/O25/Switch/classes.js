const SwitchClasses = {
  component: "tui-o25-component",
  root: "tui-switch__root",
  rootRtl: "tui-switch__root-rtl",
  control: "tui-switch__control",
  thumb: "tui-switch__thumb",
  level: {
    1: "tui-switch_level-1",
    2: "tui-switch_level-2",
    3: "tui-switch_level-3"
  }
};

export { SwitchClasses };
//# sourceMappingURL=classes.js.map
