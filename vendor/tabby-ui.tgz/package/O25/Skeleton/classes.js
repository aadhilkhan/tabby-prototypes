const SkeletonClasses = {
  root: "tui-skeleton",
  component: "tui-o25-component",
  inverted: "tui-skeleton_inverted",
  level: {
    1: "tui-skeleton_level-1",
    2: "tui-skeleton_level-2",
    3: "tui-skeleton_level-3"
  }
};

export { SkeletonClasses };
//# sourceMappingURL=classes.js.map
