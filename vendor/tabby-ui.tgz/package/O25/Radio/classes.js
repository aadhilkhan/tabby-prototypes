const RadioClasses = {
  root: "tui-radio",
  component: "tui-o25-component",
  size: {
    xs: "tui-radio_size-xs",
    s: "tui-radio_size-s"
  },
  level: {
    1: "tui-radio_level-1",
    2: "tui-radio_level-2",
    3: "tui-radio_level-3"
  },
  disabled: "tui-radio_disabled",
  checked: "tui-radio_checked",
  error: "tui-radio_error",
  input: "tui-radio__input",
  icon: "tui-radio__icon",
  dot: "tui-radio__dot"
};

export { RadioClasses };
//# sourceMappingURL=classes.js.map
