const DrawerClasses = {
  component: "tui-o25-component",
  root: "tui-drawer-root",
  backdrop: "tui-drawer-backdrop",
  panel: "tui-drawer-panel",
  panelMajorBackground: "tui-drawer-panel--major-background",
  panelMinorBackground: "tui-drawer-panel--minor-background",
  content: "tui-drawer-content",
  footer: "tui-drawer-footer"
};

export { DrawerClasses };
//# sourceMappingURL=classes.js.map
