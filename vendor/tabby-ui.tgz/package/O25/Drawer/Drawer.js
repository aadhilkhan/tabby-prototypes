import { LazyMotion, domMax, AnimatePresence, m } from 'motion/react';
import cn from 'classnames';
import React__default, { useContext, useEffect } from 'react';
import { createPortal } from 'react-dom';
import Close24 from '../../icons/core/Close24.js';
import '../Button/Button.js';
import { IconButton } from '../Button/IconButton.js';
import '../Button/FloatingButton.js';
import { NavBar } from '../NavBar/NavBar.js';
import { DirWrapperContext } from '../StyleWrapper/DirWrapper.js';
import { usePortalContainer } from '../utils/PortalContainerContext.js';
import { DrawerClasses } from './classes.js';
import "./Drawer.css";

const PANEL_TRANSITION_ENTER = {
  type: "tween",
  duration: 0.3,
  ease: [0, 0, 0.17, 1.05]
};
const PANEL_TRANSITION_EXIT = {
  type: "tween",
  duration: 0.3,
  ease: "easeIn"
};
const BACKDROP_TRANSITION = { duration: 0.25 };
const PANEL_SHIFT = 436 + 12;
function Drawer(props) {
  const {
    isOpen,
    onClose,
    headerNavBarProps,
    content,
    footer,
    backdrop = false,
    shiftSelectors,
    shiftRefs,
    className,
    variant = "majorBackground",
    ...rest
  } = props;
  const portalContainer = usePortalContainer();
  const mountPoint = portalContainer?.current ?? (typeof document !== "undefined" ? document.body : null);
  const { dir = "ltr" } = useContext(DirWrapperContext) ?? {};
  const initialX = dir === "rtl" ? "-100%" : "100%";
  useEffect(() => {
    const prev = document.body.style.overflow;
    if (isOpen) {
      document.body.style.overflow = "hidden";
    }
    return () => {
      document.body.style.overflow = prev;
    };
  }, [isOpen]);
  useEffect(() => {
    let timeout;
    if (shiftSelectors?.length) {
      const elements = shiftSelectors.flatMap(
        (sel) => Array.from(document.querySelectorAll(sel))
      );
      if (elements.length) {
        const shift = dir === "rtl" ? PANEL_SHIFT : -PANEL_SHIFT;
        const transition = isOpen ? `transform ${PANEL_TRANSITION_ENTER.duration}s cubic-bezier(0, 0, 0.17, 1.05)` : `transform ${PANEL_TRANSITION_EXIT.duration}s ease-in`;
        elements.forEach((el) => {
          el.style.transition = transition;
          el.style.transform = isOpen ? `translateX(${shift}px)` : "translateX(0)";
        });
        if (!isOpen) {
          timeout = setTimeout(() => {
            elements.forEach((el) => {
              el.style.transition = "";
              el.style.transform = "";
            });
          }, PANEL_TRANSITION_EXIT.duration * 1e3);
        }
      }
    }
    return () => clearTimeout(timeout);
  }, [isOpen, dir, shiftSelectors]);
  useEffect(() => {
    let timeout;
    if (shiftRefs?.length) {
      const elements = shiftRefs.map((ref) => ref.current).filter((el) => el !== null);
      if (elements.length) {
        const shift = dir === "rtl" ? PANEL_SHIFT : -PANEL_SHIFT;
        const transition = isOpen ? `transform ${PANEL_TRANSITION_ENTER.duration}s cubic-bezier(0, 0, 0.17, 1.05)` : `transform ${PANEL_TRANSITION_EXIT.duration}s ease-in`;
        elements.forEach((el) => {
          el.style.transition = transition;
          el.style.transform = isOpen ? `translateX(${shift}px)` : "translateX(0)";
        });
        if (!isOpen) {
          timeout = setTimeout(() => {
            elements.forEach((el) => {
              el.style.transition = "";
              el.style.transform = "";
            });
          }, PANEL_TRANSITION_EXIT.duration * 1e3);
        }
      }
    }
    return () => clearTimeout(timeout);
  }, [isOpen, dir, shiftRefs]);
  const trail = headerNavBarProps && "trail" in headerNavBarProps ? headerNavBarProps.trail : /* @__PURE__ */ React__default.createElement(
    IconButton,
    {
      variant: "ghost",
      tone: "neutral",
      size: "m",
      "aria-label": "Close",
      onClick: onClose
    },
    /* @__PURE__ */ React__default.createElement(Close24, null)
  );
  const drawer = /* @__PURE__ */ React__default.createElement(LazyMotion, { features: domMax }, /* @__PURE__ */ React__default.createElement(AnimatePresence, null, isOpen && /* @__PURE__ */ React__default.createElement(
    "div",
    {
      className: cn(
        DrawerClasses.component,
        DrawerClasses.root,
        className
      ),
      dir
    },
    backdrop && /* @__PURE__ */ React__default.createElement(
      m.div,
      {
        className: DrawerClasses.backdrop,
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        exit: { opacity: 0 },
        transition: BACKDROP_TRANSITION,
        onClick: onClose
      }
    ),
    /* @__PURE__ */ React__default.createElement(
      m.div,
      {
        className: cn(
          DrawerClasses.component,
          DrawerClasses.panel,
          variant === "minorBackground" ? DrawerClasses.panelMinorBackground : DrawerClasses.panelMajorBackground
        ),
        initial: { x: initialX },
        animate: { x: 0 },
        exit: { x: initialX, transition: PANEL_TRANSITION_EXIT },
        transition: PANEL_TRANSITION_ENTER,
        ...rest
      },
      /* @__PURE__ */ React__default.createElement(NavBar, { ...headerNavBarProps, trail }),
      content && /* @__PURE__ */ React__default.createElement("div", { className: DrawerClasses.content }, content),
      footer && /* @__PURE__ */ React__default.createElement("div", { className: DrawerClasses.footer }, footer)
    )
  )));
  if (!mountPoint) return null;
  return createPortal(drawer, mountPoint);
}
Drawer.displayName = "Drawer";

export { Drawer };
//# sourceMappingURL=Drawer.js.map
