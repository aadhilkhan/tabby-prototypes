const DEFAULT_HEIGHT = "calc(100% - env(safe-area-inset-top) - 34px)";
const IS_SSR = typeof window === "undefined";
const DEFAULT_TWEEN_CONFIG = {
  ease: "easeOut",
  duration: 0.2
};
const REDUCED_MOTION_TWEEN_CONFIG = {
  ease: "linear",
  duration: 0.01
};
const DEFAULT_DRAG_CLOSE_THRESHOLD = 0.6;
const DEFAULT_DRAG_VELOCITY_THRESHOLD = 500;

export { DEFAULT_DRAG_CLOSE_THRESHOLD, DEFAULT_DRAG_VELOCITY_THRESHOLD, DEFAULT_HEIGHT, DEFAULT_TWEEN_CONFIG, IS_SSR, REDUCED_MOTION_TWEEN_CONFIG };
//# sourceMappingURL=constants.js.map
