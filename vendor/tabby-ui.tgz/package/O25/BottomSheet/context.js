import { createContext, useContext } from 'react';

const SheetContext = createContext(
  void 0
);
function useSheetContext() {
  const context = useContext(SheetContext);
  if (!context) throw new Error("Sheet context error");
  return context;
}

export { SheetContext, useSheetContext };
//# sourceMappingURL=context.js.map
