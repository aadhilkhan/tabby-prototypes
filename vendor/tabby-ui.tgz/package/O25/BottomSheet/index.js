import { SheetBackdrop } from './SheetBackdrop.js';
import { SheetContainer } from './SheetContainer.js';
import { SheetContent } from './SheetContent.js';
import { SheetDragIndicator } from './SheetDragIndicator.js';
import { SheetHeader } from './SheetHeader.js';
import { Sheet } from './Sheet.js';
export { useScrollPosition } from './hooks/use-scroll-position.js';
export { useVirtualKeyboard } from './hooks/use-virtual-keyboard.js';

const BottomSheet = {
  ...Sheet,
  Container: SheetContainer,
  Header: SheetHeader,
  DragIndicator: SheetDragIndicator,
  Content: SheetContent,
  Backdrop: SheetBackdrop
};

export { BottomSheet };
//# sourceMappingURL=index.js.map
