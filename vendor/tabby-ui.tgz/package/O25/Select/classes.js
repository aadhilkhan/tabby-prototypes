const SelectClasses = {
  root: "tui-select",
  size: {
    l: "tui-select_size-l"
  },
  level: {
    1: "tui-select_level-1",
    2: "tui-select_level-2",
    3: "tui-select_level-3"
  },
  open: "tui-select_open",
  error: "tui-select_error",
  disabled: "tui-select_disabled",
  highlighted: "tui-select_highlighted",
  chevron: "tui-select__chevron",
  hint: "tui-select__hint",
  chipTriggerContent: "tui-select-chip-trigger__content"
};

export { SelectClasses };
//# sourceMappingURL=classes.js.map
