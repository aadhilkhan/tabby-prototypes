const InformerClasses = {
  root: "tui-informer",
  component: "tui-o25-component",
  size: {
    s: "tui-informer_size-s",
    l: "tui-informer_size-l"
  },
  tone: {
    neutral: "tui-informer_tone-neutral",
    positive: "tui-informer_tone-positive",
    warning: "tui-informer_tone-warning",
    error: "tui-informer_tone-error"
  },
  level: {
    1: "tui-informer_level-1",
    2: "tui-informer_level-2",
    3: "tui-informer_level-3"
  },
  clickable: "tui-informer_clickable",
  lead: "tui-informer__lead",
  leadIcon: "tui-informer__lead-icon",
  container: "tui-informer__container",
  title: "tui-informer__title",
  content: "tui-informer__content",
  button: "tui-informer__button",
  trail: "tui-informer__trail",
  trailChevron: "tui-informer__trail_chevron",
  trailClose: "tui-informer__trail_close",
  closeButton: "tui-informer__close-button"
};

export { InformerClasses };
//# sourceMappingURL=classes.js.map
