const TextClasses = {
  root: "tui-text",
  component: "tui-o25-component",
  variant: {
    h1: "tui-text_variant-h1",
    h2: "tui-text_variant-h2",
    h3: "tui-text_variant-h3",
    h4: "tui-text_variant-h4",
    h5: "tui-text_variant-h5",
    h6: "tui-text_variant-h6",
    h1Numeric: "tui-text_variant-h1-numeric",
    h2Numeric: "tui-text_variant-h2-numeric",
    h3Numeric: "tui-text_variant-h3-numeric",
    body1Tight: "tui-text_variant-body1-tight",
    body1TightBold: "tui-text_variant-body1-tight-bold",
    body1Loose: "tui-text_variant-body1-loose",
    body1LooseBold: "tui-text_variant-body1-loose-bold",
    body2Tight: "tui-text_variant-body2-tight",
    body2TightBold: "tui-text_variant-body2-tight-bold",
    body2Loose: "tui-text_variant-body2-loose",
    body2LooseBold: "tui-text_variant-body2-loose-bold",
    caption: "tui-text_variant-caption",
    captionBold: "tui-text_variant-caption-bold",
    xl: "tui-text_variant-xl",
    numbers: "tui-text_variant-numbers",
    capsL: "tui-text_variant-caps-l",
    capsM: "tui-text_variant-caps-m",
    capsS: "tui-text_variant-caps-s",
    microtext: "tui-text_variant-microtext"
  }
};

export { TextClasses };
//# sourceMappingURL=classes.js.map
