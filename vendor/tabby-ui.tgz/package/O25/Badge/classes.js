const BadgeClasses = {
  root: "tui-badge",
  component: "tui-o25-component",
  tone: {
    default: "tui-badge_tone-default",
    highlight: "tui-badge_tone-highlight",
    positive: "tui-badge_tone-positive",
    warning: "tui-badge_tone-warning",
    negative: "tui-badge_tone-negative",
    inverted: "tui-badge_tone-inverted"
  },
  weight: {
    primary: "tui-badge_weight-primary",
    secondary: "tui-badge_weight-secondary"
  },
  size: {
    xs: "tui-badge_size-xs",
    s: "tui-badge_size-s",
    m: "tui-badge_size-m"
  },
  level: {
    1: "tui-badge_level-1",
    2: "tui-badge_level-2",
    3: "tui-badge_level-3"
  },
  lead: "tui-badge_lead",
  trail: "tui-badge_trail",
  disabled: "tui-badge_disabled",
  icon: "tui-badge__icon",
  iconLead: "tui-badge__icon_lead",
  iconTrail: "tui-badge__icon_trail"
};
const CounterBadgeClasses = {
  root: "tui-counter-badge",
  component: "tui-o25-component",
  tone: {
    important: "tui-counter-badge_tone-important",
    neutralLight: "tui-counter-badge_tone-neutral-light",
    neutralDark: "tui-counter-badge_tone-neutral-dark",
    inverted: "tui-counter-badge_tone-inverted"
  },
  size: {
    xs: "tui-counter-badge_size-xs",
    s: "tui-counter-badge_size-s",
    m: "tui-counter-badge_size-m",
    l: "tui-counter-badge_size-l"
  },
  disabled: "tui-counter-badge_disabled"
};
const NotificationBadgeClasses = {
  component: "tui-o25-component",
  root: "tui-notification-badge"
};

export { BadgeClasses, CounterBadgeClasses, NotificationBadgeClasses };
//# sourceMappingURL=classes.js.map
