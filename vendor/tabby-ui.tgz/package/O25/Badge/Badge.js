import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { Text } from '../Text/Text.js';
import { BadgeClasses } from './classes.js';
import "./Badge.css";

const getTextVariant = (size) => {
  if (size === "xs") {
    return "microtext";
  }
  if (size === "s") {
    return "caption";
  }
  return "body2Tight";
};
const Badge = forwardRef(
  (props, externalRef) => {
    const {
      className,
      tone = "default",
      weight = "primary",
      size = "m",
      level = 2,
      children,
      lead,
      trail,
      disabled,
      ...rest
    } = props;
    const textVariant = getTextVariant(size);
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        ref: externalRef,
        className: cn(
          BadgeClasses.component,
          BadgeClasses.root,
          BadgeClasses.tone[tone],
          BadgeClasses.weight[weight],
          BadgeClasses.size[size],
          BadgeClasses.level[level],
          lead && BadgeClasses.lead,
          trail && BadgeClasses.trail,
          disabled && BadgeClasses.disabled,
          className
        ),
        ...rest
      },
      lead && /* @__PURE__ */ React__default.createElement("div", { className: cn(BadgeClasses.icon, BadgeClasses.iconLead) }, lead),
      /* @__PURE__ */ React__default.createElement(Text, { variant: textVariant }, children),
      trail && /* @__PURE__ */ React__default.createElement("div", { className: cn(BadgeClasses.icon, BadgeClasses.iconTrail) }, trail)
    );
  }
);
Badge.displayName = "Badge";

export { Badge };
//# sourceMappingURL=Badge.js.map
