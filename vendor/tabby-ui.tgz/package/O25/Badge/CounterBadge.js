import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { Text } from '../Text/Text.js';
import { CounterBadgeClasses } from './classes.js';
import "./CounterBadge.css";

const SIZE_TO_TEXT_VARIANT_MAP = {
  xs: "captionBold",
  s: "capsS",
  m: "capsS",
  l: "capsM"
};
const CounterBadge = forwardRef(
  (props, externalRef) => {
    const {
      className,
      tone = "neutralDark",
      size = "m",
      children,
      disabled,
      ...rest
    } = props;
    const textVariant = SIZE_TO_TEXT_VARIANT_MAP[size];
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        ref: externalRef,
        className: cn(
          CounterBadgeClasses.component,
          CounterBadgeClasses.root,
          CounterBadgeClasses.tone[tone],
          CounterBadgeClasses.size[size],
          disabled && CounterBadgeClasses.disabled,
          className
        ),
        ...rest
      },
      /* @__PURE__ */ React__default.createElement(Text, { variant: textVariant }, children)
    );
  }
);
CounterBadge.displayName = "CounterBadge";

export { CounterBadge };
//# sourceMappingURL=CounterBadge.js.map
