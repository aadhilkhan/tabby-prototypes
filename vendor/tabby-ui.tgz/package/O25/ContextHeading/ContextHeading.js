import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { Text } from '../Text/Text.js';
import { ContextHeadingClasses } from './classes.js';
import "./ContextHeading.css";

const ContextHeading = forwardRef(
  (props, ref) => {
    const { heading, subheading, trail, className, ...rest } = props;
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        className: cn(
          ContextHeadingClasses.component,
          ContextHeadingClasses.root,
          className
        ),
        ...rest,
        ref
      },
      /* @__PURE__ */ React__default.createElement("div", { className: ContextHeadingClasses.lead }, heading && /* @__PURE__ */ React__default.createElement(Text, { variant: "h1", className: ContextHeadingClasses.heading }, heading), subheading && /* @__PURE__ */ React__default.createElement(
        Text,
        {
          variant: "body1Loose",
          className: ContextHeadingClasses.subheading
        },
        subheading
      )),
      trail && /* @__PURE__ */ React__default.createElement("div", { className: ContextHeadingClasses.trail }, trail)
    );
  }
);
ContextHeading.displayName = "ContextHeading";

export { ContextHeading };
//# sourceMappingURL=ContextHeading.js.map
