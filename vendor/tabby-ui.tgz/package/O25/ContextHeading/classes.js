const ContextHeadingClasses = {
  root: "tui-context-heading",
  component: "tui-o25-component",
  lead: "tui-context-heading__lead",
  heading: "tui-context-heading__heading",
  subheading: "tui-context-heading__subheading",
  trail: "tui-context-heading__trail"
};

export { ContextHeadingClasses };
//# sourceMappingURL=classes.js.map
