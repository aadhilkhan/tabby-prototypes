const PopoverClasses = {
  root: "tui-popover",
  component: "tui-o25-component",
  inverted: "tui-popover_inverted",
  level: {
    1: "tui-popover_level-1",
    2: "tui-popover_level-2",
    3: "tui-popover_level-3"
  }
};

export { PopoverClasses };
//# sourceMappingURL=classes.js.map
