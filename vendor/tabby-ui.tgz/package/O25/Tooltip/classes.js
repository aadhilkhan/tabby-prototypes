const TooltipClasses = {
  root: "tui-tooltip",
  component: "tui-o25-component",
  inverted: "tui-tooltip_inverted",
  level: {
    1: "tui-tooltip_level-1",
    2: "tui-tooltip_level-2",
    3: "tui-tooltip_level-3"
  }
};

export { TooltipClasses };
//# sourceMappingURL=classes.js.map
