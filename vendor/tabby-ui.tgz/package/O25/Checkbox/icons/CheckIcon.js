import React__default from 'react';

function CheckIcon(props) {
  return /* @__PURE__ */ React__default.createElement(
    "svg",
    {
      className: props.className,
      xmlns: "http://www.w3.org/2000/svg",
      viewBox: "0 0 13 9",
      fill: "none"
    },
    /* @__PURE__ */ React__default.createElement(
      "path",
      {
        d: "M12.0194 1.45703L4.47644 9L0.0115967 4.53516L1.42566 3.12109L4.47644 6.17188L10.6053 0.0429688L12.0194 1.45703Z",
        fill: "currentColor"
      }
    )
  );
}

export { CheckIcon };
//# sourceMappingURL=CheckIcon.js.map
