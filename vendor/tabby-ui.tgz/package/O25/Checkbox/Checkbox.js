import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { CheckIcon } from './icons/CheckIcon.js';
import { CheckboxClasses } from './classes.js';
import "./Checkbox.css";

const Checkbox = forwardRef(
  (props, ref) => {
    const {
      size = "s",
      level = 2,
      className,
      checked,
      indeterminate,
      disabled,
      error,
      ...rest
    } = props;
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        className: cn(
          CheckboxClasses.component,
          CheckboxClasses.root,
          CheckboxClasses.size[size],
          CheckboxClasses.level[level],
          {
            [CheckboxClasses.disabled]: disabled,
            [CheckboxClasses.checked]: checked || indeterminate,
            [CheckboxClasses.error]: error && !disabled,
            [CheckboxClasses.indeterminate]: indeterminate
          },
          className
        )
      },
      /* @__PURE__ */ React__default.createElement(
        "input",
        {
          ref,
          type: "checkbox",
          className: CheckboxClasses.input,
          checked,
          disabled,
          ...rest
        }
      ),
      /* @__PURE__ */ React__default.createElement("div", { className: CheckboxClasses.icon }, checked && !indeterminate && /* @__PURE__ */ React__default.createElement(CheckIcon, { className: CheckboxClasses.svg }))
    );
  }
);
Checkbox.displayName = "Checkbox";

export { Checkbox };
//# sourceMappingURL=Checkbox.js.map
