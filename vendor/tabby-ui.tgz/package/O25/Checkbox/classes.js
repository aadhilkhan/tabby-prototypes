const CheckboxClasses = {
  root: "tui-checkbox",
  component: "tui-o25-component",
  size: {
    xs: "tui-checkbox_size-xs",
    s: "tui-checkbox_size-s"
  },
  level: {
    1: "tui-checkbox_level-1",
    2: "tui-checkbox_level-2",
    3: "tui-checkbox_level-3"
  },
  disabled: "tui-checkbox_disabled",
  checked: "tui-checkbox_checked",
  error: "tui-checkbox_error",
  indeterminate: "tui-checkbox_indeterminate",
  input: "tui-checkbox__input",
  icon: "tui-checkbox__icon",
  svg: "tui-checkbox__svg"
};

export { CheckboxClasses };
//# sourceMappingURL=classes.js.map
