const AssetClasses = {
  root: "tui-asset",
  component: "tui-o25-component",
  size: {
    xxl: "tui-asset_size-xxl",
    xl: "tui-asset_size-xl",
    l: "tui-asset_size-l",
    m: "tui-asset_size-m",
    s: "tui-asset_size-s",
    xs: "tui-asset_size-xs"
  },
  dir: {
    ltr: "tui-asset_dir-ltr",
    rtl: "tui-asset_dir-rtl"
  },
  variant: {
    rounded: "tui-asset_variant-rounded",
    square: "tui-asset_variant-square"
  },
  topBadge: "tui-asset_top-badge",
  bottomBadge: "tui-asset_bottom-badge",
  color: {
    lipstick: "tui-asset_color-lipstick",
    bubblegum: "tui-asset_color-bubblegum",
    iris: "tui-asset_color-iris",
    green: "tui-asset_color-green",
    honey: "tui-asset_color-honey",
    lipstickInverted: "tui-asset_color-lipstick-inverted",
    bubblegumInverted: "tui-asset_color-bubblegum-inverted",
    irisInverted: "tui-asset_color-iris-inverted",
    greenInverted: "tui-asset_color-green-inverted",
    honeyInverted: "tui-asset_color-honey-inverted"
  },
  colorByKebab: {
    lipstick: "tui-asset_color-lipstick",
    bubblegum: "tui-asset_color-bubblegum",
    iris: "tui-asset_color-iris",
    green: "tui-asset_color-green",
    honey: "tui-asset_color-honey",
    "lipstick-inverted": "tui-asset_color-lipstick-inverted",
    "bubblegum-inverted": "tui-asset_color-bubblegum-inverted",
    "iris-inverted": "tui-asset_color-iris-inverted",
    "green-inverted": "tui-asset_color-green-inverted",
    "honey-inverted": "tui-asset_color-honey-inverted"
  },
  overlay: "tui-asset_overlay",
  content: "tui-asset__content",
  image: "tui-asset__image",
  badge: "tui-asset__badge",
  badgeTop: "tui-asset__badge_top",
  badgeBottom: "tui-asset__badge_bottom"
};
const AssetFlagClasses = {
  root: "tui-asset-flag"
};
const AssetNotificationClasses = {
  root: "tui-asset-notification",
  size: {
    xxl: "tui-asset-notification_size-xxl",
    m: "tui-asset-notification_size-m",
    s: "tui-asset-notification_size-s",
    xs: "tui-asset-notification_size-xs"
  },
  shown: "tui-asset-notification_shown",
  notificationBadge: "tui-asset_notification-badge"
};
const AssetProgressClasses = {
  root: "tui-asset-progress",
  size: {
    xxl: "tui-asset-progress_size-xxl",
    m: "tui-asset-progress_size-m",
    s: "tui-asset-progress_size-s",
    xs: "tui-asset-progress_size-xs"
  }
};

export { AssetClasses, AssetFlagClasses, AssetNotificationClasses, AssetProgressClasses };
//# sourceMappingURL=classes.js.map
