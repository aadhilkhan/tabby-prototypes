import React__default, { forwardRef } from 'react';
import cn from 'classnames';
import { Asset } from './Asset.js';
import { AssetFlagClasses } from './classes.js';
import "./AssetFlag.css";

const AssetFlag = forwardRef(
  (props, ref) => {
    const { size = "m", className, ...rest } = props;
    return /* @__PURE__ */ React__default.createElement(
      Asset,
      {
        ref,
        ...rest,
        size,
        className: cn(AssetFlagClasses.root, className)
      }
    );
  }
);
AssetFlag.displayName = "AssetFlag";

export { AssetFlag };
//# sourceMappingURL=AssetFlag.js.map
