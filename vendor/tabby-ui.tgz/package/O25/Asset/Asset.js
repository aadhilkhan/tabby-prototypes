import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { useDir } from '../../hooks/useDir.js';
import { putDevError } from '../utils/putDevError.js';
import { Text } from '../Text/Text.js';
import { AssetClasses } from './classes.js';
import "./Asset.css";

const getTextVariant = (size) => {
  if (["xxl", "xl", "l"].includes(size)) {
    return "body1TightBold";
  }
  if (size === "m") {
    return "body2TightBold";
  }
  if (size === "s") {
    return "captionBold";
  }
  return "capsS";
};
const Asset = forwardRef((props, ref) => {
  const {
    children,
    size = "m",
    src,
    topBadge,
    bottomBadge,
    className,
    color,
    alwaysShowTopBadge = false,
    variant = "rounded",
    overlay = false,
    srcAlt = "",
    ...rest
  } = props;
  const [imgLoadingError, setImgLoadingError] = React__default.useState(false);
  const isTopBadgeVisible = size !== "xs" && variant === "rounded" || alwaysShowTopBadge;
  const isBottomBadgeVisible = size !== "xs" && variant === "rounded";
  const dir = useDir();
  if ((topBadge || bottomBadge) && size === "xs") {
    putDevError("Badges is available for all sizes except xs");
  }
  if ((topBadge || bottomBadge) && variant === "square") {
    putDevError("Badges is available for only rounded variant");
  }
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      ref,
      className: cn(
        AssetClasses.component,
        AssetClasses.root,
        AssetClasses.size[size],
        AssetClasses.dir[dir],
        AssetClasses.variant[variant],
        color && AssetClasses.colorByKebab[color],
        overlay && AssetClasses.overlay,
        {
          [AssetClasses.topBadge]: topBadge && isTopBadgeVisible,
          [AssetClasses.bottomBadge]: bottomBadge && isBottomBadgeVisible
        },
        className
      ),
      ...rest
    },
    topBadge && isTopBadgeVisible && /* @__PURE__ */ React__default.createElement("div", { className: cn(AssetClasses.badge, AssetClasses.badgeTop) }, topBadge),
    /* @__PURE__ */ React__default.createElement("div", { className: AssetClasses.content }, src && !imgLoadingError ? /* @__PURE__ */ React__default.createElement(
      "img",
      {
        alt: srcAlt,
        className: AssetClasses.image,
        src,
        onError: () => setImgLoadingError(true)
      }
    ) : /* @__PURE__ */ React__default.createElement(Text, { variant: getTextVariant(size) }, children)),
    bottomBadge && isBottomBadgeVisible && /* @__PURE__ */ React__default.createElement("div", { className: cn(AssetClasses.badge, AssetClasses.badgeBottom) }, bottomBadge)
  );
});
Asset.displayName = "Asset";

export { Asset };
//# sourceMappingURL=Asset.js.map
