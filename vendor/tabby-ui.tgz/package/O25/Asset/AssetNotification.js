import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { Asset } from './Asset.js';
import { AssetNotificationClasses } from './classes.js';
import '../Badge/Badge.js';
import '../Badge/CounterBadge.js';
import { NotificationBadge } from '../Badge/NotificationBadge.js';
import "./AssetNotification.css";

const AssetNotification = forwardRef((props, ref) => {
  const { className, notification = true, size } = props;
  return /* @__PURE__ */ React__default.createElement(
    Asset,
    {
      ref,
      topBadge: notification ? /* @__PURE__ */ React__default.createElement(
        NotificationBadge,
        {
          className: AssetNotificationClasses.notificationBadge
        }
      ) : null,
      className: cn(
        AssetNotificationClasses.root,
        size && AssetNotificationClasses.size[size],
        notification && AssetNotificationClasses.shown,
        className
      ),
      size,
      alwaysShowTopBadge: true,
      ...props
    }
  );
});
AssetNotification.displayName = "AssetNotification";

export { AssetNotification };
//# sourceMappingURL=AssetNotification.js.map
