import React__default, { forwardRef } from 'react';
import cn from 'classnames';
import { Asset } from './Asset.js';
import { AssetProgressClasses } from './classes.js';
import "./AssetProgress.css";

const AssetProgress = forwardRef(
  (props, ref) => {
    const { className, progress = 0, size, ...rest } = props;
    const calculatedProgress = Math.max(0, Math.min(progress, 100));
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        style: {
          "--tui-asset-progress": `${calculatedProgress}%`
        },
        className: cn(
          AssetProgressClasses.root,
          size && AssetProgressClasses.size[size]
        )
      },
      /* @__PURE__ */ React__default.createElement(Asset, { ref, ...rest, className, size })
    );
  }
);
AssetProgress.displayName = "AssetProgress";

export { AssetProgress };
//# sourceMappingURL=AssetProgress.js.map
