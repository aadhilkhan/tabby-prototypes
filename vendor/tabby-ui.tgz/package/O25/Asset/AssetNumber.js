import React__default, { forwardRef } from 'react';
import { Asset } from './Asset.js';
import { Text } from '../Text/Text.js';

const getTextVariant = (size) => {
  if (size === "xs") {
    return "capsS";
  }
  return "body2Tight";
};
const AssetNumber = forwardRef(
  (props, ref) => {
    const { size = "m", children, ...rest } = props;
    return /* @__PURE__ */ React__default.createElement(Asset, { ref, ...rest, size }, /* @__PURE__ */ React__default.createElement(Text, { variant: getTextVariant(size) }, children));
  }
);
AssetNumber.displayName = "AssetNumber";

export { AssetNumber };
//# sourceMappingURL=AssetNumber.js.map
