import cn from 'classnames';
import React__default, { forwardRef, Children } from 'react';
import { putDevError } from '../utils/putDevError.js';
import "./AssetDouble.css";

const isForwardRefComponent = (type) => {
  return !!type && typeof type === "object" && type.$$typeof === Symbol.for("react.forward_ref");
};
const filterChildren = (children) => {
  return Children.toArray(children).filter((item) => {
    return React__default.isValidElement(item) && isForwardRefComponent(item.type) && item.type.displayName === "Asset";
  });
};
const mapSizes = {
  xxl: "m",
  m: "xs"
};
const AssetDouble = forwardRef(
  (props, ref) => {
    const { className, children, size = "m", ...rest } = props;
    const assets = filterChildren(children);
    if (children?.length !== assets?.length) {
      putDevError("Only component Asset could be used as a child");
    }
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        className: cn(
          "tui-o25-component",
          "tui-asset-double",
          `tui-asset-double_size-${size}`,
          className
        ),
        ref,
        ...rest
      },
      React__default.Children.map(
        assets,
        (item) => React__default.cloneElement(item, {
          size: mapSizes[size],
          variant: "rounded",
          topBadge: null,
          bottomBadge: null
        })
      )
    );
  }
);
AssetDouble.displayName = "AssetDouble";

export { AssetDouble };
//# sourceMappingURL=AssetDouble.js.map
