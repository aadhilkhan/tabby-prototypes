const TextFieldClasses = {
  root: "tui-text-field",
  component: "tui-o25-component",
  size: {
    l: "tui-text-field_size-l",
    m: "tui-text-field_size-m",
    s: "tui-text-field_size-s"
  },
  level: {
    1: "tui-text-field_level-1",
    2: "tui-text-field_level-2",
    3: "tui-text-field_level-3"
  },
  focused: "tui-text-field_focused",
  error: "tui-text-field_error",
  disabled: "tui-text-field_disabled",
  filled: "tui-text-field_filled",
  lead: "tui-text-field_lead",
  trail: "tui-text-field_trail",
  placeholder: "tui-text-field_placeholder",
  searchBar: "tui-text-field_search-bar",
  select: "tui-text-field_select",
  selectEmpty: "tui-text-field_select-empty",
  selectOpen: "tui-text-field_select-open",
  container: "tui-text-field__container",
  labelWrapper: "tui-text-field__label-wrapper",
  label: "tui-text-field__label",
  labelInside: "tui-text-field__label_inside",
  icon: "tui-text-field__icon",
  iconLead: "tui-text-field__icon_lead",
  iconError: "tui-text-field__icon_error",
  iconClose: "tui-text-field__icon_close",
  iconTrail: "tui-text-field__icon_trail",
  center: "tui-text-field__center",
  inputLine: "tui-text-field__input-line",
  prefix: "tui-text-field__prefix",
  input: "tui-text-field__input",
  trailBlock: "tui-text-field__trail-block",
  bottomLine: "tui-text-field__bottom-line",
  hint: "tui-text-field__hint",
  counter: "tui-text-field__counter"
};

export { TextFieldClasses };
//# sourceMappingURL=classes.js.map
