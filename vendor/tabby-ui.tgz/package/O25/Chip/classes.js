const ChipClasses = {
  root: "tui-chip",
  component: "tui-o25-component",
  size: {
    md: "tui-chip_size-md",
    sm: "tui-chip_size-sm",
    xs: "tui-chip_size-xs"
  },
  tone: {
    neutral: "tui-chip_tone-neutral",
    inverted: "tui-chip_tone-inverted"
  },
  level: {
    1: "tui-chip_level-1",
    2: "tui-chip_level-2",
    3: "tui-chip_level-3"
  },
  disabled: "tui-chip_disabled",
  selected: "tui-chip_selected",
  withLead: "tui-chip_with-lead",
  withTrail: "tui-chip_with-trail",
  withCloseButton: "tui-chip_with-close-button",
  container: "tui-chip__container",
  content: "tui-chip__content",
  lead: "tui-chip__lead",
  trail: "tui-chip__trail",
  closeButton: "tui-chip__close-button",
  innerButton: "tui-chip__inner-button"
};

export { ChipClasses };
//# sourceMappingURL=classes.js.map
