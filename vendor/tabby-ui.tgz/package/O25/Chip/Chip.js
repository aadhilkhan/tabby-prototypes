import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import Close24 from '../../icons/core/Close24.js';
import { Text } from '../Text/Text.js';
import { ChipClasses } from './classes.js';
import "./Chip.css";

const CHIP_TEXT_VARIANT_MAP = {
  md: "body2Tight",
  sm: "body2Tight",
  xs: "caption"
};
const Chip = forwardRef(
  (props, externalRef) => {
    const {
      size = "md",
      tone = "neutral",
      level = 2,
      className,
      children,
      lead,
      trail,
      isSelected,
      disabled,
      onClose,
      ...rest
    } = props;
    const labelVariant = CHIP_TEXT_VARIANT_MAP[size];
    const chipClassName = cn(
      ChipClasses.component,
      ChipClasses.root,
      ChipClasses.size[size],
      ChipClasses.tone[tone],
      ChipClasses.level[level],
      isSelected && ChipClasses.selected,
      disabled && ChipClasses.disabled,
      lead && ChipClasses.withLead,
      trail && ChipClasses.withTrail,
      onClose && ChipClasses.withCloseButton,
      className
    );
    const chipButton = /* @__PURE__ */ React__default.createElement(
      "button",
      {
        type: "button",
        ref: externalRef,
        className: onClose ? ChipClasses.innerButton : chipClassName,
        disabled,
        ...rest
      },
      /* @__PURE__ */ React__default.createElement("div", { className: ChipClasses.container }, lead && /* @__PURE__ */ React__default.createElement("div", { className: ChipClasses.lead }, lead), children && /* @__PURE__ */ React__default.createElement(Text, { className: ChipClasses.content, variant: labelVariant }, children), trail && /* @__PURE__ */ React__default.createElement("div", { className: ChipClasses.trail }, trail))
    );
    if (!onClose) {
      return chipButton;
    }
    return /* @__PURE__ */ React__default.createElement("div", { role: "group", className: chipClassName }, chipButton, /* @__PURE__ */ React__default.createElement(
      "button",
      {
        type: "button",
        className: ChipClasses.closeButton,
        onClick: onClose,
        disabled,
        "aria-label": "close",
        tabIndex: disabled ? -1 : 0
      },
      /* @__PURE__ */ React__default.createElement(Close24, { size: 14 })
    ));
  }
);
Chip.displayName = "Chip";

export { Chip };
//# sourceMappingURL=Chip.js.map
