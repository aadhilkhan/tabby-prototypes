const TabBarClasses = {
  component: "tui-o25-component",
  wrapper: "tui-tab-bar-wrapper",
  root: "tui-tab-bar",
  element: "tui-tab-bar__element",
  elementActive: "tui-tab-bar__element_active",
  label: "tui-tab-bar__label",
  indicator: "tui-tab-bar__indicator",
  floatingButton: "tui-tab-bar__floating-button"
};

export { TabBarClasses };
//# sourceMappingURL=classes.js.map
