import cn from 'classnames';
import React__default from 'react';
import AlertCircleStrokeFill24 from '../../icons/core/AlertCircleStrokeFill24.js';
import { Text } from '../Text/Text.js';
import { TextButton } from '../TextButton/TextButton.js';
import { AlertTopClasses } from './classes.js';

function AlertTopDesktop(props) {
  const { title, subtitle, icon, buttonLabel, onButtonClick } = props;
  return /* @__PURE__ */ React__default.createElement(
    "div",
    {
      className: cn(
        AlertTopClasses.container,
        AlertTopClasses.containerDesktop
      )
    },
    /* @__PURE__ */ React__default.createElement("div", { className: AlertTopClasses.icon }, icon ?? /* @__PURE__ */ React__default.createElement(AlertCircleStrokeFill24, { size: 16 })),
    /* @__PURE__ */ React__default.createElement("div", { className: AlertTopClasses.text }, /* @__PURE__ */ React__default.createElement(Text, { variant: "h5", asChild: true, className: AlertTopClasses.title }, /* @__PURE__ */ React__default.createElement("div", null, title)), subtitle && /* @__PURE__ */ React__default.createElement(Text, { variant: "body2Tight", className: AlertTopClasses.subtitle }, subtitle)),
    buttonLabel && /* @__PURE__ */ React__default.createElement(
      TextButton,
      {
        size: "body2Bold",
        type: "primary",
        className: AlertTopClasses.button,
        onClick: onButtonClick
      },
      buttonLabel
    )
  );
}

export { AlertTopDesktop };
//# sourceMappingURL=AlertTopDesktop.js.map
