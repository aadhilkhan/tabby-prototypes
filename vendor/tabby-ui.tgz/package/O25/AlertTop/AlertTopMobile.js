import cn from 'classnames';
import React__default from 'react';
import AlertCircleStrokeFill24 from '../../icons/core/AlertCircleStrokeFill24.js';
import ChevronForward24 from '../../icons/core/ChevronForward24.js';
import { Text } from '../Text/Text.js';
import { AlertTopClasses } from './classes.js';

function AlertTopMobile(props) {
  const { title, subtitle, icon, onButtonClick } = props;
  return /* @__PURE__ */ React__default.createElement(
    "button",
    {
      type: "button",
      className: cn(AlertTopClasses.container, AlertTopClasses.containerMobile),
      onClick: onButtonClick
    },
    /* @__PURE__ */ React__default.createElement("div", { className: AlertTopClasses.text }, /* @__PURE__ */ React__default.createElement("div", { className: AlertTopClasses.titleRow }, /* @__PURE__ */ React__default.createElement("div", { className: AlertTopClasses.icon }, icon ?? /* @__PURE__ */ React__default.createElement(AlertCircleStrokeFill24, { size: 16 })), /* @__PURE__ */ React__default.createElement(Text, { variant: "h4", asChild: true, className: AlertTopClasses.title }, /* @__PURE__ */ React__default.createElement("div", null, title))), subtitle && /* @__PURE__ */ React__default.createElement(Text, { variant: "body1Loose", className: AlertTopClasses.subtitle }, subtitle)),
    /* @__PURE__ */ React__default.createElement(ChevronForward24, { className: AlertTopClasses.chevron })
  );
}

export { AlertTopMobile };
//# sourceMappingURL=AlertTopMobile.js.map
