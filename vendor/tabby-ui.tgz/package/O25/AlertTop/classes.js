const AlertTopClasses = {
  root: "tui-alert-top",
  component: "tui-o25-component",
  tone: {
    negative: "tui-alert-top_tone-negative",
    warning: "tui-alert-top_tone-warning",
    positive: "tui-alert-top_tone-positive",
    neutralDark: "tui-alert-top_tone-neutral-dark",
    neutralLight: "tui-alert-top_tone-neutral-light",
    primary: "tui-alert-top_tone-primary"
  },
  container: "tui-alert-top__container",
  containerDesktop: "tui-alert-top__container_desktop",
  containerMobile: "tui-alert-top__container_mobile",
  icon: "tui-alert-top__icon",
  text: "tui-alert-top__text",
  titleRow: "tui-alert-top__title-row",
  title: "tui-alert-top__title",
  subtitle: "tui-alert-top__subtitle",
  button: "tui-alert-top__button",
  chevron: "tui-alert-top__chevron"
};

export { AlertTopClasses };
//# sourceMappingURL=classes.js.map
