import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { AlertTopDesktop } from './AlertTopDesktop.js';
import { AlertTopMobile } from './AlertTopMobile.js';
import { AlertTopClasses } from './classes.js';
import "./AlertTop.css";

const AlertTop = forwardRef(
  (props, ref) => {
    const {
      tone = "negative",
      title,
      subtitle,
      icon,
      buttonLabel,
      onButtonClick,
      className,
      ...rest
    } = props;
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        className: cn(
          AlertTopClasses.component,
          AlertTopClasses.root,
          AlertTopClasses.tone[tone],
          className
        ),
        role: "alert",
        ...rest,
        ref
      },
      /* @__PURE__ */ React__default.createElement(
        AlertTopDesktop,
        {
          title,
          subtitle,
          icon,
          buttonLabel,
          onButtonClick
        }
      ),
      /* @__PURE__ */ React__default.createElement(
        AlertTopMobile,
        {
          title,
          subtitle,
          icon,
          onButtonClick
        }
      )
    );
  }
);
AlertTop.displayName = "AlertTop";

export { AlertTop };
//# sourceMappingURL=AlertTop.js.map
