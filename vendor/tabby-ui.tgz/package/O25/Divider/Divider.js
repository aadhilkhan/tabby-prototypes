import React__default, { forwardRef } from 'react';
import cn from 'classnames';
import { DividerClasses } from './classes.js';
import "./Divider.css";

const Divider = forwardRef(
  (props, externalRef) => {
    const { className, orientation = "horizontal", level = 2, ...rest } = props;
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        ref: externalRef,
        className: cn(
          DividerClasses.component,
          DividerClasses.root,
          DividerClasses.orientation[orientation],
          DividerClasses.level[level],
          className
        ),
        ...rest
      }
    );
  }
);
Divider.displayName = "Divider";

export { Divider };
//# sourceMappingURL=Divider.js.map
