const DividerClasses = {
  root: "tui-divider",
  component: "tui-o25-component",
  orientation: {
    horizontal: "tui-divider_orientation-horizontal",
    vertical: "tui-divider_orientation-vertical"
  },
  level: {
    1: "tui-divider_level-1",
    2: "tui-divider_level-2",
    3: "tui-divider_level-3"
  }
};

export { DividerClasses };
//# sourceMappingURL=classes.js.map
