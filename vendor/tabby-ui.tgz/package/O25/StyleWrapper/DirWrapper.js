import cn from 'classnames';
import React__default, { createContext, forwardRef, useMemo, useEffect } from 'react';

const DirWrapperContext = createContext(void 0);
const DirWrapper = forwardRef(
  (props, ref) => {
    const {
      dir = "ltr",
      setDocumentDir = true,
      className,
      children,
      ...rest
    } = props;
    const contextProps = useMemo(() => ({ dir }), [dir]);
    useEffect(() => {
      if (setDocumentDir) {
        document.dir = dir;
      }
    }, [setDocumentDir, dir]);
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        ...rest,
        className: cn("tui-dir-wrapper", className),
        dir,
        ref
      },
      /* @__PURE__ */ React__default.createElement(DirWrapperContext.Provider, { value: contextProps }, children)
    );
  }
);
DirWrapper.displayName = "DirWrapper";

export { DirWrapper, DirWrapperContext };
//# sourceMappingURL=DirWrapper.js.map
