import { THEME_CLASS_O25_LIGHT, THEME_CLASS_O26_DARK, THEME_CLASS_O26_LIGHT, THEME_CLASS_O25_DARK } from './themeClassNames.js';

const StyleWrapperClasses = {
  themeO25Light: THEME_CLASS_O25_LIGHT,
  themeO25Dark: THEME_CLASS_O25_DARK,
  themeO26Light: THEME_CLASS_O26_LIGHT,
  themeO26Dark: THEME_CLASS_O26_DARK
};

export { StyleWrapperClasses };
//# sourceMappingURL=classes.js.map
