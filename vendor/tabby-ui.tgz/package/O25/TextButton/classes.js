const TextButtonClasses = {
  root: "tui-text-button",
  component: "tui-o25-component",
  size: {
    body1: "tui-text-button_size-body1",
    body1Bold: "tui-text-button_size-body1Bold",
    body2: "tui-text-button_size-body2",
    body2Bold: "tui-text-button_size-body2Bold",
    caption: "tui-text-button_size-caption",
    captionBold: "tui-text-button_size-caption-bold"
  },
  type: {
    primary: "tui-text-button_type-primary",
    primaryAccent: "tui-text-button_type-primaryAccent",
    secondary: "tui-text-button_type-secondary"
  },
  disabled: "tui-text-button_disabled",
  chevron: "tui-text-button_chevron",
  container: "tui-text-button__container",
  trail: "tui-text-button__trail"
};

export { TextButtonClasses };
//# sourceMappingURL=classes.js.map
