const GlobalHeadingClasses = {
  root: "tui-global-heading",
  component: "tui-o25-component",
  scrolled: "tui-global-heading_scrolled",
  container: "tui-global-heading__container",
  lead: "tui-global-heading__lead",
  breadcrumbs: "tui-global-heading__breadcrumbs",
  separator: "tui-global-heading__separator",
  breadcrumb: "tui-global-heading__breadcrumb",
  breadcrumbContent: "tui-global-heading__breadcrumb-content",
  breadcrumbActive: "tui-global-heading__breadcrumb_active",
  backIcon: "tui-global-heading__back-icon",
  trail: "tui-global-heading__trail"
};

export { GlobalHeadingClasses };
//# sourceMappingURL=classes.js.map
