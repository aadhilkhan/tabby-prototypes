export { GlobalHeading } from './GlobalHeading.js';
export { GlobalHeadingClasses } from './classes.js';
//# sourceMappingURL=index.js.map
