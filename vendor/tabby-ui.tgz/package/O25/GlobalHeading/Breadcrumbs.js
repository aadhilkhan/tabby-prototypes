import React__default, { useMemo } from 'react';
import ArrowBack24 from '../../icons/core/ArrowBack24.js';
import { Text } from '../Text/Text.js';
import { TextButton } from '../TextButton/TextButton.js';

function computeCrumbs(items, isSticky) {
  if (items.length === 0) return [];
  if (items.length === 1) {
    if (!isSticky) return [];
    const currentPage = items[items.length - 1];
    return [{ ...currentPage, isActive: true, showBackIcon: false }];
  }
  if (!isSticky) {
    return [{ ...items[0], isActive: false, showBackIcon: true }];
  }
  return [
    { ...items[0], isActive: false, showBackIcon: true },
    { ...items[items.length - 1], isActive: true, showBackIcon: false }
  ];
}
function Separator() {
  return /* @__PURE__ */ React__default.createElement(Text, { variant: "body2Tight", className: "tui-global-heading__separator" }, "/");
}
function ActiveCrumb(props) {
  const { label } = props;
  return /* @__PURE__ */ React__default.createElement(
    Text,
    {
      variant: "body2Tight",
      className: "tui-global-heading__breadcrumb tui-global-heading__breadcrumb_active"
    },
    label
  );
}
function LinkCrumb(props) {
  const { label, onClick, showBackIcon } = props;
  return /* @__PURE__ */ React__default.createElement(
    TextButton,
    {
      size: "body2",
      type: "secondary",
      className: "tui-global-heading__breadcrumb",
      onClick
    },
    /* @__PURE__ */ React__default.createElement("span", { className: "tui-global-heading__breadcrumb-content" }, showBackIcon && /* @__PURE__ */ React__default.createElement(ArrowBack24, { size: 18, className: "tui-global-heading__back-icon" }), label)
  );
}
function Breadcrumbs(props) {
  const { items, isSticky } = props;
  const crumbs = useMemo(
    () => computeCrumbs(items, isSticky),
    [items, isSticky]
  );
  if (crumbs.length === 0) return null;
  return /* @__PURE__ */ React__default.createElement("nav", { className: "tui-global-heading__breadcrumbs", "aria-label": "Breadcrumb" }, crumbs.map((crumb, index) => /* @__PURE__ */ React__default.createElement(React__default.Fragment, { key: crumb.label }, index > 0 && /* @__PURE__ */ React__default.createElement(Separator, null), crumb.isActive ? /* @__PURE__ */ React__default.createElement(ActiveCrumb, { label: crumb.label }) : /* @__PURE__ */ React__default.createElement(LinkCrumb, { ...crumb }))));
}

export { Breadcrumbs };
//# sourceMappingURL=Breadcrumbs.js.map
