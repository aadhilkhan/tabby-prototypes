import cn from 'classnames';
import React__default, { forwardRef, useState, useEffect } from 'react';
import { Breadcrumbs } from './Breadcrumbs.js';
import { GlobalHeadingClasses } from './classes.js';
import "./GlobalHeading.css";

const HEADER_HEIGHT = 64;
const GlobalHeading = forwardRef(
  (props, ref) => {
    const {
      breadcrumbs = [],
      trail,
      scrollContainerRef,
      className,
      ...rest
    } = props;
    const [isSticky, setIsSticky] = useState(false);
    useEffect(() => {
      const target = scrollContainerRef?.current ?? window;
      const handleScroll = () => {
        const scrollTop = target === window ? window.scrollY : target.scrollTop;
        setIsSticky(scrollTop >= HEADER_HEIGHT);
      };
      handleScroll();
      target.addEventListener("scroll", handleScroll);
      return () => target.removeEventListener("scroll", handleScroll);
    }, [scrollContainerRef]);
    return /* @__PURE__ */ React__default.createElement(
      "header",
      {
        className: cn(
          GlobalHeadingClasses.component,
          GlobalHeadingClasses.root,
          isSticky && GlobalHeadingClasses.scrolled,
          className
        ),
        ...rest,
        ref
      },
      /* @__PURE__ */ React__default.createElement("div", { className: GlobalHeadingClasses.container }, /* @__PURE__ */ React__default.createElement("div", { className: GlobalHeadingClasses.lead }, /* @__PURE__ */ React__default.createElement(Breadcrumbs, { items: breadcrumbs, isSticky }))),
      trail && /* @__PURE__ */ React__default.createElement("div", { className: GlobalHeadingClasses.trail }, trail)
    );
  }
);
GlobalHeading.displayName = "GlobalHeading";

export { GlobalHeading };
//# sourceMappingURL=GlobalHeading.js.map
