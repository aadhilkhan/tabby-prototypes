const LogoClasses = {
  root: "tui-logo",
  component: "tui-o25-component"
};

export { LogoClasses };
//# sourceMappingURL=classes.js.map
