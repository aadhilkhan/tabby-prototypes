const ReadOnlyClasses = {
  root: "tui-read-only",
  component: "tui-o25-component",
  level: {
    1: "tui-read-only_level-1",
    2: "tui-read-only_level-2",
    3: "tui-read-only_level-3"
  },
  clipboard: "tui-read-only__clipboard",
  clipboardTrigger: "tui-read-only__clipboard-trigger",
  clipboardIconContainer: "tui-read-only__clipboard-icon-container",
  clipboardIconCopied: "tui-read-only__clipboard-icon-copied",
  clipboardIconCopy: "tui-read-only__clipboard-icon-copy"
};

export { ReadOnlyClasses };
//# sourceMappingURL=classes.js.map
