export { ReadOnly } from './ReadOnly.js';
export { ReadOnlyClasses } from './classes.js';
//# sourceMappingURL=index.js.map
