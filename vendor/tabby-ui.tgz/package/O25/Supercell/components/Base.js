import React__default, { forwardRef } from 'react';
import cn from 'classnames';
import { SupercellClasses } from '../classes.js';

const Base = forwardRef((props, ref) => {
  const { children, className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement("div", { className: cn(SupercellClasses.base, className), ...rest, ref }, children);
});
Base.displayName = "SupercellBase";

export { Base };
//# sourceMappingURL=Base.js.map
