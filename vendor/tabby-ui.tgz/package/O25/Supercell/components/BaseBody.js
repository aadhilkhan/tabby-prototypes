import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { Text } from '../../Text/Text.js';
import { SupercellClasses } from '../classes.js';

const BaseBody = forwardRef(
  (props, ref) => {
    const { children, className, multiline = false, ...rest } = props;
    return /* @__PURE__ */ React__default.createElement(Text, { variant: "body1Tight", asChild: true }, /* @__PURE__ */ React__default.createElement(
      "div",
      {
        className: cn(
          SupercellClasses.baseBody,
          multiline && SupercellClasses.baseBodyMultiline,
          className
        ),
        ...rest,
        ref
      },
      children
    ));
  }
);
BaseBody.displayName = "SupercellBaseBody";

export { BaseBody };
//# sourceMappingURL=BaseBody.js.map
