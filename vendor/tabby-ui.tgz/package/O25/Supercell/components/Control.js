import React__default, { forwardRef, useRef, useImperativeHandle } from 'react';
import cn from 'classnames';
import { SupercellClasses } from '../classes.js';

const Control = forwardRef(
  (props, externalRef) => {
    const { children, className, contentType, ...rest } = props;
    const containerRef = useRef(null);
    useImperativeHandle(externalRef, () => containerRef.current);
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        className: cn(
          SupercellClasses.control,
          contentType && SupercellClasses.controlContentType[contentType],
          className
        ),
        ...rest,
        ref: containerRef
      },
      children
    );
  }
);
Control.displayName = "SupercellControl";

export { Control };
//# sourceMappingURL=Control.js.map
