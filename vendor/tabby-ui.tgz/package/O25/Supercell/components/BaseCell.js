import React__default, { forwardRef } from 'react';
import cn from 'classnames';
import { SupercellClasses } from '../classes.js';

const BaseCell = forwardRef(
  (props, ref) => {
    const { children, className, ...rest } = props;
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        className: cn(SupercellClasses.baseCell, className),
        ...rest,
        ref
      },
      children
    );
  }
);
BaseCell.displayName = "SupercellBaseCell";

export { BaseCell };
//# sourceMappingURL=BaseCell.js.map
