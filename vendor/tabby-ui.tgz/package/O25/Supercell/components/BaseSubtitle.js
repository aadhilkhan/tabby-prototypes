import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { Text } from '../../Text/Text.js';
import { SupercellClasses } from '../classes.js';

const BaseSubtitle = forwardRef(
  (props, ref) => {
    const { children, className, multiline, ...rest } = props;
    return /* @__PURE__ */ React__default.createElement(Text, { variant: "body2Tight", asChild: true }, /* @__PURE__ */ React__default.createElement(
      "div",
      {
        className: cn(
          SupercellClasses.baseSubtitle,
          multiline && SupercellClasses.baseSubtitleMultiline,
          className
        ),
        ...rest,
        ref
      },
      children
    ));
  }
);
BaseSubtitle.displayName = "SupercellBaseSubtitle";

export { BaseSubtitle };
//# sourceMappingURL=BaseSubtitle.js.map
