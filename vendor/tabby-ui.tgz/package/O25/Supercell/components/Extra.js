import React__default, { forwardRef } from 'react';
import cn from 'classnames';
import { SupercellClasses } from '../classes.js';

const Extra = forwardRef((props, ref) => {
  const { children, className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement("div", { className: cn(SupercellClasses.extra, className), ...rest, ref }, children);
});
Extra.displayName = "SupercellExtra";

export { Extra };
//# sourceMappingURL=Extra.js.map
