const SupercellClasses = {
  root: "tui-supercell",
  component: "tui-o25-component",
  orientation: {
    columns: "tui-supercell_orientation-columns",
    rows: "tui-supercell_orientation-rows"
  },
  clickable: "tui-supercell_clickable",
  disabled: "tui-supercell_disabled",
  lead: "tui-supercell__lead",
  base: "tui-supercell__base",
  baseCell: "tui-supercell__base-cell",
  baseBody: "tui-supercell__base-body",
  baseBodyMultiline: "tui-supercell__base-body_multiline",
  baseSubtitle: "tui-supercell__base-subtitle",
  baseSubtitleMultiline: "tui-supercell__base-subtitle_multiline",
  control: "tui-supercell__control",
  controlContentType: {
    input: "tui-supercell__control_input",
    icon: "tui-supercell__control_icon",
    "icon-button": "tui-supercell__control_icon-button",
    chevron: "tui-supercell__control_chevron"
  },
  extra: "tui-supercell__extra"
};

export { SupercellClasses };
//# sourceMappingURL=classes.js.map
