const SidebarClasses = {
  root: "tui-sidebar",
  component: "tui-o25-component",
  logo: "tui-sidebar__logo",
  logoCollapsed: "tui-sidebar__logo-collapsed",
  logoExtended: "tui-sidebar__logo-extended",
  nav: "tui-sidebar__nav",
  group: "tui-sidebar__group",
  groupHeader: "tui-sidebar__group-header",
  groupHeaderActive: "tui-sidebar__group-header_active",
  groupHeaderDisabled: "tui-sidebar__group-header_disabled",
  groupTitle: "tui-sidebar__group-title",
  groupIcon: "tui-sidebar__group-icon",
  item: "tui-sidebar__item",
  itemActive: "tui-sidebar__item_active",
  itemLabel: "tui-sidebar__item-label",
  itemBadge: "tui-sidebar__item-badge"
};

export { SidebarClasses };
//# sourceMappingURL=classes.js.map
