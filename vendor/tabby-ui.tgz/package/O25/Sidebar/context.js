import { createContext, useContext } from 'react';

const SidebarContext = createContext(
  void 0
);
function useSidebarContext() {
  return useContext(SidebarContext);
}

export { SidebarContext, useSidebarContext };
//# sourceMappingURL=context.js.map
