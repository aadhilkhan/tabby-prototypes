import { createContext, useContext } from 'react';

const LayoutContext = createContext(
  void 0
);
function useLayoutScrollContainer() {
  return useContext(LayoutContext)?.scrollContainerRef ?? null;
}

export { LayoutContext, useLayoutScrollContainer };
//# sourceMappingURL=context.js.map
