const LayoutClasses = {
  root: "tui-layout",
  component: "tui-o25-component",
  sidebar: "tui-layout__sidebar",
  main: "tui-layout__main",
  content: "tui-layout__content",
  columns: "tui-layout__columns",
  column: "tui-layout__column",
  columnsGapXs: "tui-layout__columns_gap-xs",
  columnsGapS: "tui-layout__columns_gap-s",
  columnsGapM: "tui-layout__columns_gap-m",
  columnsGapL: "tui-layout__columns_gap-l",
  columnsGapXl: "tui-layout__columns_gap-xl"
};

export { LayoutClasses };
//# sourceMappingURL=classes.js.map
