const LoaderClasses = {
  component: "tui-o25-component",
  root: "tui-loader",
  icon: "tui-loader__icon",
  withBg: "tui-loader_with-bg",
  xs: "tui-loader_xs",
  s: "tui-loader_s",
  m: "tui-loader_m",
  l: "tui-loader_l",
  neutral: "tui-loader_neutral",
  inverted: "tui-loader_inverted"
};

export { LoaderClasses };
//# sourceMappingURL=classes.js.map
