const SwipeButtonClasses = {
  root: "tui-swipe-button",
  component: "tui-o25-component",
  rootElement: "tui-swipe-button__root",
  rail: "tui-swipe-button__rail",
  overlay: "tui-swipe-button__overlay",
  slider: "tui-swipe-button__slider",
  disabled: "tui-swipe-button_disabled",
  loading: "tui-swipe-button_loading",
  sliderIconContainer: "tui-swipe-button__slider-icon-container",
  sliderIcon: "tui-swipe-button__slider-icon",
  sliderIconBack: "tui-swipe-button__slider-icon_back",
  sliderIconFront: "tui-swipe-button__slider-icon_front",
  loadingIcon: "tui-swipe-button__loading-icon"
};

export { SwipeButtonClasses };
//# sourceMappingURL=classes.js.map
