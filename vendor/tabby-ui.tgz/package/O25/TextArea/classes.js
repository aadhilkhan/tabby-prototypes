const TextAreaClasses = {
  root: "tui-text-area",
  component: "tui-o25-component",
  size: {
    l: "tui-text-area_size-l",
    m: "tui-text-area_size-m",
    s: "tui-text-area_size-s"
  },
  error: "tui-text-area_error",
  filled: "tui-text-area_filled",
  focused: "tui-text-area_focused",
  lead: "tui-text-area_lead",
  trail: "tui-text-area_trail",
  placeholder: "tui-text-area_placeholder",
  disabled: "tui-text-area_disabled",
  level: {
    1: "tui-text-area_level-1",
    2: "tui-text-area_level-2",
    3: "tui-text-area_level-3"
  },
  container: "tui-text-area__container",
  labelWrapper: "tui-text-area__label-wrapper",
  label: "tui-text-area__label",
  labelInside: "tui-text-area__label_inside",
  icon: "tui-text-area__icon",
  iconLead: "tui-text-area__icon_lead",
  iconError: "tui-text-area__icon_error",
  iconClose: "tui-text-area__icon_close",
  iconTrail: "tui-text-area__icon_trail",
  center: "tui-text-area__center",
  inputLine: "tui-text-area__input-line",
  prefix: "tui-text-area__prefix",
  input: "tui-text-area__input",
  trailBlock: "tui-text-area__trail-block",
  bottomLine: "tui-text-area__bottom-line",
  hint: "tui-text-area__hint",
  counter: "tui-text-area__counter"
};

export { TextAreaClasses };
//# sourceMappingURL=classes.js.map
