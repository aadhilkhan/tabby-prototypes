const IndicatorClasses = {
  component: "tui-o25-component",
  root: "tui-indicator__root"
};

export { IndicatorClasses };
//# sourceMappingURL=classes.js.map
