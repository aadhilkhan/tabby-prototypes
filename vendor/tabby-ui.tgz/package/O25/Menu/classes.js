const MenuClasses = {
  component: "tui-o25-component",
  positioner: "tui-menu__positioner",
  menu: "tui-menu",
  option: "tui-menu__option",
  optionDisabled: "tui-menu__option_disabled",
  optionSelected: "tui-menu__option_selected",
  optionContainer: "tui-menu__option-container"
};

export { MenuClasses };
//# sourceMappingURL=classes.js.map
