const ChipCarouselClasses = {
  root: "tui-chip-carousel",
  component: "tui-o25-component",
  viewport: "tui-chip-carousel__viewport",
  content: "tui-chip-carousel__content",
  size: {
    xs: "tui-chip-carousel_size-xs",
    sm: "tui-chip-carousel_size-sm",
    md: "tui-chip-carousel_size-md"
  }
};

export { ChipCarouselClasses };
//# sourceMappingURL=classes.js.map
