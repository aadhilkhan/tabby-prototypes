import { ScrollArea } from '@ark-ui/react/scroll-area';
import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { ChipCarouselClasses } from './classes.js';
import "./ChipCarousel.css";

const ChipCarousel = forwardRef(
  (props, externalRef) => {
    const { className, children, size = "md", ...rest } = props;
    return /* @__PURE__ */ React__default.createElement(
      ScrollArea.Root,
      {
        ref: externalRef,
        className: cn(
          ChipCarouselClasses.component,
          ChipCarouselClasses.root,
          ChipCarouselClasses.size[size],
          className
        ),
        ...rest
      },
      /* @__PURE__ */ React__default.createElement(ScrollArea.Viewport, { className: ChipCarouselClasses.viewport }, /* @__PURE__ */ React__default.createElement(ScrollArea.Content, { className: ChipCarouselClasses.content }, children))
    );
  }
);
ChipCarousel.displayName = "ChipCarousel";

export { ChipCarousel };
//# sourceMappingURL=ChipCarousel.js.map
