const SnackbarClasses = {
  root: "tui-snackbar",
  component: "tui-o25-component",
  container: "tui-snackbar-container",
  containerDesktop: "tui-snackbar-container-desktop",
  body: "tui-snackbar__body",
  lead: "tui-snackbar__lead",
  trail: "tui-snackbar__trail",
  content: "tui-snackbar-content",
  fill: "tui-snackbar_fill"
};

export { SnackbarClasses };
//# sourceMappingURL=classes.js.map
