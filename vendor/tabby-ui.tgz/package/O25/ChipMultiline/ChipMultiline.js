import cn from 'classnames';
import React__default, { forwardRef } from 'react';
import { Text } from '../Text/Text.js';
import { ChipMultilineClasses } from './classes.js';
import "./ChipMultiline.css";

const ChipMultiline = forwardRef(
  (props, externalRef) => {
    const {
      className,
      title,
      hintText,
      children,
      size = "sm",
      error,
      ...rest
    } = props;
    const messageText = error || hintText;
    const isError = !!error;
    return /* @__PURE__ */ React__default.createElement(
      "div",
      {
        ref: externalRef,
        className: cn(
          ChipMultilineClasses.component,
          ChipMultilineClasses.root,
          ChipMultilineClasses.size[size],
          className
        ),
        ...rest
      },
      title && /* @__PURE__ */ React__default.createElement(Text, { variant: "body1TightBold", className: ChipMultilineClasses.title }, title),
      /* @__PURE__ */ React__default.createElement("div", { className: ChipMultilineClasses.content }, children),
      messageText && /* @__PURE__ */ React__default.createElement(
        Text,
        {
          variant: "caption",
          className: cn(
            ChipMultilineClasses.hint,
            isError && ChipMultilineClasses.hintError
          )
        },
        messageText
      )
    );
  }
);
ChipMultiline.displayName = "ChipMultiline";

export { ChipMultiline };
//# sourceMappingURL=ChipMultiline.js.map
