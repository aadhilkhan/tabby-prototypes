const ChipMultilineClasses = {
  root: "tui-chip-multiline",
  component: "tui-o25-component",
  size: {
    xs: "tui-chip-multiline_size-xs",
    sm: "tui-chip-multiline_size-sm",
    md: "tui-chip-multiline_size-md"
  },
  title: "tui-chip-multiline__title",
  content: "tui-chip-multiline__content",
  hint: "tui-chip-multiline__hint",
  hintError: "tui-chip-multiline__hint_error"
};

export { ChipMultilineClasses };
//# sourceMappingURL=classes.js.map
