export { ChipMultiline } from './ChipMultiline.js';
export { ChipMultilineClasses } from './classes.js';
//# sourceMappingURL=index.js.map
