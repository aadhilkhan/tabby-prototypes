const SearchBarClasses = {
  component: "tui-o25-component",
  root: "tui-search-bar",
  size: {
    m: "tui-text-field_size-m",
    s: "tui-text-field_size-s"
  },
  level: {
    1: "tui-search-bar_level-1",
    2: "tui-search-bar_level-2",
    3: "tui-search-bar_level-3"
  },
  loadingIcon: "tui-search-bar__loading-icon",
  searchIcon: "tui-search-bar__search-icon"
};

export { SearchBarClasses };
//# sourceMappingURL=classes.js.map
