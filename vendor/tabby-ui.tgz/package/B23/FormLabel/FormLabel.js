import React__default from 'react';
import { FormLabelCommon } from '../../common/FormLabel/FormLabel.js';
import { Styles } from './styles/styles.js';

function FormLabel(props) {
  return /* @__PURE__ */ React__default.createElement(FormLabelCommon, { ...props, sx: Styles(props) });
}

export { FormLabel };
//# sourceMappingURL=FormLabel.js.map
