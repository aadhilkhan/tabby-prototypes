export { FormLabel } from './FormLabel.js';
import 'classnames';
import 'react';
import '@mui/material';
export { TuiFormLabelClasses } from '../../common/FormLabel/styles/classes.js';
//# sourceMappingURL=index.js.map
