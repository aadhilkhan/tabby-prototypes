export { Radio } from './Radio.js';
import 'classnames';
import 'react';
import '@mui/material';
export { TuiRadioClasses } from '../../common/Radio/styles/classes.js';
//# sourceMappingURL=index.js.map
