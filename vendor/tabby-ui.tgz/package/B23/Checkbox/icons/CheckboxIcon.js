import React__default from 'react';

function CheckboxIcon(props) {
  return /* @__PURE__ */ React__default.createElement(
    "svg",
    {
      xmlns: "http://www.w3.org/2000/svg",
      width: "16",
      height: "16",
      fill: "none",
      className: "TuiCheckbox-iconRoot",
      ...props
    },
    /* @__PURE__ */ React__default.createElement(
      "rect",
      {
        width: "15",
        height: "15",
        x: ".5",
        y: ".5",
        className: "TuiCheckbox-base",
        rx: "3.5"
      }
    ),
    /* @__PURE__ */ React__default.createElement(
      "rect",
      {
        width: "15",
        height: "15",
        x: ".5",
        y: ".5",
        className: "TuiCheckbox-border",
        rx: "3.5"
      }
    )
  );
}

export { CheckboxIcon as default };
//# sourceMappingURL=CheckboxIcon.js.map
