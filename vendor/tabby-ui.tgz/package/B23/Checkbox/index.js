export { Checkbox } from './Checkbox.js';
import 'classnames';
import 'react';
import '@mui/material';
export { TuiCheckboxClasses } from '../../common/Checkbox/styles/classes.js';
//# sourceMappingURL=index.js.map
