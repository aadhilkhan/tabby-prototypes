import React__default from 'react';
import { deepmerge } from '@mui/utils';
import { TextField } from '../TextField/TextField.js';
import { DateTimePickerCommon } from '../../common/DateTimePicker/DateTimePicker.js';
import Calendar24 from '../../icons/core/Calendar24.js';
import { injectErrorToEndAdornment } from '../../utils/endAdornment.js';
import { TextFieldStyles, PopperStyles } from './styles/styles.js';

function DatePickerIcon() {
  return /* @__PURE__ */ React__default.createElement(Calendar24, { "data-testid": "CalendarIcon" });
}
function DateTimePickerTextFieldBase(props, ref) {
  const { InputProps, error, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(
    TextField,
    {
      ...rest,
      ref,
      error,
      InputProps: {
        ...InputProps,
        endAdornment: injectErrorToEndAdornment(
          InputProps?.endAdornment,
          error
        )
      },
      hideErrorIcon: true
    }
  );
}
const DateTimePickerTextField = React__default.forwardRef(
  DateTimePickerTextFieldBase
);
function DateTimePicker(props) {
  const {
    slotProps = {},
    slots = {},
    labelInside,
    clearable = false,
    fullWidth = false,
    "data-testid": dataTestId,
    size = "small",
    error,
    ...rest
  } = props;
  const resultSlots = {
    ...slots,
    openPickerIcon: DatePickerIcon,
    textField: slots.textField || DateTimePickerTextField
  };
  const resultSlotProps = deepmerge(slotProps, {
    popper: {
      sx: PopperStyles(props),
      "data-testid": `${dataTestId}-popper`
    },
    textField: {
      fullWidth,
      labelInside,
      size,
      // we use same function to create SxProps
      sx: TextFieldStyles(props),
      error,
      "data-testid": `${dataTestId}-textField`
    },
    field: { clearable }
  });
  return /* @__PURE__ */ React__default.createElement(
    DateTimePickerCommon,
    {
      ...rest,
      slots: resultSlots,
      slotProps: resultSlotProps
    }
  );
}

export { DateTimePicker, DateTimePickerTextField };
//# sourceMappingURL=DateTimePicker.js.map
