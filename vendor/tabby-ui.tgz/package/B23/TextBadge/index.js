export { TextBadge } from './TextBadge.js';
//# sourceMappingURL=index.js.map
