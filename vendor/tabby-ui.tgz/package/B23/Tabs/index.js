export { Tabs } from './Tabs.js';
//# sourceMappingURL=index.js.map
