import cn from 'classnames';
import React__default from 'react';
import { Box } from '@mui/material';
import { IconButton } from '../IconButton/IconButton.js';
import { Text } from '../Text/Text.js';
import { DrawerCommon, BORDER_TYPES } from '../../common/Drawer/Drawer.js';
import { useCalculateBorder } from '../../common/Drawer/hooks/useCalculateBorder.js';
import { TuiDrawerClasses } from '../../common/Drawer/styles/classes.js';
import Close24 from '../../icons/core/Close24.js';
import { Styles } from './styles/styles.js';

const DEFAULT_DRAWER_WIDTH = "440px";
function DefaultHeader(props) {
  const { title, onClose, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(Box, { ...rest, className: TuiDrawerClasses.header }, /* @__PURE__ */ React__default.createElement(Text, { variant: "h3" }, title), /* @__PURE__ */ React__default.createElement(
    IconButton,
    {
      "data-testid": "tui-drawer-close",
      variant: "text",
      onClick: (event) => {
        if (onClose) onClose(event, "backdropClick");
      }
    },
    /* @__PURE__ */ React__default.createElement(Close24, null)
  ));
}
function DefaultBody(props) {
  const { children } = props;
  const { bodyRef, onScroll, borderType, ...rest } = useCalculateBorder();
  return /* @__PURE__ */ React__default.createElement(
    Box,
    {
      ref: bodyRef,
      onScroll,
      ...rest,
      className: cn(TuiDrawerClasses.body, {
        [TuiDrawerClasses.bodyNoScroll]: borderType === BORDER_TYPES.noscroll,
        [TuiDrawerClasses.bodyBorderTop]: borderType === BORDER_TYPES.top,
        [TuiDrawerClasses.bodyBorderBottom]: borderType === BORDER_TYPES.bottom
      })
    },
    children
  );
}
function Drawer(props) {
  const {
    title = "",
    header,
    children,
    body,
    footer,
    width = DEFAULT_DRAWER_WIDTH,
    onClose,
    ...rest
  } = props;
  return /* @__PURE__ */ React__default.createElement(
    DrawerCommon,
    {
      ...rest,
      header: header || /* @__PURE__ */ React__default.createElement(DefaultHeader, { title, onClose }),
      body: body || /* @__PURE__ */ React__default.createElement(DefaultBody, null, children),
      footer: footer && /* @__PURE__ */ React__default.createElement(Box, { className: TuiDrawerClasses.footer }, footer),
      width,
      onClose,
      className: TuiDrawerClasses.root,
      sx: Styles(props)
    },
    children
  );
}

export { Drawer };
//# sourceMappingURL=Drawer.js.map
