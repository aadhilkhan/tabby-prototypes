export { Drawer } from './Drawer.js';
import 'classnames';
import 'react';
import '@mui/material';
export { TuiDrawerClasses } from '../../common/Drawer/styles/classes.js';
//# sourceMappingURL=index.js.map
