export { MenuItem } from './MenuItem.js';
export { TuiMenuItemClasses } from '../../common/MenuItem/styles/classes.js';
//# sourceMappingURL=index.js.map
