import React__default from 'react';
import { FormHelperTextCommon } from '../../common/FormHelperText/FormHelperText.js';
import { Styles } from './styles/styles.js';

function FormHelperText(props) {
  return /* @__PURE__ */ React__default.createElement(FormHelperTextCommon, { ...props, sx: Styles(props) });
}

export { FormHelperText };
//# sourceMappingURL=FormHelperText.js.map
