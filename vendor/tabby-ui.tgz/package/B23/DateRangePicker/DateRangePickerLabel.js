import React__default from 'react';
import { Box } from '@mui/material';
import { FormLabel } from '../FormLabel/FormLabel.js';
import 'classnames';
import '@mui/x-date-pickers-pro/AdapterDateFns';
import '@mui/x-date-pickers-pro/DesktopDateRangePicker';
import '@mui/x-date-pickers-pro/LocalizationProvider';
import '../../core/HijriAdapter/HijriAdapter.js';
import { TuiDateRangePickerLabelClasses } from '../../common/DateRangePicker/styles/classes.js';
import { DateRangePickerLabelStyles } from './styles/styles.js';

function DateRangePickerLabel(props) {
  const { labels, ...rest } = props;
  if (!labels) return null;
  return /* @__PURE__ */ React__default.createElement(
    Box,
    {
      ...rest,
      sx: DateRangePickerLabelStyles(),
      className: TuiDateRangePickerLabelClasses.root
    },
    /* @__PURE__ */ React__default.createElement(Box, { className: TuiDateRangePickerLabelClasses.label }, /* @__PURE__ */ React__default.createElement(FormLabel, { variant: "TextField" }, labels[0])),
    labels[1] && /* @__PURE__ */ React__default.createElement(React__default.Fragment, null, /* @__PURE__ */ React__default.createElement(Box, { className: TuiDateRangePickerLabelClasses.divider }), /* @__PURE__ */ React__default.createElement(Box, { className: TuiDateRangePickerLabelClasses.label }, /* @__PURE__ */ React__default.createElement(FormLabel, { variant: "TextField" }, labels[1])))
  );
}

export { DateRangePickerLabel };
//# sourceMappingURL=DateRangePickerLabel.js.map
