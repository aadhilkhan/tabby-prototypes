import React__default from 'react';
import { deepmerge } from '@mui/utils';
import { SingleInputDateRangeField } from '@mui/x-date-pickers-pro/SingleInputDateRangeField';
import { DateRangePickerLabel } from './DateRangePickerLabel.js';
import { TextField } from '../TextField/TextField.js';
import { DateRangePickerCommon } from '../../common/DateRangePicker/DateRangePicker.js';
import Calendar24 from '../../icons/core/Calendar24.js';
import { paletteB23 } from '../../theme/palette/paletteB23.js';
import { injectErrorToEndAdornment } from '../../utils/endAdornment.js';
import { PopperStyles } from './styles/styles.js';

function DatePickerIcon(props) {
  const { disabled } = props;
  return /* @__PURE__ */ React__default.createElement(
    Calendar24,
    {
      color: disabled ? paletteB23.front.disabled : paletteB23.front.minor
    }
  );
}
function DateRangePickerTextFieldBase(props, ref) {
  const { InputProps, error, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(
    TextField,
    {
      ...rest,
      ref,
      error,
      InputProps: {
        ...InputProps,
        endAdornment: injectErrorToEndAdornment(
          InputProps?.endAdornment,
          error
        )
      },
      hideErrorIcon: true
    }
  );
}
const DateRangePickerTextField = React__default.forwardRef(
  DateRangePickerTextFieldBase
);
function DateRangePicker(props) {
  const {
    slotProps = {},
    slots = {},
    labels,
    "data-testid": dataTestId,
    size = "small",
    inputVariant = "multi",
    error,
    ...rest
  } = props;
  const resultSlots = {
    ...slots,
    textField: slots.textField || DateRangePickerTextField
  };
  if (inputVariant === "single") {
    resultSlots.field = SingleInputDateRangeField;
  }
  const resultSlotProps = deepmerge(slotProps, {
    popper: {
      sx: PopperStyles(props),
      "data-testid": `${dataTestId}-popper`
    },
    textField: {
      fullWidth: true,
      size,
      error,
      InputProps: {
        endAdornment: /* @__PURE__ */ React__default.createElement(DatePickerIcon, { disabled: props.disabled })
      },
      "data-testid": `${dataTestId}-textField`,
      ...slotProps.textField || {}
    }
  });
  return /* @__PURE__ */ React__default.createElement(
    DateRangePickerCommon,
    {
      ...rest,
      labels: /* @__PURE__ */ React__default.createElement(DateRangePickerLabel, { labels }),
      slots: resultSlots,
      slotProps: resultSlotProps
    }
  );
}

export { DateRangePicker, DateRangePickerTextField };
//# sourceMappingURL=DateRangePicker.js.map
