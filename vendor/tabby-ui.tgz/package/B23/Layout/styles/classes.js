const TuiLayoutClasses = {
  layoutRoot: "TuiLayout-root",
  headerRoot: "TuiLayoutHeader-root",
  footerRoot: "TuiLayoutFooter-root",
  contentRoot: "TuiLayoutContent-root",
  itemRoot: "TuiLayoutItem-Root"
};

export { TuiLayoutClasses };
//# sourceMappingURL=classes.js.map
