export { Text, useTypographyStyle } from './Text.js';
//# sourceMappingURL=index.js.map
