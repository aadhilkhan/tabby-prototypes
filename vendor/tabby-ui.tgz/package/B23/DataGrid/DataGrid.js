import cn from 'classnames';
import React__default from 'react';
import { DataGrid as DataGrid$1 } from '@mui/x-data-grid';
import { Checkbox } from '../Checkbox/Checkbox.js';
import '@mui/material';
import { Styles } from './styles/styles.js';

function BaseGridCheckbox(props, ref) {
  return /* @__PURE__ */ React__default.createElement(Checkbox, { ...props, ref });
}
const GridCheckbox = React__default.forwardRef(BaseGridCheckbox);
function DataGrid(props) {
  const { slots = {}, className, ...rest } = props;
  if (!slots.baseCheckbox) slots.baseCheckbox = GridCheckbox;
  return /* @__PURE__ */ React__default.createElement(
    DataGrid$1,
    {
      ...rest,
      sx: Styles(props),
      slots,
      className: cn("Tui-Component", "Tui-DataGrid", className)
    }
  );
}

export { DataGrid, GridCheckbox };
//# sourceMappingURL=DataGrid.js.map
