export { OutlinedInput } from './OutlinedInput.js';
import '../../common/OutlinedInput/OutlinedInput.js';
export { TuiOutlineInputClasses, TuiTwoLinedInputClasses } from '../../common/OutlinedInput/styles/classes.js';
//# sourceMappingURL=index.js.map
