const TuiUniversalHeaderClasses = {
  root: "TuiUniversalHeader-root",
  leftSection: "TuiUniversalHeader-leftSection",
  middleSection: "TuiUniversalHeader-middleSection",
  rightSection: "TuiUniversalHeader-rightSection",
  avatar: "TuiUniversalHeader-avatar"
};
const TuiUniversalMenuClasses = {
  menuButton: "TuiUniversalMenu-menuButton",
  menuContainer: "TuiUniversalMenu-menuContainer",
  menuGrid: "TuiUniversalMenu-menuGrid",
  menuItem: "TuiUniversalMenu-menuItem"
};
const TuiMenuIconClasses = {
  container: "TuiMenuIcon-container",
  cornerDot: "TuiMenuIcon-cornerDot",
  extraDot: "TuiMenuIcon-extraDot"
};

export { TuiMenuIconClasses, TuiUniversalHeaderClasses, TuiUniversalMenuClasses };
//# sourceMappingURL=classes.js.map
