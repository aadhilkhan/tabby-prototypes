export { UniversalHeader } from './UniversalHeader.js';
export { UniversalMenu } from './UniversalMenu.js';
export { MenuIcon } from './MenuIcon.js';
export { TuiMenuIconClasses, TuiUniversalHeaderClasses, TuiUniversalMenuClasses } from './styles/classes.js';
//# sourceMappingURL=index.js.map
