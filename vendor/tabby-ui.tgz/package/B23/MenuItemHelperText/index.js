export { MenuItemHelperText } from './MenuItemHelperText.js';
import '../../common/MenuItemHelperText/MenuItemHelperText.js';
export { TuiMenuItemHelperTextClasses } from '../../common/MenuItemHelperText/styles/classes.js';
//# sourceMappingURL=index.js.map
