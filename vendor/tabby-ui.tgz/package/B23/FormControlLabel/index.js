export { FormControlLabel } from './FormControlLabel.js';
import 'classnames';
import 'react';
import '@mui/material';
export { TuiFormControlLabelClasses } from '../../common/FormControlLabel/styles/classes.js';
//# sourceMappingURL=index.js.map
