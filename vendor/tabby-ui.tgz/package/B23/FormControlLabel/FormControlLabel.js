import React__default from 'react';
import { FormControlLabelCommon } from '../../common/FormControlLabel/FormControlLabel.js';
import { Styles } from './styles/styles.js';

function FormControlLabel(props) {
  return /* @__PURE__ */ React__default.createElement(FormControlLabelCommon, { ...props, sx: Styles(props) });
}

export { FormControlLabel };
//# sourceMappingURL=FormControlLabel.js.map
