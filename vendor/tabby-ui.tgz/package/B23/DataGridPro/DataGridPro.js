import cn from 'classnames';
import React__default from 'react';
import { DataGridPro as DataGridPro$1 } from '@mui/x-data-grid-pro';
import { Checkbox } from '../Checkbox/Checkbox.js';
import '@mui/material';
import { Styles } from './styles/styles.js';

function BaseGridCheckbox(props, ref) {
  return /* @__PURE__ */ React__default.createElement(Checkbox, { ...props, ref });
}
const GridCheckbox = React__default.forwardRef(BaseGridCheckbox);
function DataGridPro(props) {
  const { slots = {}, className, ...rest } = props;
  if (!slots.baseCheckbox) slots.baseCheckbox = GridCheckbox;
  return /* @__PURE__ */ React__default.createElement(
    DataGridPro$1,
    {
      ...rest,
      sx: Styles(props),
      slots,
      className: cn("Tui-Component", "Tui-DataGridPro", className)
    }
  );
}

export { DataGridPro, GridCheckbox };
//# sourceMappingURL=DataGridPro.js.map
