export { DataGridPro } from './DataGridPro.js';
//# sourceMappingURL=index.js.map
