import React__default from 'react';
import cn from 'classnames';
import { ButtonCommon } from '../../common/Button/Button.js';
import { Styles } from './styles/styles.js';

function capitalizeFirstLetter(val) {
  return String(val).charAt(0).toUpperCase() + String(val).slice(1);
}
function Button(props) {
  const {
    color = "neutral",
    size = "medium",
    variant = "contained",
    className,
    ...rest
  } = props;
  return /* @__PURE__ */ React__default.createElement(
    ButtonCommon,
    {
      size,
      variant,
      ...rest,
      className: cn(
        `TuiButton-color${capitalizeFirstLetter(color)}`,
        className
      ),
      sx: Styles(props)
    }
  );
}

export { Button };
//# sourceMappingURL=Button.js.map
