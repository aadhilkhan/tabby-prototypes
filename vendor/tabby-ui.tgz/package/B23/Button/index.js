export { Button } from './Button.js';
import 'classnames';
import 'react';
import '@mui/material';
import '../../common/Loader/Loader.js';
import '@mui/utils';
import '../../theme/palette/paletteB23.js';
export { TuiButtonClasses } from '../../common/Button/styles/classes.js';
//# sourceMappingURL=index.js.map
