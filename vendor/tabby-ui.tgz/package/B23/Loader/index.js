export { Loader } from './Loader.js';
import '../../common/Loader/Loader.js';
export { TuiLoaderClasses } from '../../common/Loader/styles/classes.js';
//# sourceMappingURL=index.js.map
