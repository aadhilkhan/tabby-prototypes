import * as React from 'react';
import { DropdownCommon } from '../../common/Dropdown/Dropdown.js';
import { Menu } from '../Menu/Menu.js';
import { MenuItem } from '../MenuItem/MenuItem.js';

function Dropdown(props) {
  return /* @__PURE__ */ React.createElement(
    DropdownCommon,
    {
      ...props,
      MenuComponent: Menu,
      MenuItemComponent: MenuItem
    }
  );
}

export { Dropdown };
//# sourceMappingURL=Dropdown.js.map
