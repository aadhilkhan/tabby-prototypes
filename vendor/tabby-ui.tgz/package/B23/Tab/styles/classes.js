const TuiTabClasses = {
  sizeSmall: "TuiTab-sizeSmall",
  sizeMedium: "TuiTab-sizeMedium",
  sticky: "TuiTab-sticky",
  discrete: "TuiTab-discrete"
};

export { TuiTabClasses };
//# sourceMappingURL=classes.js.map
