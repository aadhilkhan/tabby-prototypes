export { Tab } from './Tab.js';
export { TuiTabClasses } from './styles/classes.js';
//# sourceMappingURL=index.js.map
