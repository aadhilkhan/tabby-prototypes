import React__default from 'react';
import { IconButton } from '../IconButton/IconButton.js';
import { AlertCommon } from '../../common/Alert/AlertCommon.js';
import { TuiAlertClasses } from '../../common/Alert/styles/classes.js';
import Close16 from '../../icons/core/Close16.js';
import { Styles } from './styles/styles.js';

const colorMap = {
  success: "positive",
  info: "highlight",
  error: "negative",
  dark: "inverted",
  warning: "warning"
};
function Alert(props) {
  const { onClose, severity = "info", variant = "outlined", ...rest } = props;
  const iconButton = /* @__PURE__ */ React__default.createElement(
    IconButton,
    {
      onClick: onClose,
      variant: "text",
      className: TuiAlertClasses.closeButton,
      size: "medium",
      color: variant === "filled" ? colorMap[severity] : "neutral"
    },
    /* @__PURE__ */ React__default.createElement(Close16, null)
  );
  return /* @__PURE__ */ React__default.createElement(
    AlertCommon,
    {
      iconButton,
      onClose,
      variant,
      severity,
      ...rest,
      sx: Styles(props)
    }
  );
}

export { Alert };
//# sourceMappingURL=Alert.js.map
