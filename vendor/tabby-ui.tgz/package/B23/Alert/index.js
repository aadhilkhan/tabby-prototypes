export { Alert } from './Alert.js';
import 'classnames';
import 'react';
import '@mui/material';
import '@mui/system';
import '../../theme/palette/paletteB23.js';
export { TuiAlertClasses } from '../../common/Alert/styles/classes.js';
//# sourceMappingURL=index.js.map
