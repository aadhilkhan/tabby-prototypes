import React__default from 'react';
import { deepmerge } from '@mui/utils';
import { TextField } from '../TextField/TextField.js';
import { DatePickerCommon } from '../../common/DatePicker/DatePicker.js';
import Calendar24 from '../../icons/core/Calendar24.js';
import { injectErrorToEndAdornment } from '../../utils/endAdornment.js';
import { TextFieldStyles, PopperStyles } from './styles/styles.js';

function DatePickerIcon() {
  return /* @__PURE__ */ React__default.createElement(Calendar24, { "data-testid": "CalendarIcon" });
}
function DatePickerTextFieldBase(props, ref) {
  const { InputProps, error, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(
    TextField,
    {
      ...rest,
      ref,
      error,
      InputProps: {
        ...InputProps,
        endAdornment: injectErrorToEndAdornment(
          InputProps?.endAdornment,
          error
        )
      },
      hideErrorIcon: true
    }
  );
}
const DatePickerTextField = React__default.forwardRef(DatePickerTextFieldBase);
function DatePicker(props) {
  const {
    slotProps = {},
    slots = {},
    labelInside,
    clearable = false,
    fullWidth = false,
    "data-testid": dataTestId,
    size = "small",
    error,
    ...rest
  } = props;
  const resultSlots = {
    ...slots,
    openPickerIcon: DatePickerIcon,
    textField: slots.textField || DatePickerTextField
  };
  const resultSlotProps = deepmerge(slotProps, {
    popper: {
      sx: PopperStyles(props),
      "data-testid": `${dataTestId}-popper`
    },
    textField: {
      fullWidth,
      labelInside,
      size,
      sx: TextFieldStyles(props),
      error,
      "data-testid": `${dataTestId}-textField`
    },
    field: { clearable }
  });
  return /* @__PURE__ */ React__default.createElement(
    DatePickerCommon,
    {
      ...rest,
      slots: resultSlots,
      slotProps: resultSlotProps
    }
  );
}

export { DatePicker, DatePickerTextField };
//# sourceMappingURL=DatePicker.js.map
