const TuiMultiSelectWithSearchClasses = {
  root: "TuiMultiSelectWithSearch-root",
  input: "TuiMultiSelectWithSearch-input",
  popper: "TuiMultiSelectWithSearch-popper",
  overlay: "TuiMultiSelectWithSearch-overlay",
  overlaySizeSmall: "TuiMultiSelectWithSearch-overlaySizeSmall",
  overlaySizeMedium: "TuiMultiSelectWithSearch-overlaySizeMedium",
  overlaySizeExtraSmall: "TuiMultiSelectWithSearch-overlaySizeExtraSmall",
  rootSizeExtraSmall: "TuiMultiSelectWithSearch-rootSizeExtraSmall",
  wrapperIcon: "TuiMultiSelectWithSearch-wrapperIcon",
  wrapperIconOpened: "TuiMultiSelectWithSearch-wrapperIconOpened",
  autocompletePopper: "TuiMultiSelectWithSearch-autocompletePopper",
  outsideChipsContainer: "TuiMultiSelectWithSearch-outsideChipsContainer",
  disabled: "TuiDisabled",
  fakeLabelInside: "TuiMultiSelectWithSearch-fakeLabelInside"
};
const TuiSelectClasses = {
  root: "TuiSelect-root"
};
const TuiOutsideChipsClasses = {
  root: "TuiOutsideChips-root"
};
const TuiSelectContentClasses = {
  disabled: "TuiDisabled",
  root: "TuiSelectContent-root",
  singleValue: "TuiSelectContent-singleValue",
  multiple: "TuiSelectContent-multiple",
  placeholder: "TuiSelectContent-placeholder",
  content: "TuiSelectContent-content",
  clearIcon: "TuiSelectContent-clearIcon",
  multiContent: "TuiSelectContent-multiContent",
  item: "TuiSelectContent-item",
  itemHidden: "TuiSelectContent-itemHidden",
  itemVisible: "TuiSelectContent-itemVisible",
  itemLastVisible: "TuiSelectContent-itemLastVisible",
  moreOptions: "TuiSelectContent-moreOptions",
  counter: "TuiSelectContent-counter",
  chevron: "TuiSelectContent-chevron",
  chevronOpened: "TuiSelectContent-chevronOpened",
  errorIcon: "TuiSelectContent-errorIcon"
};

export { TuiMultiSelectWithSearchClasses, TuiOutsideChipsClasses, TuiSelectClasses, TuiSelectContentClasses };
//# sourceMappingURL=classes.js.map
