import { TuiSelectContentClasses } from '../styles/classes.js';

const MORE_OPTIONS_RIGHT_PADDING = 8;
const getHiddenCount = (containerWidth, moreOptionsWidth, itemsElements) => {
  const totalWidth = itemsElements.reduce((width, item) => {
    const itemWidth = item.clientWidth;
    return width + itemWidth;
  }, 0);
  const availableWidth = totalWidth > containerWidth ? containerWidth - moreOptionsWidth - MORE_OPTIONS_RIGHT_PADDING : containerWidth;
  return itemsElements.reduce(
    (props, item, currentIndex) => {
      const { width, hiddenCount, hideCounter } = props;
      const itemWidth = item.clientWidth;
      const newWidth = width + itemWidth;
      if (newWidth > availableWidth) {
        item.style.order = String(1e3 + currentIndex);
        item.classList.add(TuiSelectContentClasses.itemHidden);
        item.classList.remove(TuiSelectContentClasses.itemVisible);
        item.classList.remove(TuiSelectContentClasses.itemLastVisible);
        return {
          width: newWidth,
          hiddenCount: hiddenCount + 1,
          hideCounter: currentIndex === 0 ? true : hideCounter
        };
      }
      item.style.order = String(currentIndex);
      item.classList.add(TuiSelectContentClasses.itemVisible);
      item.classList.add(TuiSelectContentClasses.itemLastVisible);
      if (itemsElements[currentIndex - 1]) {
        itemsElements[currentIndex - 1].classList.remove(
          TuiSelectContentClasses.itemLastVisible
        );
      }
      item.classList.remove(TuiSelectContentClasses.itemHidden);
      return {
        width: newWidth,
        hiddenCount: 0,
        hideCounter
      };
    },
    {
      width: 0,
      hiddenCount: 0,
      hideCounter: false
    }
  );
};

export { getHiddenCount };
//# sourceMappingURL=getHiddenCount.js.map
