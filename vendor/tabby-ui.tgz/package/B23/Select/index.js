export { Select } from './Select.js';
export { MultiSelectWithSearch } from './MultiSelectWithSearch.js';
export { TuiMultiSelectWithSearchClasses, TuiOutsideChipsClasses, TuiSelectClasses, TuiSelectContentClasses } from './styles/classes.js';
//# sourceMappingURL=index.js.map
