import cn from 'classnames';
import React__default from 'react';
import { Chip as Chip$1 } from '@mui/material';
import Close16 from '../../icons/core/Close16.js';
import { paletteB23 } from '../../theme/palette/paletteB23.js';
import { Styles } from './styles/styles.js';

function Chip(props) {
  const { variant, className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(
    Chip$1,
    {
      variant,
      deleteIcon: /* @__PURE__ */ React__default.createElement("span", null, /* @__PURE__ */ React__default.createElement(Close16, { color: paletteB23.front.major })),
      ...rest,
      className: cn("Tui-Component", "Tui-Chip", className),
      sx: Styles(props)
    }
  );
}

export { Chip };
//# sourceMappingURL=Chip.js.map
