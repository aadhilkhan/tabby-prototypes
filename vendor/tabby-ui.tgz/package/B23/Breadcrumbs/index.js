export { Breadcrumbs } from './Breadcrumbs.js';
import 'classnames';
import 'react';
import 'react-router-dom';
import '@mui/material';
import '@mui/utils';
import '../Menu/Menu.js';
import '../Checkbox/Checkbox.js';
import '../../common/MenuItemHelperText/MenuItemHelperText.js';
import '../../theme/palette/paletteB23.js';
export { TuiBreadcrumbsClasses } from '../../common/Breadcrumbs/styles/classes.js';
//# sourceMappingURL=index.js.map
