import React__default from 'react';
import { BreadcrumbsCommon } from '../../common/Breadcrumbs/Breadcrumbs.js';
import { Styles } from './styles/styles.js';

function Breadcrumbs(props) {
  return /* @__PURE__ */ React__default.createElement(BreadcrumbsCommon, { ...props, sx: Styles(props) });
}

export { Breadcrumbs };
//# sourceMappingURL=Breadcrumbs.js.map
