import React__default from 'react';
import { Box } from '@mui/material';
import { Logo } from '../../Logo/Logo.js';
import 'classnames';
import "../../../hooks/useNoRootScroll/useNoRootScrollStyles.css";
import { useSideMenuContext } from '../../../common/SideMenu/context.js';
import { TuiSideMenuHeaderClasses } from '../../../common/SideMenu/styles/classes.js';
import '@mui/material/Paper';
import DoubleChevronBack24 from '../../../icons/core/DoubleChevronBack24.js';
import { paletteB23 } from '../../../theme/palette/paletteB23.js';

function Header(props) {
  const { logo, ...rest } = props;
  const { isCollapsed, setIsCollapsed, setIsToggledByUser } = useSideMenuContext();
  const onClick = () => {
    setIsToggledByUser(true);
    setIsCollapsed(!isCollapsed);
  };
  return /* @__PURE__ */ React__default.createElement(Box, { ...rest, className: TuiSideMenuHeaderClasses.root }, logo || /* @__PURE__ */ React__default.createElement(Logo, { isCollapsed }), /* @__PURE__ */ React__default.createElement(
    Box,
    {
      onClick,
      className: TuiSideMenuHeaderClasses.collapseButton,
      "data-testid": "TuiSideMenu-collapseButton"
    },
    /* @__PURE__ */ React__default.createElement(DoubleChevronBack24, { color: paletteB23.front.minor, dir: "ltr" })
  ));
}

export { Header };
//# sourceMappingURL=Header.js.map
