const TuiModalClasses = {
  root: "TuiModal-root",
  inline: "TuiModal-inline",
  inner: "TuiModal-inner",
  closeButton: "TuiModal-closeButton",
  hero: "TuiModal-hero",
  header: "TuiModal-header",
  content: "TuiModal-content",
  contentInner: "TuiModal-content-inner",
  contentNoScroll: "TuiModal-content-no-scroll",
  contentBorderTop: "TuiModal-content-border-top",
  contentBorderBottom: "TuiModal-content-border-bottom",
  footer: "TuiModal-footer",
  backdrop: "TuiModal-backdrop",
  backdropInline: "TuiModal-backdrop-inline"
};

export { TuiModalClasses };
//# sourceMappingURL=classes.js.map
