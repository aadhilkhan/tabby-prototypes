export { Modal } from './Modal.js';
export { TuiModalClasses } from './styles/classes.js';
//# sourceMappingURL=index.js.map
