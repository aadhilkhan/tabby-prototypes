import React__default from 'react';
import { Button } from '../Button/Button.js';
import 'classnames';
import '@mui/material';
import '../../common/Loader/Loader.js';
import '@mui/utils';
import '../../theme/palette/paletteB23.js';
import { Styles } from './styles/styles.js';

function IconButton(props) {
  const { children, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(Button, { ...rest, sx: Styles(props) }, children);
}

export { IconButton };
//# sourceMappingURL=IconButton.js.map
