import cn from 'classnames';
import React__default from 'react';
import { Autocomplete as Autocomplete$1 } from '@mui/material';
import { MenuItem } from '../MenuItem/MenuItem.js';
import { TextField } from '../TextField/TextField.js';
import ChevronDown24 from '../../icons/core/ChevronDown24.js';
import { paletteB23 } from '../../theme/palette/paletteB23.js';
import { injectErrorToEndAdornment } from '../../utils/endAdornment.js';
import { Styles } from './styles/styles.js';

function Autocomplete(props) {
  const {
    labelInside,
    error,
    required,
    placeholder,
    helperText,
    className,
    size = "small",
    options,
    freeSolo,
    value,
    sx: sxProp,
    ...rest
  } = props;
  return /* @__PURE__ */ React__default.createElement(
    Autocomplete$1,
    {
      value,
      renderInput: (params) => /* @__PURE__ */ React__default.createElement(
        TextField,
        {
          ...params,
          value,
          labelInside,
          placeholder,
          helperText,
          error,
          size,
          required,
          hideErrorIcon: true,
          InputProps: {
            ...params.InputProps,
            endAdornment: injectErrorToEndAdornment(
              params.InputProps.endAdornment,
              error
            )
          }
        }
      ),
      options,
      freeSolo,
      size,
      disablePortal: true,
      popupIcon: /* @__PURE__ */ React__default.createElement(
        ChevronDown24,
        {
          color: props.disabled ? paletteB23.front.disabled : paletteB23.front.minor
        }
      ),
      renderOption: (params, option, _, ownerState) => /* @__PURE__ */ React__default.createElement(MenuItem, { ...params, label: ownerState.getOptionLabel(option) }),
      ...rest,
      className: cn("Tui-Component", "Tui-Autocomplete", className),
      sx: Styles({
        sx: sxProp,
        freeSolo,
        noOptions: options.length === 0
      })
    }
  );
}

export { Autocomplete };
//# sourceMappingURL=Autocomplete.js.map
