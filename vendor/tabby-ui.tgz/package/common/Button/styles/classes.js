const TuiButtonClasses = {
  colorNeutral: "TuiButton-colorNeutral",
  colorNegative: "TuiButton-colorNegative",
  colorWarning: "TuiButton-colorWarning",
  colorPositive: "TuiButton-colorPositive",
  colorHighlight: "TuiButton-colorHighlight",
  colorInverted: "TuiButton-colorInverted",
  containedLight: "MuiButton-containedLight",
  sizeExtraSmall: "MuiButton-sizeExtraSmall"
};

export { TuiButtonClasses };
//# sourceMappingURL=classes.js.map
