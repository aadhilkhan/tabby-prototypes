import cn from 'classnames';
import React__default from 'react';
import { Button, Box } from '@mui/material';
import { Loader } from '../../B23/Loader/Loader.js';
import '../Loader/Loader.js';

function ButtonCommon(props) {
  const {
    children,
    isLoading,
    disabled,
    startIcon,
    endIcon,
    className,
    ...rest
  } = props;
  return /* @__PURE__ */ React__default.createElement(
    Button,
    {
      disabled: isLoading || disabled,
      startIcon: !isLoading && startIcon,
      endIcon: !isLoading && endIcon,
      ...rest,
      className: cn("Tui-Component", "Tui-Button", className)
    },
    isLoading && // eslint-disable-next-line local-rules/no-box-style-props
    /* @__PURE__ */ React__default.createElement(Box, { position: "absolute" }, /* @__PURE__ */ React__default.createElement(Loader, { type: "3dots" })),
    /* @__PURE__ */ React__default.createElement(Box, { visibility: isLoading ? "hidden" : "visible" }, children)
  );
}

export { ButtonCommon };
//# sourceMappingURL=Button.js.map
