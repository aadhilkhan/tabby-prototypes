const TuiLogoClasses = {
  root: "TuiLogo-root"
};

export { TuiLogoClasses };
//# sourceMappingURL=classes.js.map
