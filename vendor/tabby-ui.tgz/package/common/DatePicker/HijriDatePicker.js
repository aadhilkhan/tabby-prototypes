import cn from 'classnames';
import React__default from 'react';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { DesktopDatePicker } from '@mui/x-date-pickers/DesktopDatePicker';
import { HijriAdapter } from '../../core/HijriAdapter/HijriAdapter.js';

function HijriDatePicker(props) {
  const { className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(LocalizationProvider, { dateAdapter: HijriAdapter }, /* @__PURE__ */ React__default.createElement(
    DesktopDatePicker,
    {
      ...rest,
      className: cn("Tui-Component", "Tui-DatePicker", className)
    }
  ));
}

export { HijriDatePicker as default };
//# sourceMappingURL=HijriDatePicker.js.map
