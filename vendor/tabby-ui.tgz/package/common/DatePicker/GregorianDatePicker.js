import cn from 'classnames';
import React__default from 'react';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DesktopDatePicker } from '@mui/x-date-pickers/DesktopDatePicker';

function GregorianDatePicker(props) {
  const { className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(LocalizationProvider, { dateAdapter: AdapterDateFns }, /* @__PURE__ */ React__default.createElement(
    DesktopDatePicker,
    {
      ...rest,
      className: cn("Tui-Component", "Tui-DatePicker", className)
    }
  ));
}

export { GregorianDatePicker as default };
//# sourceMappingURL=GregorianDatePicker.js.map
