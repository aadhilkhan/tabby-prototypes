import React__default from 'react';
import GregorianDatePicker from './GregorianDatePicker.js';
import HijriDatePicker from './HijriDatePicker.js';

function DatePickerCommon(props) {
  const { isHijri, ...rest } = props;
  if (isHijri) {
    return /* @__PURE__ */ React__default.createElement(HijriDatePicker, { ...rest });
  }
  return /* @__PURE__ */ React__default.createElement(GregorianDatePicker, { ...rest });
}

export { DatePickerCommon };
//# sourceMappingURL=DatePicker.js.map
