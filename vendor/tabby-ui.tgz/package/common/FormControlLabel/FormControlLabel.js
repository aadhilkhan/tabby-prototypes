import cn from 'classnames';
import React__default from 'react';
import { FormControlLabel } from '@mui/material';
import { TuiFormControlLabelClasses } from './styles/classes.js';

function FormControlLabelCommon(props) {
  const { helperText, label, variant, className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(
    FormControlLabel,
    {
      ...rest,
      label: /* @__PURE__ */ React__default.createElement("div", { className: TuiFormControlLabelClasses.label }, /* @__PURE__ */ React__default.createElement("div", { className: TuiFormControlLabelClasses.mainText }, label), helperText && /* @__PURE__ */ React__default.createElement("div", { className: TuiFormControlLabelClasses.helperText }, helperText)),
      className: cn(
        "Tui-Component",
        "Tui-FormControlLabel",
        TuiFormControlLabelClasses.root,
        `TuiFormControlLabel-for${variant}`,
        className
      )
    }
  );
}

export { FormControlLabelCommon };
//# sourceMappingURL=FormControlLabel.js.map
