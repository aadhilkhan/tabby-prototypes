const TuiFormControlLabelClasses = {
  label: "TuiFormControlLabel-label",
  root: "TuiFormControlLabel-root",
  mainText: "TuiFormControlLabel-mainText",
  helperText: "TuiFormControlLabel-helperText",
  forSwitch: "TuiFormControlLabel-forSwitch",
  forRadio: "TuiFormControlLabel-forRadio",
  forCheckbox: "TuiFormControlLabel-forCheckbox"
};

export { TuiFormControlLabelClasses };
//# sourceMappingURL=classes.js.map
