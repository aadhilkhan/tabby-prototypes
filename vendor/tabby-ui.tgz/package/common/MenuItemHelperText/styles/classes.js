const TuiMenuItemHelperTextClasses = {
  root: "TuiMenuItemHelperText-root",
  topPosition: "TuiMenuItemHelperText-topPosition",
  bottomPosition: "TuiMenuItemHelperText-bottomPosition"
};

export { TuiMenuItemHelperTextClasses };
//# sourceMappingURL=classes.js.map
