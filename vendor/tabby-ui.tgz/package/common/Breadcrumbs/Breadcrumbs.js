import cn from 'classnames';
import React__default from 'react';
import { Link } from 'react-router-dom';
import { Breadcrumbs } from '@mui/material';
import { Dropdown } from '../../B23/Dropdown/Dropdown.js';
import ChevronForward24 from '../../icons/core/ChevronForward24.js';
import More24 from '../../icons/core/More24.js';
import { paletteB23 } from '../../theme/palette/paletteB23.js';
import { TuiBreadcrumbsClasses } from './styles/classes.js';

const cropCrumbs = (crumbs, maxItems) => {
  if (maxItems === 0) return [crumbs, []];
  if (crumbs.length < maxItems + 1) return [crumbs, []];
  return [
    [
      ...crumbs.slice(0, maxItems - 1),
      { label: "..." },
      crumbs[crumbs.length - 1]
    ],
    crumbs.slice(maxItems - 1, crumbs.length - 1)
  ];
};
function BreadcrumbCommon(props) {
  const { label, href, isLast, isFirst, hiddenCrumbs } = props;
  if (label === "...") {
    const menuItems = hiddenCrumbs.map((crumb) => {
      return { label: crumb.label, href: crumb.href };
    });
    return /* @__PURE__ */ React__default.createElement(Dropdown, { menuItems }, /* @__PURE__ */ React__default.createElement(
      "div",
      {
        className: cn(
          TuiBreadcrumbsClasses.label,
          TuiBreadcrumbsClasses.ellipsis,
          isFirst && TuiBreadcrumbsClasses.firstLabel
        )
      },
      /* @__PURE__ */ React__default.createElement(
        More24,
        {
          color: paletteB23.front.minor,
          "data-testid": "BreadcrumbDropdownTrigger"
        }
      )
    ));
  }
  return href && !isLast ? /* @__PURE__ */ React__default.createElement(
    Link,
    {
      to: href,
      className: cn(TuiBreadcrumbsClasses.label, isFirst && TuiBreadcrumbsClasses.firstLabel)
    },
    label
  ) : /* @__PURE__ */ React__default.createElement(
    "span",
    {
      className: cn(TuiBreadcrumbsClasses.label, isFirst && TuiBreadcrumbsClasses.firstLabel)
    },
    label
  );
}
function BreadcrumbsCommon(props) {
  const { crumbs, maxItems = 0, className, ...rest } = props;
  const [visibleCrumbs, hiddenCrumbs] = cropCrumbs(crumbs, maxItems);
  return /* @__PURE__ */ React__default.createElement(
    Breadcrumbs,
    {
      ...rest,
      className: cn("Tui-Component", "Tui-Breadcrumbs", className)
    },
    visibleCrumbs.map((crumb, index) => {
      const isLast = visibleCrumbs.length - 1 === index;
      return /* @__PURE__ */ React__default.createElement("div", { className: TuiBreadcrumbsClasses.item, key: crumb.label }, index > 0 && /* @__PURE__ */ React__default.createElement(
        "span",
        {
          className: cn(
            TuiBreadcrumbsClasses.separator,
            isLast && TuiBreadcrumbsClasses.separatorLast
          )
        },
        /* @__PURE__ */ React__default.createElement(ChevronForward24, { color: paletteB23.front.minor })
      ), /* @__PURE__ */ React__default.createElement(
        BreadcrumbCommon,
        {
          ...crumb,
          isLast,
          isFirst: index === 0,
          hiddenCrumbs
        }
      ));
    })
  );
}

export { BreadcrumbsCommon };
//# sourceMappingURL=Breadcrumbs.js.map
