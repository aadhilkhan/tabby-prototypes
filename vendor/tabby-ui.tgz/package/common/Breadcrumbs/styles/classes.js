const TuiBreadcrumbsClasses = {
  ellipsis: "TuiBreadcrumbs-ellipsis",
  firstLabel: "TuiBreadcrumbs-firstLabel",
  item: "TuiBreadcrumbs-item",
  label: "TuiBreadcrumbs-label",
  separator: "TuiBreadcrumbs-separator",
  separatorLast: "TuiBreadcrumbs-separatorLast"
};

export { TuiBreadcrumbsClasses };
//# sourceMappingURL=classes.js.map
