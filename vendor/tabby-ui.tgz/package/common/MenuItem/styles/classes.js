const TuiMenuItemClasses = {
  content: "TuiMenuItem-content",
  divider: "TuiMenuItem-divider",
  justText: "TuiMenuItem-justText",
  textWrapper: "TuiMenuItem-textWrapper",
  withCheckbox: "TuiMenuItem-withCheckbox",
  withTopHelperText: "TuiMenuItem-withTopHelperText"
};

export { TuiMenuItemClasses };
//# sourceMappingURL=classes.js.map
