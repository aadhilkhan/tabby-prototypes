const TuiLoaderClasses = {
  "3dots-root": "TuiLoader-3dots-root",
  "3dots-dot": "TuiLoader-3dots-dot",
  "Spinning24-root": "TuiLoader-Spinning24-root",
  "Spinning48-root": "TuiLoader-Spinning48-root"
};

export { TuiLoaderClasses };
//# sourceMappingURL=classes.js.map
