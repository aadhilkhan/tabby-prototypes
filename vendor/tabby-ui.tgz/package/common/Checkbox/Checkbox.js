import cn from 'classnames';
import React__default from 'react';
import { Checkbox } from '@mui/material';
import { TuiCheckboxClasses } from './styles/classes.js';

function CheckboxCommon(props) {
  const { className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(
    Checkbox,
    {
      ...rest,
      className: cn(
        "Tui-Component",
        "Tui-Checkbox",
        TuiCheckboxClasses.root,
        className
      )
    }
  );
}

export { CheckboxCommon };
//# sourceMappingURL=Checkbox.js.map
