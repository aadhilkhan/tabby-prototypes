const TuiCheckboxClasses = {
  root: "TuiCheckbox-root",
  iconRoot: "TuiCheckbox-iconRoot",
  base: "TuiCheckbox-base",
  border: "TuiCheckbox-border",
  icon: "TuiCheckbox-icon"
};

export { TuiCheckboxClasses };
//# sourceMappingURL=classes.js.map
