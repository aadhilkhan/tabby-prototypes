const TuiFormLabelClasses = {
  forTextField: "TuiFormLabel-forTextField",
  forRadio: "TuiFormLabel-forRadio",
  forCheckbox: "TuiFormLabel-forCheckbox",
  forSwitch: "TuiFormLabel-forSwitch"
};

export { TuiFormLabelClasses };
//# sourceMappingURL=classes.js.map
