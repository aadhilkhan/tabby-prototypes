import cn from 'classnames';
import React__default from 'react';
import { FormLabel } from '@mui/material';

function FormLabelCommon(props) {
  const { children, variant, className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(
    FormLabel,
    {
      ...rest,
      className: cn(
        "Tui-Component",
        "Tui-FormLabel",
        `TuiFormLabel-for${variant}`,
        className
      )
    },
    children
  );
}

export { FormLabelCommon };
//# sourceMappingURL=FormLabel.js.map
