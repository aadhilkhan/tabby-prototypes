import React__default from 'react';
import cn from 'classnames';
import { FormHelperText } from '@mui/material';

function FormHelperTextCommon(props) {
  const { className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(
    FormHelperText,
    {
      ...rest,
      className: cn("Tui-Component", "Tui-FormHelperText", className)
    }
  );
}

export { FormHelperTextCommon };
//# sourceMappingURL=FormHelperText.js.map
