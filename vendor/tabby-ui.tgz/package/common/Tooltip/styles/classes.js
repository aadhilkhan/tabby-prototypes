const TuiTooltipClasses = {
  bottomEnd: "TuiTooltip-bottom-end",
  topEnd: "TuiTooltip-top-end",
  bottomStart: "TuiTooltip-bottom-start",
  topStart: "TuiTooltip-top-start",
  leftEnd: "TuiTooltip-left-end",
  rightEnd: "TuiTooltip-right-end",
  leftStart: "TuiTooltip-left-start",
  rightStart: "TuiTooltip-right-start"
};

export { TuiTooltipClasses };
//# sourceMappingURL=classes.js.map
