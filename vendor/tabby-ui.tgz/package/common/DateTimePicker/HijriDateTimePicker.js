import cn from 'classnames';
import React__default from 'react';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { DesktopDateTimePicker } from '@mui/x-date-pickers/DesktopDateTimePicker';
import { HijriAdapter } from '../../core/HijriAdapter/HijriAdapter.js';

function HijriDateTimePicker(props) {
  const { className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(LocalizationProvider, { dateAdapter: HijriAdapter }, /* @__PURE__ */ React__default.createElement(
    DesktopDateTimePicker,
    {
      ...rest,
      className: cn("Tui-Component", "Tui-DatePicker", className)
    }
  ));
}

export { HijriDateTimePicker as default };
//# sourceMappingURL=HijriDateTimePicker.js.map
