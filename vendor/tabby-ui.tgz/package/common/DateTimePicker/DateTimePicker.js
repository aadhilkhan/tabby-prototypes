import React__default from 'react';
import GregorianDateTimePicker from './GregorianDateTimePicker.js';
import HijriDateTimePicker from './HijriDateTimePicker.js';

function DateTimePickerCommon(props) {
  const { isHijri, ...rest } = props;
  if (isHijri) {
    return /* @__PURE__ */ React__default.createElement(HijriDateTimePicker, { ...rest });
  }
  return /* @__PURE__ */ React__default.createElement(GregorianDateTimePicker, { ...rest });
}

export { DateTimePickerCommon };
//# sourceMappingURL=DateTimePicker.js.map
