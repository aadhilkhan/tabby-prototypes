import cn from 'classnames';
import React__default from 'react';
import { LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { DesktopDateTimePicker } from '@mui/x-date-pickers/DesktopDateTimePicker';

function GregorianDateTimePicker(props) {
  const { className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(LocalizationProvider, { dateAdapter: AdapterDateFns }, /* @__PURE__ */ React__default.createElement(
    DesktopDateTimePicker,
    {
      ...rest,
      className: cn("Tui-Component", "Tui-DateTimePicker", className)
    }
  ));
}

export { GregorianDateTimePicker as default };
//# sourceMappingURL=GregorianDateTimePicker.js.map
