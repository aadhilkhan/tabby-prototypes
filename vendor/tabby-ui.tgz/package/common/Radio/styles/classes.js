const TuiRadioClasses = {
  root: "TuiRadio-root",
  iconRoot: "TuiRadio-iconRoot",
  base: "TuiRadio-base",
  border: "TuiRadio-border",
  disabled: "TuiRadio-disabled",
  icon: "TuiRadio-icon"
};

export { TuiRadioClasses };
//# sourceMappingURL=classes.js.map
