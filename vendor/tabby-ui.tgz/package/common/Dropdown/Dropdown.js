import cn from 'classnames';
import React__default from 'react';
import { deepmerge } from '@mui/utils';

function DropdownCommon(props) {
  const {
    children,
    menuItems,
    MenuItemClassName,
    MenuItemSX = {},
    MenuSlotProps,
    MenuListProps,
    MenuComponent,
    MenuItemComponent,
    className
  } = props;
  const [anchorEl, setAnchorEl] = React__default.useState(null);
  const open = Boolean(anchorEl);
  const handleOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  return /* @__PURE__ */ React__default.createElement(React__default.Fragment, null, /* @__PURE__ */ React__default.createElement(
    "div",
    {
      onClick: handleOpen,
      "data-testid": "TuiDropdown-trigger",
      className: cn("Tui-Component", "Tui-Dropdown", className)
    },
    children
  ), /* @__PURE__ */ React__default.createElement(
    MenuComponent,
    {
      anchorEl,
      open,
      onClose: handleClose,
      slotProps: MenuSlotProps,
      MenuListProps
    },
    menuItems.map((menuItem) => /* @__PURE__ */ React__default.createElement(
      MenuItemComponent,
      {
        key: menuItem.label,
        ...menuItem,
        className: MenuItemClassName,
        sx: deepmerge(MenuItemSX, menuItem.sx),
        onClick: (event) => {
          handleClose();
          if (menuItem.onClick) menuItem.onClick(event);
        }
      }
    ))
  ));
}

export { DropdownCommon };
//# sourceMappingURL=Dropdown.js.map
