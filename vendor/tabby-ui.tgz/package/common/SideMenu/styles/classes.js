const TuiSideMenuClasses = {
  content: "TuiSideMenu-content"
};
const TuiSideMenuBlockClasses = {
  root: "TuiSideMenuBlock-root"
};
const TuiListSubheaderClasses = {
  root: "TuiListSubheader-root",
  overlay: "TuiListSubheader-overlay"
};
const TuiSideMenuHeaderClasses = {
  root: "TuiSideMenuHeader-root",
  collapseButton: "TuiSideMenuHeader-collapseButton"
};
const TuiListItemClasses = {
  content: "TuiListItem-content"
};

export { TuiListItemClasses, TuiListSubheaderClasses, TuiSideMenuBlockClasses, TuiSideMenuClasses, TuiSideMenuHeaderClasses };
//# sourceMappingURL=classes.js.map
