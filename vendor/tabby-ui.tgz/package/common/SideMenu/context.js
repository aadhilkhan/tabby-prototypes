import React__default, { createContext, useContext, useState, useMemo } from 'react';
import { useLocalStorage } from '../../hooks/useLocalStorage.js';

const SideMenuContext = createContext(
  void 0
);
const SIDE_MENU_COLLAPSE_LS_KEY = "isSideMenuCollapsed";
function SideMenuProvider(props) {
  const { children } = props;
  const [isToggledByUser, setIsToggledByUser] = useState(false);
  const [isCollapsed, setIsCollapsed] = useLocalStorage(
    SIDE_MENU_COLLAPSE_LS_KEY,
    false
  );
  const value = useMemo(
    () => ({
      isCollapsed,
      setIsCollapsed,
      isToggledByUser,
      setIsToggledByUser
    }),
    [isCollapsed, isToggledByUser, setIsCollapsed]
  );
  return /* @__PURE__ */ React__default.createElement(SideMenuContext.Provider, { value }, children);
}
const useSideMenuContext = () => {
  const context = useContext(SideMenuContext);
  if (context === void 0) {
    throw new Error("useSideMenuContext must be used within a SideMenuContext");
  }
  return context;
};
const WithSideMenuProvider = (Component) => function f(props) {
  return /* @__PURE__ */ React__default.createElement(SideMenuProvider, null, /* @__PURE__ */ React__default.createElement(Component, { ...props }));
};

export { SIDE_MENU_COLLAPSE_LS_KEY, SideMenuContext, SideMenuProvider, WithSideMenuProvider, useSideMenuContext };
//# sourceMappingURL=context.js.map
