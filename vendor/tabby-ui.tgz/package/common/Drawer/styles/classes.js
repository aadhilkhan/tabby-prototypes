const TuiDrawerClasses = {
  root: "TuiDrawer-root",
  header: "TuiDrawer-header",
  footer: "TuiDrawer-footer",
  body: "TuiDrawer-body",
  bodyBorderTop: "TuiDrawer-bodyBorderTop",
  bodyBorderBottom: "TuiDrawer-bodyBorderBottom",
  bodyNoScroll: "TuiDrawer-bodyNoScroll"
};

export { TuiDrawerClasses };
//# sourceMappingURL=classes.js.map
