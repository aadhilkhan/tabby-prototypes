import cn from 'classnames';
import React__default from 'react';
import { useTheme, Drawer } from '@mui/material';
import { TuiDrawerClasses } from './styles/classes.js';

const BORDER_TYPES = {
  noscroll: "noscroll",
  top: "top",
  bottom: "bottom"};
function DrawerCommon(props) {
  const theme = useTheme();
  const {
    header,
    body,
    footer,
    width,
    PaperProps = {},
    className,
    ...rest
  } = props;
  if (!PaperProps.sx) PaperProps.sx = {};
  PaperProps.sx = { ...PaperProps.sx, width };
  return /* @__PURE__ */ React__default.createElement(
    Drawer,
    {
      PaperProps,
      dir: theme.direction,
      ...rest,
      className: cn(
        "Tui-Component",
        "Tui-Drawer",
        TuiDrawerClasses.root,
        className
      )
    },
    /* @__PURE__ */ React__default.createElement(React__default.Fragment, null, header, body, footer)
  );
}

export { BORDER_TYPES, DrawerCommon };
//# sourceMappingURL=Drawer.js.map
