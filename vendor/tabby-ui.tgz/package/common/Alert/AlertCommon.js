import cn from 'classnames';
import React__default from 'react';
import { Alert, AlertTitle } from '@mui/material';
import { Stack } from '@mui/system';
import { Text } from '../../B23/Text/Text.js';
import AlertStroke24 from '../../icons/core/AlertStroke24.js';
import CheckM24 from '../../icons/core/CheckM24.js';
import Info24 from '../../icons/core/Info24.js';
import { TuiAlertClasses } from './styles/classes.js';

const defaultIconMapping = {
  warning: /* @__PURE__ */ React__default.createElement(AlertStroke24, null),
  error: /* @__PURE__ */ React__default.createElement(AlertStroke24, null),
  success: /* @__PURE__ */ React__default.createElement(CheckM24, null),
  info: /* @__PURE__ */ React__default.createElement(Info24, null),
  dark: /* @__PURE__ */ React__default.createElement(Info24, null)
};
function AlertCommon(props) {
  const {
    title,
    children,
    iconMapping,
    severity = "info",
    iconButton,
    onClose,
    className,
    action,
    rootRef,
    ...rest
  } = props;
  const muiSeverity = severity === "dark" ? "info" : severity;
  return /* @__PURE__ */ React__default.createElement(
    Alert,
    {
      severity: muiSeverity,
      iconMapping: iconMapping || defaultIconMapping,
      action: action || onClose && iconButton,
      ref: rootRef,
      ...rest,
      className: cn(
        "Tui-Component",
        "Tui-Alert",
        TuiAlertClasses.root,
        className,
        {
          [TuiAlertClasses.dark]: severity === "dark"
        }
      )
    },
    /* @__PURE__ */ React__default.createElement(Stack, { gap: 1 }, title && /* @__PURE__ */ React__default.createElement(
      AlertTitle,
      {
        sx: { marginBlock: 0 }
      },
      title
    ), children && /* @__PURE__ */ React__default.createElement(
      Text,
      {
        variant: "body2Loose500",
        sx: {
          color: "inherit"
        }
      },
      children
    ))
  );
}

export { AlertCommon };
//# sourceMappingURL=AlertCommon.js.map
