const TuiAlertClasses = {
  root: "TuiAlert-root",
  dark: "TuiAlert-dark",
  closeButton: "TuiAlert-closeButton"
};

export { TuiAlertClasses };
//# sourceMappingURL=classes.js.map
