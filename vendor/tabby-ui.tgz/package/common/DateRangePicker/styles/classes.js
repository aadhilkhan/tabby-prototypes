const TuiDateRangePickerLabelClasses = {
  root: "TuiDateRangePickerLabel-root",
  label: "TuiDateRangePickerLabel-label",
  divider: "TuiDateRangePickerLabel-divider"
};

export { TuiDateRangePickerLabelClasses };
//# sourceMappingURL=classes.js.map
