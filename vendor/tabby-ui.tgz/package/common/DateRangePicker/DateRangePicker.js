import React__default from 'react';
import { Box } from '@mui/material';
import GregorianDateRangePicker from './GregorianDateRangePicker.js';
import HijriDateRangePicker from './HijriDateRangePicker.js';

function DateRangePickerCommon(props) {
  const { isHijri = false, labels, ...rest } = props;
  const Component = isHijri ? HijriDateRangePicker : GregorianDateRangePicker;
  if (!labels) {
    return /* @__PURE__ */ React__default.createElement(Component, { ...rest });
  }
  return (
    // eslint-disable-next-line local-rules/jsx-top-wrapper-spread
    /* @__PURE__ */ React__default.createElement(Box, null, labels, /* @__PURE__ */ React__default.createElement(Component, { ...rest, localeText: { start: "", end: "" } }))
  );
}

export { DateRangePickerCommon };
//# sourceMappingURL=DateRangePicker.js.map
