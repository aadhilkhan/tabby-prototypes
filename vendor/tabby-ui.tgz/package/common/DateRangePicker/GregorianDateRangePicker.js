import cn from 'classnames';
import React__default from 'react';
import { AdapterDateFns } from '@mui/x-date-pickers-pro/AdapterDateFns';
import { DesktopDateRangePicker } from '@mui/x-date-pickers-pro/DesktopDateRangePicker';
import { LocalizationProvider } from '@mui/x-date-pickers-pro/LocalizationProvider';

function GregorianDateRangePicker(props) {
  const { className, ...rest } = props;
  return /* @__PURE__ */ React__default.createElement(LocalizationProvider, { dateAdapter: AdapterDateFns }, /* @__PURE__ */ React__default.createElement(
    DesktopDateRangePicker,
    {
      ...rest,
      className: cn("Tui-Component", "Tui-DateRangePicker", className)
    }
  ));
}

export { GregorianDateRangePicker as default };
//# sourceMappingURL=GregorianDateRangePicker.js.map
