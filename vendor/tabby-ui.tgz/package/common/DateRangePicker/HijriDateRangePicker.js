import React__default from 'react';
import { DesktopDateRangePicker } from '@mui/x-date-pickers-pro/DesktopDateRangePicker';
import { LocalizationProvider } from '@mui/x-date-pickers-pro/LocalizationProvider';
import { HijriAdapter } from '../../core/HijriAdapter/HijriAdapter.js';

function HijriDateRangePicker(props) {
  return /* @__PURE__ */ React__default.createElement(LocalizationProvider, { dateAdapter: HijriAdapter }, /* @__PURE__ */ React__default.createElement(DesktopDateRangePicker, { ...props }));
}

export { HijriDateRangePicker as default };
//# sourceMappingURL=HijriDateRangePicker.js.map
