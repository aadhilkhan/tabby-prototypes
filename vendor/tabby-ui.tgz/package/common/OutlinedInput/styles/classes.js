const TuiOutlineInputClasses = {
  labelInside: "TuiOutlineInput-labelInside",
  errorIcon: "TuiOutlineInput-errorIcon",
  sizeExtraSmall: "TuiOutlineInput-sizeExtraSmall"
};
const TuiTwoLinedInputClasses = {
  root: "TuiTwoLinedInput-root",
  filled: "TuiTwoLinedInput-filled"
};

export { TuiOutlineInputClasses, TuiTwoLinedInputClasses };
//# sourceMappingURL=classes.js.map
