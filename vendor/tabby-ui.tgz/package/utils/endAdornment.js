import * as React from 'react';
import { Box } from '@mui/material';
import AlertStroke24 from '../icons/core/AlertStroke24.js';
import { paletteB23 } from '../theme/palette/paletteB23.js';

const ERROR_ICON_KEY = "ERROR_ICON_KEY";
function injectErrorToEndAdornment(endAdornment, error) {
  if (error) {
    const ErrorIconElement = (
      // eslint-disable-next-line local-rules/no-box-style-props
      /* @__PURE__ */ React.createElement(
        Box,
        {
          key: ERROR_ICON_KEY,
          sx: {
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            width: "28px",
            height: "28px",
            padding: "2px",
            verticalAlign: "middle"
          },
          className: "TuiErrorAdornment-root"
        },
        /* @__PURE__ */ React.createElement(AlertStroke24, { color: paletteB23.accent.negativeA })
      )
    );
    if (React.isValidElement(endAdornment)) {
      const childrenArray = React.Children.toArray(endAdornment.props.children);
      childrenArray.splice(-1, 0, ErrorIconElement);
      return React.cloneElement(
        endAdornment,
        endAdornment.props,
        childrenArray
      );
    }
    return ErrorIconElement;
  }
  return endAdornment;
}

export { injectErrorToEndAdornment };
//# sourceMappingURL=endAdornment.js.map
